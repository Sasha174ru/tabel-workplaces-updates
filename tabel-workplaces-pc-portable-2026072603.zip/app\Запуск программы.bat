@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"

set "PORT=18765"
set "URL=http://127.0.0.1:%PORT%/index.html?v=2026072403"

netstat -ano | findstr /R /C:":%PORT% .*LISTENING" >nul 2>nul
if not errorlevel 1 goto open_app

where py >nul 2>nul
if %errorlevel%==0 (
  start "Tabel server" /min py -3 -m http.server %PORT% --bind 127.0.0.1
  goto wait_server
)

where python >nul 2>nul
if %errorlevel%==0 (
  start "Tabel server" /min python -m http.server %PORT% --bind 127.0.0.1
  goto wait_server
)

start "" "%~dp0index.html"
exit /b

:wait_server
timeout /t 1 /nobreak >nul

:open_app
start "" "%URL%"
exit /b
