@echo off
setlocal
cd /d "%~dp0"

if not exist "server.pid" exit /b 0
set /p PID=<server.pid
powershell -NoProfile -ExecutionPolicy Bypass -Command "Stop-Process -Id %PID% -Force -ErrorAction SilentlyContinue"
del "server.pid" >nul 2>nul
exit /b 0
