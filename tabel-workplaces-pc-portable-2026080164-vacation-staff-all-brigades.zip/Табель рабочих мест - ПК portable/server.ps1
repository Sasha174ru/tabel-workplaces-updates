param(
  [Parameter(Mandatory = $true)]
  [string]$Root,

  [int]$Port = 8765
)

$ErrorActionPreference = "Stop"

$rootPath = (Resolve-Path -LiteralPath $Root).Path
$basePath = Split-Path -Parent $MyInvocation.MyCommand.Path
$logPath = Join-Path $basePath "server.log"
$pidPath = Join-Path $basePath "server.pid"

Set-Content -LiteralPath $pidPath -Value $PID -Encoding ASCII

function Get-ContentType([string]$Path) {
  switch ([IO.Path]::GetExtension($Path).ToLowerInvariant()) {
    ".html" { "text/html; charset=utf-8"; break }
    ".css" { "text/css; charset=utf-8"; break }
    ".js" { "application/javascript; charset=utf-8"; break }
    ".json" { "application/json; charset=utf-8"; break }
    ".txt" { "text/plain; charset=utf-8"; break }
    ".png" { "image/png"; break }
    ".jpg" { "image/jpeg"; break }
    ".jpeg" { "image/jpeg"; break }
    ".svg" { "image/svg+xml"; break }
    default { "application/octet-stream" }
  }
}

Add-Type -AssemblyName System.Web
$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add("http://127.0.0.1:$Port/")
$listener.Start()
Add-Content -LiteralPath $logPath -Value "$(Get-Date -Format s) started on 127.0.0.1:$Port root=$rootPath" -Encoding UTF8

while ($listener.IsListening) {
  try {
    $context = $listener.GetContext()
    $requestPath = [System.Web.HttpUtility]::UrlDecode($context.Request.Url.AbsolutePath.TrimStart("/"))
    if ([string]::IsNullOrWhiteSpace($requestPath)) { $requestPath = "index.html" }
    $requestPath = $requestPath -replace "/", [IO.Path]::DirectorySeparatorChar
    $target = [IO.Path]::GetFullPath((Join-Path $rootPath $requestPath))

    if (-not $target.StartsWith($rootPath, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $target -PathType Leaf)) {
      $context.Response.StatusCode = 404
      $bytes = [Text.Encoding]::UTF8.GetBytes("Not found")
    } else {
      $context.Response.StatusCode = 200
      $context.Response.ContentType = Get-ContentType $target
      $bytes = [IO.File]::ReadAllBytes($target)
    }

    $context.Response.ContentLength64 = $bytes.Length
    $context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $context.Response.OutputStream.Close()
  } catch {
    Add-Content -LiteralPath $logPath -Value "$(Get-Date -Format s) error: $($_.Exception.Message)" -Encoding UTF8
  }
}
