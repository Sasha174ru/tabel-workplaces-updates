@echo off
setlocal
cd /d "%~dp0"
start "" "%~dp0app\index.html"
exit /b 0
