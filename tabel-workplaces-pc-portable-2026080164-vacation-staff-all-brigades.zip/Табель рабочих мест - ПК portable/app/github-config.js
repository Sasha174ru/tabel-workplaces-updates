window.TABEL_GITHUB_CONFIG = {
  repo: "Sasha174ru/tabel-workplaces",
  updateRepo: "Sasha174ru/tabel-workplaces-updates",
  branch: "main",
  dataPath: "data/tabel-data.json",
  autoSync: false,
};
