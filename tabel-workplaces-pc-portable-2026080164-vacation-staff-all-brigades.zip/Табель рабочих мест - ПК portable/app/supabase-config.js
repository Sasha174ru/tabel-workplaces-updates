﻿window.TABEL_SUPABASE_CONFIG = {
  projectUrl: "https://wnepotwqkknzsujwyiss.supabase.co",
  fallbackProjectUrls: [],
  anonKey: "sb_publishable_46Y-chLGP2ydILcJX0eT3Q_Ij8TXgH1",
  requireAuth: false,
  enabled: true,
};
