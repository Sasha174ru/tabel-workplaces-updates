@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"

set "PORT=18766"
set "APP_DIR=%~dp0app"
set "URL=http://127.0.0.1:%PORT%/index.html?v=2026080132"
set "SERVER_PS=%~dp0server.ps1"

netstat -ano | findstr /R /C:":%PORT% .*LISTENING" >nul 2>nul
if not errorlevel 1 goto open_app

start "Tabel portable server" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "& '%SERVER_PS%' -Root '%APP_DIR%' -Port %PORT%"
if errorlevel 1 goto direct_open

timeout /t 1 /nobreak >nul

:open_app
start "" "%URL%"
exit /b 0

:direct_open
start "" "%APP_DIR%\index.html"
exit /b 0
