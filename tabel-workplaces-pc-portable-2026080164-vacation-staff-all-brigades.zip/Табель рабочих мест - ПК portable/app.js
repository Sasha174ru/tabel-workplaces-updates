const EMPLOYEES = [
  { section: "Плавильный участок", place: "Печь 41", code: "41", tab: "573824", name: "Сибгатуллин Равиль Раисович", grade: 7, role: "melter" },
  { section: "Плавильный участок", place: "Печь 41", code: "41", tab: "201170", name: "Ваньков Денис Алексеевич", grade: 6, role: "melter" },
  { section: "Плавильный участок", place: "Печь 41", code: "41", tab: "576071", name: "Рахманов Расулжон Мансурович", grade: 6, role: "melter" },
  { section: "Плавильный участок", place: "Печь 41", code: "41", tab: "115499", name: "Гренченков Олег Николаевич", grade: 5, role: "melter" },
  { section: "Плавильный участок", place: "Печь 42", code: "42", tab: "196002", name: "Белоус Руслан Александрович", grade: 6, role: "melter" },
  { section: "Плавильный участок", place: "Печь 42", code: "42", tab: "109834", name: "Быковский Евгений Александрович", grade: 6, role: "melter" },
  { section: "Плавильный участок", place: "Печь 42", code: "42", tab: "101649", name: "Шиков Евгений Сергеевич", grade: 6, role: "melter" },
  { section: "Плавильный участок", place: "Печь 42", code: "42", tab: "121283", name: "Бадретдинов Рустам Хабилович", grade: 5, role: "melter" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "120915", name: "Маминов Алексей Валерьевич", grade: 7, role: "melter" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "194794", name: "Исаченко Олег Викторович", grade: 6, role: "melter" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "128918", name: "Ишкильдин Мирхат Раульевич", grade: 6, role: "melter" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "198027", name: "Касымов Даниль Раульевич", grade: 5, role: "melter" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "203336", name: "Мухин Андрей Андреевич", grade: 5, role: "melter" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "501830", name: "Шорин Артем Александрович", grade: 5, role: "melter" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "110956", name: "Алёшин Анатолий Николаевич", grade: 6, role: "melter" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "119906", name: "Карташев Денис Борисович", grade: 6, role: "melter" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "109013", name: "Пережогин Вадим Викторович", grade: 6, role: "melter" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "576242", name: "Облокулов Рузибой Бойкузиевич", grade: 5, role: "melter" },
  { section: "Плавильный участок", place: "Печь 45", code: "45", tab: "101708", name: "Ромин Василий Владимирович", grade: 7, role: "melter" },
  { section: "Плавильный участок", place: "Печь 45", code: "45", tab: "116308", name: "Фахрутдинов Рамиль Наркисович", grade: 6, role: "melter" },
  { section: "Плавильный участок", place: "Печь 45", code: "45", tab: "194062", name: "Шаймухаметов Эдуард Саримович", grade: 6, role: "melter" },
  { section: "Плавильный участок", place: "Печь 45", code: "45", tab: "202826", name: "Ибрагимов Вадим Ирмухаметович", grade: 5, role: "melter" },
  { section: "Плавильный участок", place: "Печь 45", code: "45", tab: "195304", name: "Кочагин Дмитрий Викторович", grade: 5, role: "melter" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "110810", name: "Черных Анатолий Дмитриевич", grade: 7, role: "melter" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "120597", name: "Касьян Евгений Владимирович", grade: 6, role: "melter" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "199787", name: "Смирнов Алексей Александрович", grade: 6, role: "melter" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "501944", name: "Федотов Павел Валерьевич", grade: 5, role: "melter" },
  { section: "Плавильный участок", place: "Печь 47", code: "47", tab: "118969", name: "Ваньков Алексей Юрьевич", grade: 7, role: "melter" },
  { section: "Плавильный участок", place: "Печь 47", code: "47", tab: "202371", name: "Синицких Антон Сергеевич", grade: 6, role: "melter" },
  { section: "Плавильный участок", place: "Печь 47", code: "47", tab: "112375", name: "Якупов Ильдар Габдельнафикович", grade: 6, role: "melter" },
  { section: "Плавильный участок", place: "Печь 47", code: "47", tab: "203328", name: "Еганшин Ильназ Марсович", grade: 5, role: "melter" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "199586", name: "Гришин Юрий Николаевич", grade: 4, role: "caster" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "190037", name: "Савенков Сергей Евгеньевич", grade: 4, role: "caster" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "108292", name: "Хивренко Андрей Владимирович", grade: 4, role: "caster" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "199294", name: "Хисматуллин Тимур Иршатович", grade: 4, role: "caster" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "203346", name: "Каблуков Алексей Андреевич", grade: 3, role: "caster" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "201383", name: "Корюкин Алексей Александрович", grade: 3, role: "caster" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "203347", name: "Трошин Алексей Викторович", grade: 3, role: "caster" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "101520", name: "Якшин Евгений Геннадьевич", grade: 3, role: "caster" },
];

const BRIGADE1_EMPLOYEES = [
  { section: "Плавильный участок", place: "Печь 41", code: "41", tab: "200826", name: "Вебер Евгений Адамович", grade: 5, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 41", code: "41", tab: "119125", name: "Донских Александр Александрович", grade: 7, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 41", code: "41", tab: "100105", name: "Карякин Сергей Борисович", grade: 6, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 41", code: "41", tab: "193918", name: "Мараков Павел Александрович", grade: 6, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 41", code: "41", tab: "191442", name: "Подгороднов Станислав Викторович", grade: 5, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 42", code: "42", tab: "503060", name: "Алябьев Евгений Васильевич", grade: 7, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 42", code: "42", tab: "128484", name: "Калинин Сергей Александрович", grade: 5, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 42", code: "42", tab: "129005", name: "Прудников Андрей Геннадьевич", grade: 5, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 42", code: "42", tab: "122845", name: "Рыков Артем Николаевич", grade: 6, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 42", code: "42", tab: "102245", name: "Юдин Валерий Анатольевич", grade: 6, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "506115", name: "Мельников Даниил Владимирович", grade: 6, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "193760", name: "Мухамеджанов Хасан Идрисович", grade: 5, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "197868", name: "Новиков Максим Николаевич", grade: 5, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "110737", name: "Пикулин Константин Борисович", grade: 7, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "101892", name: "Фесенко Сергей Сергеевич", grade: 6, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "199962", name: "Габдрафиков Дарьян Хакимзянович", grade: 6, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "194582", name: "Тараненко Михаил Васильевич", grade: 5, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "201841", name: "Фаттахов Айнур Ахнафович", grade: 5, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "128514", name: "Халиков Раиль Раисович", grade: 7, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "112400", name: "Швидко Алексей Анатольевич", grade: 5, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "190770", name: "Юсупов Санжар Суюнович", grade: 6, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 45", code: "45", tab: "191801", name: "Лебедев Максим Николаевич", grade: 7, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 45", code: "45", tab: "123189", name: "Сафин Радик Салаватович", grade: 5, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 45", code: "45", tab: "202812", name: "Серебряков Андрей Константинович", grade: 5, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 45", code: "45", tab: "107515", name: "Хивренко Вячеслав Владимирович", grade: 6, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "129281", name: "Оскин Руслан Александрович", grade: 6, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "201908", name: "Филиппов Алексей Валерьевич", grade: 5, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "119925", name: "Хайруллин Валерий Исрафилович", grade: 7, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "195972", name: "Шамгунов Руслан Габдрахимович", grade: 6, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 47", code: "47", tab: "197155", name: "Антонов Николай Владимирович", grade: 7, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 47", code: "47", tab: "197025", name: "Индюков Сергей Сергеевич", grade: 5, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 47", code: "47", tab: "195739", name: "Мартынчук Николай Николаевич", grade: 6, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 47", code: "47", tab: "196493", name: "Михайлов Виктор Сергеевич", grade: 5, role: "melter", brigade: "1" },
  { section: "Плавильный участок", place: "Печь 47", code: "47", tab: "202365", name: "Руковицын Владимир Александрович", grade: 5, role: "melter", brigade: "1" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "117586", name: "Гиляжитдинов Вадим Ринатович", grade: 3, role: "caster", brigade: "1" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "118571", name: "Жаксалыков Серик Альжанович", grade: 3, role: "caster", brigade: "1" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "105396", name: "Малюков Дмитрий Викторович", grade: 4, role: "caster", brigade: "1" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "118286", name: "Расулев Миндебай Абдрафикович", grade: 3, role: "caster", brigade: "1" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "201550", name: "Сулейменов Геннадий Викторович", grade: 3, role: "caster", brigade: "1" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "116343", name: "Сухоруков Алексей Петрович", grade: 4, role: "caster", brigade: "1" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "199697", name: "Цепенников Анатолий Сергеевич", grade: 4, role: "caster", brigade: "1" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "109803", name: "Чернаков Сергей Викторович", grade: 4, role: "caster", brigade: "1" },
];

const BRIGADE2_EMPLOYEES = [
  { section: "Плавильный участок", place: "Печь 41", code: "41", tab: "101589", name: "Буланов Дмитрий Владимирович", grade: 6, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 41", code: "41", tab: "191436", name: "Мужагитов Ринат Раульевич", grade: 5, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 41", code: "41", tab: "115332", name: "Самойлов Евгений Николаевич", grade: 7, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 41", code: "41", tab: "196577", name: "Хусаинов Зиннур Зуфарович", grade: 6, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 42", code: "42", tab: "203093", name: "Васильев Алексей Анатольевич", grade: 5, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 42", code: "42", tab: "113684", name: "Миловский Андрей Александрович", grade: 7, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 42", code: "42", tab: "199577", name: "Пронин Дмитрий Олегович", grade: 5, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 42", code: "42", tab: "505580", name: "Саетгалин Камиль Ризванович", grade: 6, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 42", code: "42", tab: "196348", name: "Шакиров Максим Мирасович", grade: 6, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "101509", name: "Новиков Денис Михайлович", grade: 6, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "194639", name: "Сотников Сергей Викторович", grade: 5, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "101424", name: "Сычев Виталий Викторович", grade: 7, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "198444", name: "Шубников Артем Анатольевич", grade: 5, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "112144", name: "Яковлев Александр Павлович", grade: 6, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "202729", name: "Галимов Ильдус Абдулгаязович", grade: 5, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "202179", name: "Гатиятов Рафис Развитович", grade: 5, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "120801", name: "Коновалов Артём Сергеевич", grade: 5, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "120836", name: "Костин Евгений Юрьевич", grade: 7, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "101475", name: "Костин Юрий Викторович", grade: 7, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 45", code: "45", tab: "101579", name: "Ланец Анатолий Дмитриевич", grade: 7, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 45", code: "45", tab: "202305", name: "Макаровский Дмитрий Александрович", grade: 6, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 45", code: "45", tab: "100466", name: "Сафронов Сергей Викторович", grade: 5, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 45", code: "45", tab: "122945", name: "Уфимцев Александр Николаевич", grade: 5, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "101601", name: "Горбань Евгений Александрович", grade: 7, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "203334", name: "Готкин Юрий Сергеевич", grade: 5, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "196915", name: "Гусейнов Рамис Аликдерович", grade: 5, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "121409", name: "Магафуров Артем Газизович", grade: 6, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "575133", name: "Никитин Алексей Михайлович", grade: 5, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "120786", name: "Шмельцер Евгений Александрович", grade: 6, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 47", code: "47", tab: "101661", name: "Васильев Сергей Сергеевич", grade: 6, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 47", code: "47", tab: "193026", name: "Воропаев Максим Сергеевич", grade: 6, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 47", code: "47", tab: "576276", name: "Маххамов Абдурасул Хужамович", grade: 5, role: "melter", brigade: "2" },
  { section: "Плавильный участок", place: "Печь 47", code: "47", tab: "110211", name: "Юровский Эдуард Валерьевич", grade: 7, role: "melter", brigade: "2" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "113348", name: "Андреев Константин Иосифович", grade: 4, role: "caster", brigade: "2" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "201409", name: "Бикбулатов Данил Муратович", grade: 3, role: "caster", brigade: "2" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "100049", name: "Ефимов Олег Валерьевич", grade: 3, role: "caster", brigade: "2" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "104362", name: "Иовенко Павел Алексеевич", grade: 3, role: "caster", brigade: "2" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "190749", name: "Ишкинин Ришат Ринатович", grade: 3, role: "caster", brigade: "2" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "100626", name: "Кошелев Константин Владимирович", grade: 3, role: "caster", brigade: "2" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "128109", name: "Мирасов Валерий Марсович", grade: 4, role: "caster", brigade: "2" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "201072", name: "Нурмухаметов Рафис Маратович", grade: 3, role: "caster", brigade: "2" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "101840", name: "Тараскин Владимир Егорович", grade: 4, role: "caster", brigade: "2" },
];

const BRIGADE3_EMPLOYEES = [
  { section: "Плавильный участок", place: "Печь 41", code: "41", tab: "117066", name: "Абдулов Рустам Нуритдинович", grade: 6, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 41", code: "41", tab: "202837", name: "Байгот Григорий Сергеевич", grade: 5, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 41", code: "41", tab: "110925", name: "Долгих Юрий Борисович", grade: 6, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 41", code: "41", tab: "117498", name: "Евсеев Сергей Викторович", grade: 7, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 42", code: "42", tab: "114458", name: "Галухин Алексей Вячеславович", grade: 6, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 42", code: "42", tab: "200712", name: "Егоров Валентин Александрович", grade: 5, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 42", code: "42", tab: "194446", name: "Елизарьев Николай Юрьевич", grade: 7, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 42", code: "42", tab: "196038", name: "Исурин Владимир Дмитриевич", grade: 6, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 42", code: "42", tab: "192752", name: "Магафуров Аблахат Рахматуллович", grade: 5, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "504772", name: "Васильченко Иван Олегович", grade: 7, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "195371", name: "Галеев Равиль Димянович", grade: 6, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "198602", name: "Рябков Александр Игоревич", grade: 5, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 43", code: "43", tab: "195991", name: "Хакимов Салават Галяутдинович", grade: 6, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "194625", name: "Ахмадгалеев Варис Тимергалеевич", grade: 5, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "200463", name: "Лукьянов Иван Владимирович", grade: 5, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "202221", name: "Машьянов Максим Витальевич", grade: 6, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "190744", name: "Мещеряков Евгений Алексеевич", grade: 7, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 44", code: "44", tab: "203331", name: "Прокопов Андрей Юрьевич", grade: 5, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 45", code: "45", tab: "504594", name: "Альфанов Павел Владимирович", grade: 7, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 45", code: "45", tab: "119221", name: "Ашмарин Константин Владимирович", grade: 6, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 45", code: "45", tab: "201046", name: "Киреев Ильнур Гаясович", grade: 6, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 45", code: "45", tab: "202979", name: "Клюг Александр Евгеньевич", grade: 5, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "199858", name: "Валиев Довуджон Джамшедович", grade: 6, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "197727", name: "Закиров Эдуард Дмитриевич", grade: 5, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "201523", name: "Замков Александр Владимирович", grade: 5, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "129600", name: "Резвых Андрей Владимирович", grade: 6, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "193313", name: "Рейдер Александр Анатольевич", grade: 6, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "114806", name: "Хакимов Ильдар Шамгулович", grade: 6, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "196209", name: "Хусаинов Руслан Сергеевич", grade: 6, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 46", code: "46", tab: "116837", name: "Шураков Евгений Геннадьевич", grade: 7, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 47", code: "47", tab: "194194", name: "Астафьев Артём Васильевич", grade: 6, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 47", code: "47", tab: "202609", name: "Киреев Юнус Азатович", grade: 5, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 47", code: "47", tab: "119201", name: "Сергеев Евгений Владимирович", grade: 7, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 47", code: "47", tab: "198158", name: "Ситдиков Ильдар Рашидович", grade: 5, role: "melter", brigade: "3" },
  { section: "Плавильный участок", place: "Печь 47", code: "47", tab: "101352", name: "Фролов Дмитрий Федорович", grade: 6, role: "melter", brigade: "3" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "118961", name: "Азналин Рустам Данилович", grade: 4, role: "caster", brigade: "3" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "129461", name: "Глебов Сергей Михайлович", grade: 4, role: "caster", brigade: "3" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "122831", name: "Елизарьев Анатолий Юрьевич", grade: 4, role: "caster", brigade: "3" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "202426", name: "Киреев Ильгиз Ильясович", grade: 3, role: "caster", brigade: "3" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "113186", name: "Классен Михаил Петрович", grade: 3, role: "caster", brigade: "3" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "199592", name: "Солоницин Павел Викторович", grade: 3, role: "caster", brigade: "3" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "203359", name: "Янбаев Даян Дамилевич", grade: 3, role: "caster", brigade: "3" },
  { section: "Машинисты разливочных машин", place: "РМ", code: "РМ", tab: "193405", name: "Ярин Александр Александрович", grade: 4, role: "caster", brigade: "3" },
];

const BASE_EMPLOYEES = [...EMPLOYEES, ...BRIGADE1_EMPLOYEES, ...BRIGADE2_EMPLOYEES, ...BRIGADE3_EMPLOYEES];
const DEFAULT_DEPARTMENT_ID = "department-ceh-7";
const DEFAULT_DEPARTMENTS = [
  { id: DEFAULT_DEPARTMENT_ID, name: "Цех 7" },
];
const DEFAULT_STRUCTURE_COLOR = "#eaf4ff";
const DEFAULT_DEPARTMENT_COLORS = {
  [DEFAULT_DEPARTMENT_ID]: DEFAULT_STRUCTURE_COLOR,
};
const DEPARTMENT_COLOR_PALETTE = ["#eaf4ff", "#ffedd5", "#ede9fe", "#d1fae5", "#fce7f3", "#cffafe", "#fef3c7", "#e0e7ff"];
const CUSTOM_SPECIAL_ROLE_PREFIX = "custom-special-";
const BUILT_IN_SPECIAL_ROLE_IDS = ["proletchik", "subworker", "capitalRepair"];
const SPECIAL_ROLE_SCOPE_VERSION = 1;
const SPECIAL_ROLE_SCOPE_MIGRATION_TIME = "2026-07-31T00:00:00.000Z";
const CUSTOM_SPECIAL_ROLE_PALETTE = ["#dbeafe", "#dcfce7", "#fef3c7", "#fce7f3", "#e0e7ff", "#cffafe", "#fae8ff", "#ffedd5"];
const DEFAULT_WORKPLACE_SECTIONS = [
  { id: "section-furnace-bay", departmentId: DEFAULT_DEPARTMENT_ID, name: "Печи" },
  { id: "section-casting-bay", departmentId: DEFAULT_DEPARTMENT_ID, name: "Разливочные машины" },
];
const BASE_WORKPLACE_DEFINITIONS = [
  ...[41, 42, 43, 44, 45, 46, 47, 48].map((number) => ({ name: `Печь ${number}`, type: "furnace", departmentId: DEFAULT_DEPARTMENT_ID, sectionId: "section-furnace-bay" })),
  { name: "РМ", type: "production", departmentId: DEFAULT_DEPARTMENT_ID, sectionId: "section-casting-bay" },
];
const PLACES = BASE_WORKPLACE_DEFINITIONS.map((item) => item.name);
const EMPLOYEE_POSITION_OPTIONS = ["Плавильщик", "Машинист разливочной машины"];
const GLOBAL_STAFF_ADD_WORKPLACE_ACTION = "__add_workplace__";
const GLOBAL_STAFF_ADD_POSITION_ACTION = "__add_position__";
const GLOBAL_STAFF_DELETE_WORKPLACE_ACTION = "__delete_workplace__";
const GLOBAL_STAFF_DELETE_POSITION_ACTION = "__delete_position__";
const GLOBAL_STAFF_DELETE_SPECIAL_ROLE_PREFIX = "__delete_special_role__:";
const FURNACES = ["41", "42", "43", "44", "45", "46", "47", "48"];
const MONTHS = ["январь", "февраль", "март", "апрель", "май", "июнь", "июль", "август", "сентябрь", "октябрь", "ноябрь", "декабрь"];
const KIND_LABELS = { regular: "Обычная", average: "По среднему", repair: "Ремонт", warmup: "Разогрев" };
const AUTO_ABSENCE_REASON = "Не указано в рабочих местах";
const ABSENCE_REASONS = ["Больничный", "Без содержания", "Донорские", "Ветеранские", "Отпуск", "Прогул", "СВО", "Пенсионные", "Уволен", "Переведён"];
const VACATION_PRIORITIES = [
  { value: "regular", label: "Обычный" },
  { value: "privileged", label: "Льготник" },
];
const LEGACY_PRIVILEGED_VACATION_PRIORITIES = ["privileged", "veteran", "many_children", "donor", "pensioner"];
const VACATION_ALLOWANCE_OPTIONS = [35, 42];
const VACATION_MONTH_LIMIT_DAYS = 90;
const VACATION_PICKER_FUTURE_YEARS = 100;
const STORAGE_KEY = "tabel-rabochih-mest-v1";
const DEVICE_PREFERENCES_KEY = "tabel-device-preferences-v1";
const GITHUB_SETTINGS_KEY = "tabel-github-settings-v1";
const SUPABASE_SETTINGS_KEY = "tabel-supabase-settings-v1";
const SUPABASE_AUTH_KEY = "tabel-supabase-auth-v1";
const SYNC_DEVICE_KEY = "tabel-sync-device-v1";
const SYNC_CONFLICT_CODE = "SYNC_REVISION_CONFLICT";
const SYNC_MAP_FIELDS = [
  "employeeEdits",
  "dismissedTabsByBrigade",
  "vacationPriorities",
  "vacationAllowances",
  "vacationMonthLimits",
  "vacationPolicySettings",
  "employeePhones",
  "repairPlans",
  "repairPlansByBrigade",
  "appSettings",
];
const APP_VERSION = "2026.08.01.64";
const BASE_STAFF_BRIGADE = "4";
const STAFF_ADMIN_PIN_HASH = "da1dead6";
const STAFF_ADMIN_PIN_HASH_KEY = "tabel-staff-admin-pin-hash-v1";
const OFFICE_EMAIL = "Kirillovanastya1@mail.ru";
const START_SHIFT_ANCHOR_DATE = "2026-06-10";
const START_SHIFT_ANCHOR_KIND = "night";
const START_SHIFT_CYCLE = ["4", "2", "3", "1", "2", "4", "1", "3"];

let state = loadState();
let devicePreferences = loadDevicePreferences();
let activeView = "places";
let settingsViewMode = normalizeSettingsViewMode(devicePreferences.settingsSection);
let selectedSettingsDepartmentId = "";
let selectedSettingsSectionId = "";
let selectedSettingsRulesWorkplace = "";
let workplaceHierarchyLevel = "sections";
let selectedWorkplaceDepartmentId = DEFAULT_DEPARTMENT_ID;
let selectedWorkplaceSectionId = "";
let viewHistory = [];
let calendarCursor = { month: state.month, year: state.year };
let startCalendarCursor = { month: state.month, year: state.year };
let selectedWorkplace = "Печь 41";
let workplaceEditorOpened = false;
let workplaceCreateOpened = false;
let workplaceCarouselTimer = null;
let workplaceCarouselSkip = false;
let workplaceCarouselTouching = false;
let selectedWorkplaceCarouselCopy = 1;
let workplaceTapReadyToOpen = "";
let statsMode = appSettings().statisticsDefaultMode || "month";
let selectedStatsDepartmentId = DEFAULT_DEPARTMENT_ID;
let selectedStatsSectionId = "";
let vacationViewMode = "plan";
let vacationStaffOverviewYear = new Date().getFullYear();
let vacationBalanceYear = new Date().getFullYear();
let vacationDatePickerTarget = "start";
let vacationDatePickerCursor = { month: state.month, year: state.year };
let vacationDatePickerDraftStart = "";
let vacationDatePickerDraftEnd = "";
// Keep the employee selected while the planner is rerendered (for example when
// switching from July to August to add the next part of the same vacation).
let vacationSelectedEmployeeTab = "";
let syncMuted = false;
let syncTimer = null;
let autoSyncTimer = null;
let syncInProgress = false;
let pendingManualSync = false;
let lastBackgroundSyncAt = 0;
let periodicSyncTimer = null;
let saveStatusState = {
  kind: state.__lastSyncedAt ? "synced" : "local",
  text: state.__lastSyncedAt ? confirmedSyncStatusText() : "Данные загружены с устройства",
};
const SUPABASE_STARTUP_TIMEOUT_MS = 5200;
const SUPABASE_BACKGROUND_TIMEOUT_MS = 9000;
const SUPABASE_SAVE_TIMEOUT_MS = 14000;
let workplaceCache = { key: "", overviewRows: null, missingRows: null, rowsByKey: new Map() };
let workplaceListSignature = "";

const $ = (id) => document.getElementById(id);

function removeUnusedShiftFields() {
  ["shiftCountInput", "commentInput"].forEach((id) => {
    const input = $(id);
    const label = input?.closest("label");
    if (label) label.remove();
  });
}

function loadState() {
  const now = new Date();
  const fallback = {
    month: now.getMonth(),
    year: now.getFullYear(),
    brigade: BASE_STAFF_BRIGADE,
    vacationDepartmentId: DEFAULT_DEPARTMENT_ID,
    vacationSectionId: "",
    vacationBrigade: "",
    vacationYear: now.getFullYear(),
    selectedShiftDate: "",
    selectedShiftKind: "",
    orderNumber: "",
    scheduleStartDate: "",
    entries: [],
    absences: [],
    vacations: [],
    vacationPriorities: {},
    vacationAllowances: {},
    vacationMonthLimits: {},
    vacationPolicySettings: {},
    employeePhones: {},
    proletchikShifts: [],
    capitalRepairShifts: [],
    repairPlans: {},
    repairPlansByBrigade: {},
    customEmployees: [],
    employeeEdits: {},
    dismissedTabs: [],
    dismissedTabsByBrigade: {},
    deletedEntryIds: [],
    deletedProletchikShiftIds: [],
    deletedCapitalRepairShiftIds: [],
    deletedAbsenceIds: [],
    deletedVacationIds: [],
    deletedCustomEmployeeIds: [],
    appSettings: {},
  };
  try {
    return { ...fallback, ...JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}") };
  } catch {
    return fallback;
  }
}

function saveState(options = {}) {
  clearWorkplaceCache();
  if (!options.fromSync) {
    markDirtySyncFields();
    state.__localChangedAt = new Date().toISOString();
  }
  state = normalizeAppStateData(state);
  if (devicePreferences.localStorageEnabled !== false) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }
  if (!options.fromSync) {
    setSaveStatus("pending", "Изменения на устройстве · нажмите «Сохранить»");
  }
  if (options.sync === true) scheduleSupabaseSync();
}

function loadDevicePreferences() {
  const defaults = {
    displayMode: "auto",
    theme: "light",
    localStorageEnabled: true,
    serverStorageEnabled: true,
    startupSyncEnabled: true,
    interfaceDensity: "comfortable",
    settingsSection: "forms",
  };
  try {
    return { ...defaults, ...JSON.parse(localStorage.getItem(DEVICE_PREFERENCES_KEY) || "{}") };
  } catch {
    return defaults;
  }
}

function saveDevicePreferences() {
  localStorage.setItem(DEVICE_PREFERENCES_KEY, JSON.stringify(devicePreferences));
  applyDevicePreferences();
}

function normalizeStructureColor(value, fallback = DEFAULT_STRUCTURE_COLOR) {
  const color = String(value || "").trim();
  if (/^#[0-9a-f]{6}$/i.test(color)) return color.toLowerCase();
  const safeFallback = String(fallback || "").trim();
  return /^#[0-9a-f]{6}$/i.test(safeFallback) ? safeFallback.toLowerCase() : DEFAULT_STRUCTURE_COLOR;
}

function normalizeOptionalStructureColor(value) {
  const color = String(value || "").trim();
  return /^#[0-9a-f]{6}$/i.test(color) ? color.toLowerCase() : "";
}

function suggestedDepartmentColor(index = 0) {
  return DEPARTMENT_COLOR_PALETTE[Math.abs(Number(index) || 0) % DEPARTMENT_COLOR_PALETTE.length];
}

function structureColorText(value) {
  const color = normalizeStructureColor(value);
  const relativeLuminance = (red, green, blue) => {
    const channel = (value) => {
      const normalized = value / 255;
      return normalized <= 0.04045 ? normalized / 12.92 : ((normalized + 0.055) / 1.055) ** 2.4;
    };
    return (0.2126 * channel(red)) + (0.7152 * channel(green)) + (0.0722 * channel(blue));
  };
  const background = relativeLuminance(
    parseInt(color.slice(1, 3), 16),
    parseInt(color.slice(3, 5), 16),
    parseInt(color.slice(5, 7), 16)
  );
  const darkText = relativeLuminance(17, 24, 39);
  const darkContrast = (Math.max(background, darkText) + 0.05) / (Math.min(background, darkText) + 0.05);
  const lightContrast = 1.05 / (background + 0.05);
  return darkContrast >= lightContrast ? "#111827" : "#ffffff";
}

function normalizeCustomSpecialRoleId(value) {
  const id = String(value || "").trim().toLowerCase();
  return new RegExp(`^${CUSTOM_SPECIAL_ROLE_PREFIX}[a-z0-9][a-z0-9-]{0,80}$`).test(id) ? id : "";
}

function normalizeCustomSpecialRoles(value) {
  if (!Array.isArray(value)) return [];
  const roles = [];
  const usedIds = new Set();
  value.forEach((item, index) => {
    if (!item || typeof item !== "object") return;
    const id = normalizeCustomSpecialRoleId(item.id);
    const name = String(item.name || "").replace(/\s+/g, " ").trim().slice(0, 80);
    if (!id || !name || usedIds.has(id)) return;
    usedIds.add(id);
    const updatedAtTime = Date.parse(String(item.updatedAt || ""));
    roles.push({
      id,
      name,
      color: normalizeStructureColor(item.color, CUSTOM_SPECIAL_ROLE_PALETTE[index % CUSTOM_SPECIAL_ROLE_PALETTE.length]),
      archived: item.archived === true,
      ...(Number.isFinite(updatedAtTime) ? { updatedAt: new Date(updatedAtTime).toISOString() } : {}),
    });
  });
  return roles;
}

function normalizeDepartmentSpecialRoleStates(value, options = {}) {
  const raw = value && typeof value === "object" && !Array.isArray(value) ? value : {};
  const result = {};
  Object.entries(raw).forEach(([departmentId, roleStates]) => {
    const cleanDepartmentId = String(departmentId || "").trim();
    if (!cleanDepartmentId || !roleStates || typeof roleStates !== "object" || Array.isArray(roleStates)) return;
    const normalizedStates = {};
    Object.entries(roleStates).forEach(([roleValue, roleState]) => {
      const roleId = canonicalSpecialRoleId(roleValue);
      if (!roleId) return;
      const source = roleState && typeof roleState === "object" && !Array.isArray(roleState)
        ? roleState
        : { enabled: roleState === true };
      const updatedAtTime = Date.parse(String(source.updatedAt || ""));
      normalizedStates[roleId] = {
        enabled: source.enabled === true,
        ...(Number.isFinite(updatedAtTime) ? { updatedAt: new Date(updatedAtTime).toISOString() } : {}),
      };
    });
    if (Object.keys(normalizedStates).length) result[cleanDepartmentId] = normalizedStates;
  });

  if (options.migrateLegacy === true) {
    const defaultDepartmentId = String(options.defaultDepartmentId || DEFAULT_DEPARTMENT_ID);
    result[defaultDepartmentId] = { ...(result[defaultDepartmentId] || {}) };
    BUILT_IN_SPECIAL_ROLE_IDS.forEach((roleId) => {
      if (!Object.prototype.hasOwnProperty.call(result[defaultDepartmentId], roleId)) {
        result[defaultDepartmentId][roleId] = { enabled: true, updatedAt: SPECIAL_ROLE_SCOPE_MIGRATION_TIME };
      }
    });
    (options.customSpecialRoles || []).filter((role) => !role.archived).forEach((role) => {
      if (!Object.prototype.hasOwnProperty.call(result[defaultDepartmentId], role.id)) {
        result[defaultDepartmentId][role.id] = { enabled: true, updatedAt: SPECIAL_ROLE_SCOPE_MIGRATION_TIME };
      }
    });
  }
  return result;
}

function suggestedCustomSpecialRoleColor(index = 0) {
  return CUSTOM_SPECIAL_ROLE_PALETTE[Math.abs(Number(index) || 0) % CUSTOM_SPECIAL_ROLE_PALETTE.length];
}

function defaultAppSettings() {
  return {
    departments: DEFAULT_DEPARTMENTS.map((item) => ({ ...item })),
    departmentColors: { ...DEFAULT_DEPARTMENT_COLORS },
    hiddenDepartments: [],
    sections: DEFAULT_WORKPLACE_SECTIONS.map((item) => ({ ...item })),
    hiddenSections: [],
    workplaces: [],
    workplaceColors: {},
    hiddenWorkplaces: [],
    staffPositions: [...EMPLOYEE_POSITION_OPTIONS],
    hiddenStaffPositions: [],
    highlightSubworkers: true,
    subworkerColor: "#ffe8e8",
    highlightProletchik: true,
    proletchikColor: "#dcfce7",
    highlightCapitalRepair: true,
    capitalRepairColor: "#fef3c7",
    furnaceGradeRules: true,
    castingGradeRules: true,
    workplaceGradeRules: {},
    workplaceSpecialRules: {},
    customSpecialRoles: [],
    specialRoleScopeVersion: SPECIAL_ROLE_SCOPE_VERSION,
    departmentSpecialRoleStates: {
      [DEFAULT_DEPARTMENT_ID]: Object.fromEntries(BUILT_IN_SPECIAL_ROLE_IDS.map((roleId) => [roleId, { enabled: true }])),
    },
    specialWorkLabels: {
      proletchik: "Пролётчик",
      capitalRepair: "Капремонт",
      subworker: "Подработчик",
    },
    statisticsDefaultMode: "month",
    statsIncludeProletchik: true,
    statsIncludeSubworkers: true,
    statsIncludeCapitalRepair: true,
    statsIncludeRepair: true,
    statsIncludeWarmup: true,
    statsShowZeroRows: true,
    transferIncludeStandardWork: false,
    transferIncludeSubworkers: true,
    transferIncludeDifferentWorkplace: true,
    transferIncludeDifferentGrade: true,
    transferMergeConsecutiveShifts: true,
    repairMergeConsecutiveShifts: true,
    meetingIncludeEmployeesWithoutShifts: true,
    formSortMode: "date",
    formSortDirection: "asc",
    enforceGradeMaximums: true,
    enforceSpecialRoleMaximums: true,
    showMinimumStaffingWarnings: true,
  };
}

function normalizeDepartmentSettings(settings = {}) {
  const hiddenDepartmentIds = new Set(
    (Array.isArray(settings.hiddenDepartments) ? settings.hiddenDepartments : [])
      .map((id) => String(id || "").trim())
      .filter(Boolean)
  );
  hiddenDepartmentIds.delete(DEFAULT_DEPARTMENT_ID);
  const rawDepartments = (Array.isArray(settings.departments) ? settings.departments : [])
    .filter((item) => {
      const id = String(typeof item === "string" ? "" : item?.id || "").trim();
      return id === DEFAULT_DEPARTMENT_ID;
    });
  const departments = [];
  const usedIds = new Set();
  const usedNames = new Set();
  rawDepartments.forEach((item, index) => {
    const name = String(typeof item === "string" ? item : item?.name || "").trim();
    if (!name || usedNames.has(name.toLowerCase())) return;
    let id = String(typeof item === "string" ? "" : item?.id || "").trim();
    if (id && hiddenDepartmentIds.has(id)) return;
    if (!id || usedIds.has(id)) id = `department-${index + 1}-${name.toLowerCase().replace(/[^a-zа-яё0-9]+/gi, "-")}`;
    usedIds.add(id);
    usedNames.add(name.toLowerCase());
    departments.push({ id, name });
  });
  DEFAULT_DEPARTMENTS.forEach((defaultDepartment) => {
    if (defaultDepartment.id !== DEFAULT_DEPARTMENT_ID && hiddenDepartmentIds.has(defaultDepartment.id)) return;
    if (departments.some((department) => department.name.toLowerCase() === defaultDepartment.name.toLowerCase())) return;
    let id = defaultDepartment.id;
    if (usedIds.has(id)) id = `${id}-${departments.length + 1}`;
    usedIds.add(id);
    usedNames.add(defaultDepartment.name.toLowerCase());
    departments.push({ id, name: defaultDepartment.name });
  });
  const rawDepartmentColors = settings.departmentColors && typeof settings.departmentColors === "object" && !Array.isArray(settings.departmentColors)
    ? settings.departmentColors
    : {};
  const departmentColors = {};
  const configuredDepartmentIds = new Set(departments.map((department) => department.id));
  Object.entries(rawDepartmentColors).forEach(([id, color]) => {
    const normalized = normalizeOptionalStructureColor(color);
    if (configuredDepartmentIds.has(String(id || "").trim()) && normalized) departmentColors[String(id)] = normalized;
  });
  departments.forEach((department, index) => {
    departmentColors[department.id] = normalizeStructureColor(
      departmentColors[department.id],
      DEFAULT_DEPARTMENT_COLORS[department.id] || suggestedDepartmentColor(index)
    );
  });
  const workplaceColors = {};
  Object.entries(settings.workplaceColors && typeof settings.workplaceColors === "object" && !Array.isArray(settings.workplaceColors) ? settings.workplaceColors : {}).forEach(([place, color]) => {
    const key = canonicalWorkplaceKey(place);
    const normalized = normalizeOptionalStructureColor(color);
    if (key && normalized && BASE_WORKPLACE_DEFINITIONS.some((item) => sameWorkplaceKey(item.name, key))) workplaceColors[key] = normalized;
  });
  const staffPositions = [...EMPLOYEE_POSITION_OPTIONS];
  const hiddenStaffPositionNames = new Set();
  let customSpecialRoles = normalizeCustomSpecialRoles(settings.customSpecialRoles);
  const defaultDepartmentId = departments.find((department) => department.name.toLowerCase() === "цех 7")?.id
    || departments[0].id;
  const hasScopedRoles = Number(settings.specialRoleScopeVersion || 0) >= SPECIAL_ROLE_SCOPE_VERSION
    || Object.prototype.hasOwnProperty.call(settings, "departmentSpecialRoleStates");
  const departmentSpecialRoleStates = normalizeDepartmentSpecialRoleStates(settings.departmentSpecialRoleStates, {
    migrateLegacy: !hasScopedRoles,
    defaultDepartmentId,
    customSpecialRoles,
  });
  const enabledCustomRoleIds = new Set();
  Object.values(departmentSpecialRoleStates).forEach((roleStates) => {
    Object.entries(roleStates || {}).forEach(([roleId, roleState]) => {
      if (roleState?.enabled === true && normalizeCustomSpecialRoleId(roleId)) enabledCustomRoleIds.add(roleId);
    });
  });
  customSpecialRoles = customSpecialRoles.map((role) => ({
    ...role,
    archived: !enabledCustomRoleIds.has(role.id),
  }));
  const hiddenSectionIds = [];
  const rawSections = Array.isArray(settings.sections) && (settings.sections.length || hiddenSectionIds.length)
    ? settings.sections
    : DEFAULT_WORKPLACE_SECTIONS;
  const sections = [];
  const sectionIds = new Set();
  const sectionNames = new Set();
  rawSections.forEach((item, index) => {
    const rawId = String(typeof item === "string" ? "" : item?.id || "").trim();
    const defaultSection = DEFAULT_WORKPLACE_SECTIONS.find((section) => section.id === rawId);
    if (!defaultSection) return;
    const name = String(defaultSection?.name || (typeof item === "string" ? item : item?.name || "")).trim();
    if (!name) return;
    const departmentId = departments.some((department) => department.id === item?.departmentId)
      ? item.departmentId
      : defaultDepartmentId;
    const uniqueName = `${departmentId}|${name.toLowerCase()}`;
    if (sectionNames.has(uniqueName)) return;
    let id = rawId;
    if (!id || sectionIds.has(id)) id = `section-${index + 1}-${name.toLowerCase().replace(/[^a-zа-яё0-9]+/gi, "-")}`;
    sectionIds.add(id);
    sectionNames.add(uniqueName);
    sections.push({ id, departmentId, name });
  });
  const visibleSections = sections.filter((section) => !hiddenSectionIds.includes(section.id));
  const workplaces = (Array.isArray(settings.workplaces) ? settings.workplaces : []).map((item) => {
    const normalized = typeof item === "string" ? { name: item, type: "other" } : { ...item };
    const departmentId = departments.some((department) => department.id === normalized.departmentId)
      ? normalized.departmentId
      : defaultDepartmentId;
    const knownBase = BASE_WORKPLACE_DEFINITIONS.find((base) => base.name === normalized.name);
    const sectionId = visibleSections.some((section) => section.id === normalized.sectionId && section.departmentId === departmentId)
      ? normalized.sectionId
      : (knownBase?.sectionId || "");
    return { ...normalized, departmentId, sectionId };
  });
  return {
    ...settings,
    departments,
    departmentColors,
    hiddenDepartments: [...hiddenDepartmentIds],
    sections,
    workplaces: workplaces.filter(Boolean),
    workplaceColors,
    staffPositions,
    hiddenStaffPositions: [...hiddenStaffPositionNames],
    customSpecialRoles,
    specialRoleScopeVersion: SPECIAL_ROLE_SCOPE_VERSION,
    departmentSpecialRoleStates,
    hiddenSections: hiddenSectionIds,
  };
}

function appSettings() {
  const stored = state.appSettings && typeof state.appSettings === "object" ? state.appSettings : {};
  const merged = { ...defaultAppSettings(), ...stored };
  const hasStoredScope = Number(stored.specialRoleScopeVersion || 0) >= SPECIAL_ROLE_SCOPE_VERSION
    || Object.prototype.hasOwnProperty.call(stored, "departmentSpecialRoleStates");
  if (!hasStoredScope) {
    delete merged.specialRoleScopeVersion;
    delete merged.departmentSpecialRoleStates;
  }
  return normalizeDepartmentSettings(merged);
}

function canonicalSpecialRoleId(value) {
  const role = String(value || "").trim();
  if (role === "proletchik") return "proletchik";
  if (role === "capitalRepair" || role === "capital-repair") return "capitalRepair";
  if (role === "subworker") return "subworker";
  return normalizeCustomSpecialRoleId(role);
}

function configuredCustomSpecialRoles(settings = appSettings(), options = {}) {
  const includeArchived = options.includeArchived === true;
  return normalizeCustomSpecialRoles(settings.customSpecialRoles)
    .filter((role) => includeArchived || !role.archived);
}

function specialRoleDefinitions(settings = appSettings(), options = {}) {
  const labels = {
    ...defaultAppSettings().specialWorkLabels,
    ...(settings.specialWorkLabels || {}),
  };
  return [
    { id: "proletchik", statsType: "proletchik", name: labels.proletchik, color: normalizeStructureColor(settings.proletchikColor, "#dcfce7"), builtIn: true, archived: false },
    { id: "subworker", statsType: "subworker", name: labels.subworker, color: normalizeStructureColor(settings.subworkerColor, "#ffe8e8"), builtIn: true, archived: false },
    { id: "capitalRepair", statsType: "capital-repair", name: labels.capitalRepair, color: normalizeStructureColor(settings.capitalRepairColor, "#fef3c7"), builtIn: true, archived: false },
  ];
}

function specialRoleEnabledForDepartment(roleValue, departmentId, settings = appSettings()) {
  const roleId = canonicalSpecialRoleId(roleValue);
  const cleanDepartmentId = String(departmentId || "").trim();
  if (!roleId || !cleanDepartmentId) return false;
  return settings.departmentSpecialRoleStates?.[cleanDepartmentId]?.[roleId]?.enabled === true;
}

function specialRoleDefinitionsForDepartment(departmentId, settings = appSettings()) {
  return specialRoleDefinitions(settings, { includeArchived: true })
    .filter((role) => specialRoleEnabledForDepartment(role.id, departmentId, settings));
}

function configuredDepartmentIdForWorkplace(place, settings = appSettings(), fallbackDepartmentId = "") {
  return configuredDepartmentForWorkplace(place, settings)?.id || String(fallbackDepartmentId || "").trim();
}

function specialRoleDefinitionsForWorkplace(place, settings = appSettings(), fallbackDepartmentId = "") {
  const departmentId = configuredDepartmentIdForWorkplace(place, settings, fallbackDepartmentId);
  return specialRoleDefinitionsForDepartment(departmentId, settings);
}

function specialRoleDefinitionsForIds(roleValues, settings = appSettings()) {
  const ids = new Set((roleValues || []).map(canonicalSpecialRoleId).filter((id) => BUILT_IN_SPECIAL_ROLE_IDS.includes(id)));
  const definitions = specialRoleDefinitions(settings, { includeArchived: true }).filter((role) => ids.has(role.id));
  const knownIds = new Set(definitions.map((role) => role.id));
  ids.forEach((roleId) => {
    if (knownIds.has(roleId)) return;
    const missing = specialRoleDefinition(roleId, settings, { includeArchived: true, fallback: "Специальная работа" });
    if (missing) definitions.push(missing);
  });
  return definitions;
}

function specialRoleEnabledForWorkplace(roleValue, place, settings = appSettings(), fallbackDepartmentId = "") {
  const departmentId = configuredDepartmentIdForWorkplace(place, settings, fallbackDepartmentId);
  return specialRoleEnabledForDepartment(roleValue, departmentId, settings);
}

function specialRoleDefinition(value, settings = appSettings(), options = {}) {
  const id = canonicalSpecialRoleId(value);
  if (!id) return null;
  const found = specialRoleDefinitions(settings, { includeArchived: options.includeArchived !== false })
    .find((role) => role.id === id || role.statsType === String(value || ""));
  if (found) return found;
  if (normalizeCustomSpecialRoleId(id)) {
    return { id, statsType: id, name: options.fallback || "Специальная работа", color: suggestedCustomSpecialRoleColor(0), builtIn: false, archived: true, missing: true };
  }
  return null;
}

function specialWorkLabels() {
  return {
    ...defaultAppSettings().specialWorkLabels,
    ...(appSettings().specialWorkLabels || {}),
  };
}

function specialWorkLabel(role, fallback = "") {
  const definition = specialRoleDefinition(role, appSettings(), { includeArchived: true, fallback });
  if (definition) return String(definition.name || fallback || "").trim();
  return String(specialWorkLabels()[role] || fallback || "").trim();
}

function specialWorkColor(role, fallback = "#e0e7ff") {
  return normalizeStructureColor(specialRoleDefinition(role, appSettings(), { includeArchived: true })?.color, fallback);
}

function specialRoleStyleAttribute(role) {
  const id = canonicalSpecialRoleId(role);
  if (!normalizeCustomSpecialRoleId(id)) return "";
  const color = specialWorkColor(id);
  return ` style="--special-role-color:${escapeHtml(color)};--special-role-text:${escapeHtml(structureColorText(color))}"`;
}

function refreshSpecialWorkLabels() {
  const settings = appSettings();
  const refresh = (select, automaticLabel, definitions) => {
    if (!select) return;
    const selected = select.value;
    select.innerHTML = [
      `<option value="auto">${escapeHtml(automaticLabel)}</option>`,
      ...definitions.map((role) => `<option value="${escapeHtml(role.id)}">${escapeHtml(role.name)}</option>`),
    ].join("");
    select.value = definitions.some((role) => role.id === selected) ? selected : "auto";
  };
  const shiftPlace = $("actualPlaceInput")?.value || selectedWorkplace || "";
  const workplacePlace = selectedWorkplace === "Другое место"
    ? ""
    : (["Пролётчик", "Капитальный ремонт"].includes(selectedWorkplace)
      ? ($("targetWorkplaceInput")?.value || "")
      : selectedWorkplace);
  refresh(
    $("roleInput"),
    "Определить по базе",
    specialRoleDefinitionsForWorkplace(shiftPlace, settings, selectedWorkplaceDepartmentId)
  );
  refresh(
    $("workplaceRoleInput"),
    "Штатный сотрудник",
    specialRoleDefinitionsForWorkplace(workplacePlace, settings, selectedWorkplaceDepartmentId)
  );
  if (document.body?.classList?.contains("screen-phone")) applyCompactWorkplaceLabels();
}

function applyDevicePreferences() {
  const mode = ["auto", "phone", "tablet", "desktop"].includes(devicePreferences.displayMode)
    ? devicePreferences.displayMode
    : "auto";
  document.body.dataset.displayMode = mode;
  document.body.dataset.theme = ["light", "dark", "contrast"].includes(devicePreferences.theme)
    ? devicePreferences.theme
    : "light";
  document.body.dataset.interfaceDensity = ["compact", "comfortable", "spacious"].includes(devicePreferences.interfaceDensity)
    ? devicePreferences.interfaceDensity
    : "comfortable";
  const settings = appSettings();
  document.documentElement.style.setProperty("--subworker-highlight", settings.subworkerColor || "#ffe8e8");
  document.documentElement.style.setProperty("--proletchik-highlight", settings.proletchikColor || "#dcfce7");
  document.documentElement.style.setProperty("--capital-repair-highlight", settings.capitalRepairColor || "#fef3c7");
  document.body.classList.toggle("hide-subworker-highlight", settings.highlightSubworkers === false);
  document.body.classList.toggle("hide-proletchik-highlight", settings.highlightProletchik === false);
  document.body.classList.toggle("hide-capital-repair-highlight", settings.highlightCapitalRepair === false);
  refreshSpecialWorkLabels();
}

function refreshConfiguredWorkplaces() {
  const defaults = BASE_WORKPLACE_DEFINITIONS.map((item) => item.name);
  const settings = appSettings();
  const hidden = new Set((settings.hiddenWorkplaces || []).map(String));
  const custom = (settings.workplaces || [])
    .map((item) => typeof item === "string" ? { name: item, type: "other", departmentId: DEFAULT_DEPARTMENT_ID } : item)
    .filter((item) => !item?.departmentId || item.departmentId === DEFAULT_DEPARTMENT_ID);
  const names = [...defaults, ...custom.map((item) => String(item?.name || "").trim())]
    .filter(Boolean)
    .filter((name, index, all) => all.indexOf(name) === index)
    .filter((name) => defaults.includes(name))
    .filter((name) => !hidden.has(name));
  PLACES.splice(0, PLACES.length, ...names);
  FURNACES.splice(0, FURNACES.length, ...names
    .map((name) => /^Печь\s+(\d+)$/i.exec(name)?.[1] || "")
    .filter(Boolean));
  if (!PLACES.includes(selectedWorkplace) && !["Все", "Отсутствующие"].includes(selectedWorkplace)) {
    selectedWorkplace = PLACES[0] || "Другое место";
  }
}

function stateFingerprint() {
  try {
    return JSON.stringify(state);
  } catch {
    return String(Date.now());
  }
}

function clearWorkplaceCache() {
  workplaceCache = { key: "", overviewRows: null, missingRows: null, rowsByKey: new Map() };
  workplaceListSignature = "";
}

function workplaceCacheKey(date = selectedShiftDate()) {
  return `${currentBrigade()}|${date}|${state.entries?.length || 0}|${state.absences?.length || 0}|${state.proletchikShifts?.length || 0}|${state.capitalRepairShifts?.length || 0}`;
}

function ensureWorkplaceCache(date = selectedShiftDate()) {
  const key = workplaceCacheKey(date);
  if (workplaceCache.key !== key) {
    workplaceCache = { key, overviewRows: null, missingRows: null, rowsByKey: new Map() };
  }
  return workplaceCache;
}

function sanitizeGithubSettings(settings = {}) {
  return {
    repo: String(settings.repo || "").trim(),
    updateRepo: String(settings.updateRepo || settings.repo || "").trim(),
    branch: String(settings.branch || "main").trim() || "main",
    dataPath: String(settings.dataPath || "data/tabel-data.json").trim() || "data/tabel-data.json",
    autoSync: false,
  };
}

function githubSettings() {
  let stored = {};
  try {
    stored = JSON.parse(localStorage.getItem(GITHUB_SETTINGS_KEY) || "{}");
  } catch {
    stored = {};
  }
  if (stored.token || stored.autoSync) {
    stored = sanitizeGithubSettings(stored);
    localStorage.setItem(GITHUB_SETTINGS_KEY, JSON.stringify(stored));
  }
  const config = sanitizeGithubSettings(window.TABEL_GITHUB_CONFIG || {});
  return sanitizeGithubSettings({ ...stored, ...config });
}

function saveGithubSettings(settings) {
  localStorage.setItem(GITHUB_SETTINGS_KEY, JSON.stringify(sanitizeGithubSettings(settings || {})));
}

function normalizeGithubRepo(value) {
  return String(value || "")
    .trim()
    .replace(/^https:\/\/github\.com\//i, "")
    .replace(/\/+$/g, "");
}

function githubHeaders(settings, json = false) {
  const headers = {
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
  };
  if (json) headers["Content-Type"] = "application/json";
  if (settings.token) headers.Authorization = `Bearer ${settings.token}`;
  return headers;
}

function compareVersions(left, right) {
  const parse = (value) => String(value || "").replace(/^v/i, "").split(/[.-]/).map((part) => Number(part) || 0);
  const a = parse(left);
  const b = parse(right);
  const length = Math.max(a.length, b.length);
  for (let index = 0; index < length; index += 1) {
    if ((a[index] || 0) > (b[index] || 0)) return 1;
    if ((a[index] || 0) < (b[index] || 0)) return -1;
  }
  return 0;
}

function showAppMessage(title, message, actions = []) {
  lockHorizontalScrollSoon();
  document.querySelector(".app-message-backdrop")?.remove();
  const backdrop = document.createElement("div");
  backdrop.className = "app-message-backdrop";
  const panel = document.createElement("div");
  panel.className = "app-message";
  panel.innerHTML = `
    <h3>${escapeHtml(title)}</h3>
    <p>${escapeHtml(message)}</p>
    <div class="app-message-actions"></div>
  `;
  const actionsBox = panel.querySelector(".app-message-actions");
  const close = () => {
    backdrop.remove();
    document.body.classList.remove("message-open");
    lockHorizontalScrollSoon();
  };
  const items = actions.length ? actions : [{ label: "OK", action: close }];
  for (const item of items) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = item.primary ? "" : "secondary";
    button.textContent = item.label;
    button.addEventListener("click", () => {
      close();
      item.action?.();
    });
    actionsBox.appendChild(button);
  }
  backdrop.appendChild(panel);
  document.body.classList.add("message-open");
  document.body.appendChild(backdrop);
  lockHorizontalScrollSoon();
}

function showStartupSyncOverlay(title = "Синхронизация данных") {
  setSaveStatus("saving", title === "Сохранение данных" ? "Сохраняю и синхронизирую..." : "Синхронизация при запуске...");
  document.querySelector(".startup-sync-backdrop")?.remove();
  const backdrop = document.createElement("div");
  backdrop.className = "startup-sync-backdrop";
  backdrop.innerHTML = `
    <div class="startup-sync-panel">
      <h3>${title}</h3>
      <p id="startupSyncText">Подготовка...</p>
      <div class="startup-sync-bar" aria-label="Ход синхронизации">
        <span id="startupSyncBar"></span>
      </div>
      <strong id="startupSyncPercent">0%</strong>
      <div class="startup-sync-actions"></div>
    </div>
  `;
  document.body.appendChild(backdrop);
  updateStartupSyncOverlay(1, "Проверка подключения...");
  return backdrop;
}

function updateStartupSyncOverlay(percent, text, mode = "") {
  const backdrop = document.querySelector(".startup-sync-backdrop");
  if (!backdrop) return;
  const value = Math.max(0, Math.min(100, Math.round(percent)));
  backdrop.classList.toggle("success", mode === "success");
  backdrop.classList.toggle("warning", mode === "warning");
  const bar = backdrop.querySelector("#startupSyncBar");
  const percentBox = backdrop.querySelector("#startupSyncPercent");
  const textBox = backdrop.querySelector("#startupSyncText");
  if (bar) bar.style.width = `${value}%`;
  if (percentBox) percentBox.textContent = `${value}%`;
  if (textBox) textBox.textContent = text;
}

function finishStartupSyncOverlay(message, mode = "success") {
  setSaveStatus(
    mode === "success" ? "synced" : "local",
    mode === "success" ? confirmedSyncStatusText() : "Сохранено на устройстве · сервер недоступен"
  );
  updateStartupSyncOverlay(100, message, mode);
  const backdrop = document.querySelector(".startup-sync-backdrop");
  if (!backdrop) return;
  const actions = backdrop.querySelector(".startup-sync-actions");
  if (mode === "warning") {
    actions.innerHTML = `<button type="button">Продолжить</button>`;
    actions.querySelector("button").addEventListener("click", () => backdrop.remove());
    return;
  }
  setTimeout(() => backdrop.remove(), 1300);
}

function updateStartupSync(percent, text, mode = "") {
  if (!document.querySelector(".startup-sync-backdrop")) showStartupSyncOverlay();
  updateStartupSyncOverlay(percent, text, mode);
}

function finishStartupSync(message, success = true) {
  if (!document.querySelector(".startup-sync-backdrop")) showStartupSyncOverlay();
  finishStartupSyncOverlay(message, success ? "success" : "warning");
}

function dismissStartupSyncOverlay(delayMs = 1600) {
  setTimeout(() => document.querySelector(".startup-sync-backdrop")?.remove(), delayMs);
}

function startProgressTicker(text, maxPercent = 92, intervalMs = 45) {
  let percent = 1;
  updateStartupSyncOverlay(percent, text);
  return setInterval(() => {
    percent = Math.min(maxPercent, percent + 1);
    updateStartupSyncOverlay(percent, text);
  }, intervalMs);
}

function stopProgressTicker(timer) {
  if (timer) clearInterval(timer);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function waitForSyncSlot(maxWaitMs = 20000) {
  const startedAt = Date.now();
  while (syncInProgress && Date.now() - startedAt < maxWaitMs) {
    await sleep(300);
  }
  return !syncInProgress;
}

function showEmployeeEditDialog(employee, brigadeKey, onSave) {
  document.querySelector(".employee-edit-backdrop")?.remove();
  const backdrop = document.createElement("div");
  backdrop.className = "employee-edit-backdrop";
  const places = employeeExistingWorkplaceOptions(employee.place);
  const currentPosition = employeePositionValue(employee);
  backdrop.innerHTML = `
    <form class="employee-edit-dialog">
      <h3>Редактировать сотрудника</h3>
      <p>${escapeHtml(employee.name)}<br><span>Таб. № ${escapeHtml(employee.tab)}</span></p>
      <label>
        <span>Изменить ФИО</span>
        <input id="editDialogName" type="text" value="${escapeHtml(employee.name)}" autocomplete="off" required />
      </label>
      <label>
        <span>Изменить табельный</span>
        <input id="editDialogTab" type="text" value="${escapeHtml(employee.tab)}" inputmode="numeric" autocomplete="off" required />
      </label>
      <label>
        <span>Изменить бригаду</span>
        <select id="editDialogBrigade">
          ${["1", "2", "3", "4"].map((value) => `<option value="${value}" ${value === brigadeKey ? "selected" : ""}>Бригада ${value}</option>`).join("")}
        </select>
      </label>
      <label>
        <span>Изменить рабочее место</span>
        <select id="editDialogPlace">
          ${places.map((place) => `<option value="${escapeHtml(place)}" ${place === employee.place ? "selected" : ""}>${escapeHtml(place)}</option>`).join("")}
        </select>
      </label>
      <label>
        <span>Изменить разряд</span>
        <select id="editDialogGrade">
          ${[3, 4, 5, 6, 7].map((grade) => `<option value="${grade}" ${Number(employee.grade) === grade ? "selected" : ""}>${grade}</option>`).join("")}
        </select>
      </label>
      <label>
        <span>Изменить должность</span>
        <select id="editDialogPosition" required>
          ${employeePositionOptionsHtml(currentPosition)}
        </select>
      </label>
      <div class="employee-edit-actions">
        <button type="button" class="secondary" id="editDialogCancel">Отмена</button>
        <button type="submit">Применить</button>
      </div>
    </form>
  `;
  const close = () => backdrop.remove();
  backdrop.querySelector("#editDialogCancel").addEventListener("click", close);
  backdrop.addEventListener("click", (event) => {
    if (event.target === backdrop) close();
  });
  bindEmployeePositionSuggestion(
    backdrop.querySelector("#editDialogPlace"),
    backdrop.querySelector("#editDialogPosition")
  );
  backdrop.querySelector("form").addEventListener("submit", (event) => {
    event.preventDefault();
    const name = backdrop.querySelector("#editDialogName").value.trim();
    const tab = backdrop.querySelector("#editDialogTab").value.trim();
    const targetBrigade = backdrop.querySelector("#editDialogBrigade").value;
    const place = backdrop.querySelector("#editDialogPlace").value;
    const grade = Number(backdrop.querySelector("#editDialogGrade").value);
    const position = normalizeEmployeePosition(backdrop.querySelector("#editDialogPosition").value, place);
    close();
    onSave({ name, tab, targetBrigade, place, grade, position });
  });
  document.body.appendChild(backdrop);
}

function showEmployeeAddDialog(onSave) {
  document.querySelector(".employee-edit-backdrop")?.remove();
  const backdrop = document.createElement("div");
  backdrop.className = "employee-edit-backdrop";
  const places = employeeWorkplaceOptions();
  const defaultBrigade = currentRealShiftBrigade();
  const defaultPlace = places[0] || "";
  const defaultPosition = normalizeEmployeePosition("", defaultPlace);
  backdrop.innerHTML = `
    <form class="employee-edit-dialog">
      <h3>Добавить сотрудника</h3>
      <label>
        <span>Бригада</span>
        <select id="addDialogBrigade">
          ${["1", "2", "3", "4"].map((value) => `<option value="${value}" ${value === defaultBrigade ? "selected" : ""}>Бригада ${value}</option>`).join("")}
        </select>
      </label>
      <label>
        <span>ФИО</span>
        <input id="addDialogName" type="text" autocomplete="off" required />
      </label>
      <label>
        <span>Таб. №</span>
        <input id="addDialogTab" type="text" inputmode="numeric" autocomplete="off" required />
      </label>
      <label>
        <span>Рабочее место</span>
        <select id="addDialogPlace">
          ${places.map((place) => `<option value="${escapeHtml(place)}">${escapeHtml(place)}</option>`).join("")}
        </select>
      </label>
      <label>
        <span>Разряд</span>
        <select id="addDialogGrade">
          ${[3, 4, 5, 6, 7].map((grade) => `<option value="${grade}" ${grade === 5 ? "selected" : ""}>${grade}</option>`).join("")}
        </select>
      </label>
      <label>
        <span>Должность</span>
        <select id="addDialogPosition" required>
          ${employeePositionOptionsHtml(defaultPosition)}
        </select>
      </label>
      <div class="employee-edit-actions">
        <button type="button" class="secondary" id="addDialogCancel">Отмена</button>
        <button type="submit">Добавить</button>
      </div>
    </form>
  `;
  const close = () => backdrop.remove();
  backdrop.querySelector("#addDialogCancel").addEventListener("click", close);
  backdrop.addEventListener("click", (event) => {
    if (event.target === backdrop) close();
  });
  bindEmployeePositionSuggestion(
    backdrop.querySelector("#addDialogPlace"),
    backdrop.querySelector("#addDialogPosition")
  );
  backdrop.querySelector("form").addEventListener("submit", (event) => {
    event.preventDefault();
    const brigade = backdrop.querySelector("#addDialogBrigade").value;
    const name = backdrop.querySelector("#addDialogName").value.trim();
    const tab = backdrop.querySelector("#addDialogTab").value.trim();
    const place = backdrop.querySelector("#addDialogPlace").value;
    const grade = Number(backdrop.querySelector("#addDialogGrade").value);
    const position = normalizeEmployeePosition(backdrop.querySelector("#addDialogPosition").value, place);
    onSave({ brigade, name, tab, place, grade, position, close });
  });
  document.body.appendChild(backdrop);
  backdrop.querySelector("#addDialogName").focus();
}

function mergeRemoteState(remoteState) {
  if (!remoteState || typeof remoteState !== "object") return state;
  let deletedEntryIds = mergeIdLists(remoteState.deletedEntryIds, state.deletedEntryIds);
  let deletedProletchikShiftIds = mergeIdLists(remoteState.deletedProletchikShiftIds, state.deletedProletchikShiftIds);
  let deletedCapitalRepairShiftIds = mergeIdLists(remoteState.deletedCapitalRepairShiftIds, state.deletedCapitalRepairShiftIds);
  let deletedAbsenceIds = mergeIdLists(remoteState.deletedAbsenceIds, state.deletedAbsenceIds);
  let deletedVacationIds = mergeIdLists(remoteState.deletedVacationIds, state.deletedVacationIds);
  let deletedCustomEmployeeIds = mergeIdLists(remoteState.deletedCustomEmployeeIds, state.deletedCustomEmployeeIds);
  deletedEntryIds = pruneDeletedIdsForRecentLocalItems(deletedEntryIds, state.entries);
  deletedProletchikShiftIds = pruneDeletedIdsForRecentLocalItems(deletedProletchikShiftIds, state.proletchikShifts);
  deletedCapitalRepairShiftIds = pruneDeletedIdsForRecentLocalItems(deletedCapitalRepairShiftIds, state.capitalRepairShifts);
  deletedAbsenceIds = pruneDeletedIdsForRecentLocalItems(deletedAbsenceIds, state.absences);
  deletedVacationIds = pruneDeletedIdsForRecentLocalItems(deletedVacationIds, state.vacations);
  deletedCustomEmployeeIds = pruneDeletedCustomEmployeesForActiveItems(deletedCustomEmployeeIds, state.customEmployees);
  const mergeById = (remoteItems = [], localItems = [], deletedIds = [], keyFn = syncMergeKey) => {
    const deleted = new Set(deletedIds || []);
    const isDeleted = (item) => {
      const key = syncMergeKey(item);
      const cleanTab = String(item?.tab || "").trim();
      const cleanName = normalizeName(item?.name);
      return deleted.has(String(item?.id || ""))
        || (key && deleted.has(key))
        || (cleanTab && deleted.has(`custom-tab:${cleanTab}`))
        || (cleanName && deleted.has(`custom-name:${cleanName}`));
    };
    const map = new Map();
    for (const item of remoteItems || []) {
      const key = keyFn(item);
      if (key && !isDeleted(item)) map.set(key, item);
    }
    for (const item of localItems || []) {
      const key = keyFn(item);
      if (!key || isDeleted(item)) continue;
      const existing = map.get(key);
      if (!existing || syncItemTime(item) > syncItemTime(existing)) map.set(key, item);
    }
    return [...map.values()];
  };

  const dirtyFields = dirtySyncFields(state);
  const mergeMapField = (field) => {
    const remoteValue = remoteState[field] && typeof remoteState[field] === "object" ? remoteState[field] : {};
    const localValue = state[field] && typeof state[field] === "object" ? state[field] : {};
    return dirtyFields.has(field)
      ? { ...remoteValue, ...localValue }
      : { ...localValue, ...remoteValue };
  };
  const preferLocalSettings = dirtyFields.has("appSettings");
  const mergeCustomRoleSettings = (remoteRoles, localRoles) => {
    const roles = new Map();
    normalizeCustomSpecialRoles(remoteRoles).forEach((role) => roles.set(role.id, role));
    normalizeCustomSpecialRoles(localRoles).forEach((role) => {
      const existing = roles.get(role.id);
      if (!existing) {
        roles.set(role.id, role);
        return;
      }
      const remoteTime = syncItemTime(existing);
      const localTime = syncItemTime(role);
      if (localTime > remoteTime || (localTime === remoteTime && preferLocalSettings)) roles.set(role.id, role);
    });
    return [...roles.values()];
  };
  const mergeWorkplaceRuleSettings = (remoteRules, localRules) => {
    const remoteMap = remoteRules && typeof remoteRules === "object" && !Array.isArray(remoteRules) ? remoteRules : {};
    const localMap = localRules && typeof localRules === "object" && !Array.isArray(localRules) ? localRules : {};
    const result = {};
    new Set([...Object.keys(remoteMap), ...Object.keys(localMap)]).forEach((place) => {
      const remotePlace = remoteMap[place] && typeof remoteMap[place] === "object" && !Array.isArray(remoteMap[place]) ? remoteMap[place] : {};
      const localPlace = localMap[place] && typeof localMap[place] === "object" && !Array.isArray(localMap[place]) ? localMap[place] : {};
      result[place] = preferLocalSettings
        ? { ...remotePlace, ...localPlace }
        : { ...localPlace, ...remotePlace };
    });
    return result;
  };
  const mergeDepartmentSpecialRoleSettings = (remoteStates, localStates) => {
    const remoteMap = remoteStates && typeof remoteStates === "object" && !Array.isArray(remoteStates) ? remoteStates : {};
    const localMap = localStates && typeof localStates === "object" && !Array.isArray(localStates) ? localStates : {};
    const result = {};
    new Set([...Object.keys(remoteMap), ...Object.keys(localMap)]).forEach((departmentId) => {
      const remoteDepartment = remoteMap[departmentId] && typeof remoteMap[departmentId] === "object" && !Array.isArray(remoteMap[departmentId])
        ? remoteMap[departmentId]
        : {};
      const localDepartment = localMap[departmentId] && typeof localMap[departmentId] === "object" && !Array.isArray(localMap[departmentId])
        ? localMap[departmentId]
        : {};
      const mergedDepartment = {};
      new Set([...Object.keys(remoteDepartment), ...Object.keys(localDepartment)]).forEach((roleId) => {
        const remoteRole = remoteDepartment[roleId];
        const localRole = localDepartment[roleId];
        if (remoteRole === undefined) {
          mergedDepartment[roleId] = localRole;
          return;
        }
        if (localRole === undefined) {
          mergedDepartment[roleId] = remoteRole;
          return;
        }
        const remoteTime = syncItemTime(remoteRole);
        const localTime = syncItemTime(localRole);
        mergedDepartment[roleId] = localTime > remoteTime || (localTime === remoteTime && preferLocalSettings)
          ? localRole
          : remoteRole;
      });
      if (Object.keys(mergedDepartment).length) result[departmentId] = mergedDepartment;
    });
    return result;
  };
  const mergeAppSettingsField = () => {
    const remoteSettings = remoteState.appSettings && typeof remoteState.appSettings === "object" ? remoteState.appSettings : {};
    const localSettings = state.appSettings && typeof state.appSettings === "object" ? state.appSettings : {};
    const merged = preferLocalSettings
      ? { ...remoteSettings, ...localSettings }
      : { ...localSettings, ...remoteSettings };
    const mergedDepartmentSpecialRoleStates = mergeDepartmentSpecialRoleSettings(
      remoteSettings.departmentSpecialRoleStates,
      localSettings.departmentSpecialRoleStates
    );
    const mergedCustomSpecialRoles = mergeCustomRoleSettings(remoteSettings.customSpecialRoles, localSettings.customSpecialRoles);
    const hasScopedRoleData = Object.keys(mergedDepartmentSpecialRoleStates).length > 0
      || Number(remoteSettings.specialRoleScopeVersion || 0) >= SPECIAL_ROLE_SCOPE_VERSION
      || Number(localSettings.specialRoleScopeVersion || 0) >= SPECIAL_ROLE_SCOPE_VERSION;
    if (hasScopedRoleData) {
      const roleHasExplicitState = (roleId) => Object.values(mergedDepartmentSpecialRoleStates)
        .some((roleStates) => Object.prototype.hasOwnProperty.call(roleStates || {}, roleId));
      const migrateRolesFromLegacySide = (sourceSettings) => {
        const sourceHasScope = Number(sourceSettings.specialRoleScopeVersion || 0) >= SPECIAL_ROLE_SCOPE_VERSION
          || Object.prototype.hasOwnProperty.call(sourceSettings, "departmentSpecialRoleStates");
        if (sourceHasScope) return;
        normalizeCustomSpecialRoles(sourceSettings.customSpecialRoles)
          .filter((role) => !role.archived && !roleHasExplicitState(role.id))
          .forEach((role) => {
            mergedDepartmentSpecialRoleStates[DEFAULT_DEPARTMENT_ID] = {
              ...(mergedDepartmentSpecialRoleStates[DEFAULT_DEPARTMENT_ID] || {}),
              [role.id]: { enabled: true, updatedAt: role.updatedAt || SPECIAL_ROLE_SCOPE_MIGRATION_TIME },
            };
          });
      };
      migrateRolesFromLegacySide(remoteSettings);
      migrateRolesFromLegacySide(localSettings);
    }
    return {
      ...merged,
      customSpecialRoles: mergedCustomSpecialRoles,
      ...(hasScopedRoleData ? {
        departmentSpecialRoleStates: mergedDepartmentSpecialRoleStates,
        specialRoleScopeVersion: SPECIAL_ROLE_SCOPE_VERSION,
      } : {}),
      workplaceGradeRules: mergeWorkplaceRuleSettings(remoteSettings.workplaceGradeRules, localSettings.workplaceGradeRules),
      workplaceSpecialRules: mergeWorkplaceRuleSettings(remoteSettings.workplaceSpecialRules, localSettings.workplaceSpecialRules),
    };
  };

  return {
    ...remoteState,
    ...state,
    customEmployees: mergeById(remoteState.customEmployees, state.customEmployees, deletedCustomEmployeeIds),
    employeeEdits: mergeMapField("employeeEdits"),
    dismissedTabsByBrigade: mergeMapField("dismissedTabsByBrigade"),
    entries: mergeById(remoteState.entries, state.entries, deletedEntryIds),
    absences: mergeById(remoteState.absences, state.absences, deletedAbsenceIds),
    vacations: mergeById(remoteState.vacations, state.vacations, deletedVacationIds, (item) => {
      const id = String(item?.id || "").trim();
      return id || syncMergeKey(item);
    }),
    vacationPriorities: mergeMapField("vacationPriorities"),
    vacationAllowances: mergeMapField("vacationAllowances"),
    vacationMonthLimits: mergeMapField("vacationMonthLimits"),
    vacationPolicySettings: mergeMapField("vacationPolicySettings"),
    appSettings: mergeAppSettingsField(),
    employeePhones: mergeMapField("employeePhones"),
    proletchikShifts: mergeById(remoteState.proletchikShifts, state.proletchikShifts, deletedProletchikShiftIds),
    capitalRepairShifts: mergeById(remoteState.capitalRepairShifts, state.capitalRepairShifts, deletedCapitalRepairShiftIds),
    deletedEntryIds,
    deletedProletchikShiftIds,
    deletedCapitalRepairShiftIds,
    deletedAbsenceIds,
    deletedVacationIds,
    deletedCustomEmployeeIds,
    repairPlans: mergeMapField("repairPlans"),
    repairPlansByBrigade: mergeMapField("repairPlansByBrigade"),
  };
}

function syncMergeKey(item) {
  if (!item || typeof item !== "object") return "";
  const logical = [
    item.brigade || "",
    item.startDate || item.date || item.item_date || item.month || item.year || "",
    item.endDate || "",
    item.tab || "",
    normalizeName(item.name || ""),
    item.actualPlace || item.place || item.homePlace || "",
    item.actualGrade || item.grade || "",
    item.kind || item.role || item.reason || "",
  ].map((part) => String(part || "").trim()).join("|");
  return logical.replace(/\|/g, "") ? logical : String(item.id || "");
}

function syncItemTime(item) {
  const value = item?.__syncedAt || item?.updatedAt || item?._updatedAt || item?.createdAt || "";
  const time = Date.parse(value);
  return Number.isFinite(time) ? time : 0;
}

function isRecentLocalSyncItem(item) {
  const time = syncItemTime(item);
  return time > 0 && Date.now() - time < 15 * 60 * 1000;
}

function pruneDeletedIdsForRecentLocalItems(deletedIds = [], localItems = []) {
  if (!Array.isArray(deletedIds) || !deletedIds.length) return [];
  const keepDeleted = new Set(deletedIds.map(String));
  for (const item of localItems || []) {
    if (!isRecentLocalSyncItem(item)) continue;
    keepDeleted.delete(String(item?.id || ""));
    const key = syncMergeKey(item);
    if (key) keepDeleted.delete(key);
  }
  return [...keepDeleted];
}

function pruneDeletedCustomEmployeesForActiveItems(deletedIds = [], localItems = []) {
  if (!Array.isArray(deletedIds) || !deletedIds.length) return [];
  const keepDeleted = new Set(deletedIds.map(String));
  for (const item of localItems || []) {
    if (!isRecentLocalSyncItem(item)) continue;
    customEmployeeDeletedKeys(item).forEach((key) => keepDeleted.delete(key));
    const cleanTab = String(item?.tab || "").trim();
    const cleanName = normalizeName(item?.name);
    for (const key of [...keepDeleted]) {
      const normalizedKey = normalizeName(key);
      if ((cleanTab && key.includes(`|${cleanTab}|`)) || (cleanName && normalizedKey.includes(cleanName))) {
        keepDeleted.delete(key);
      }
    }
  }
  return [...keepDeleted];
}

function syncFieldFingerprint(value) {
  try {
    return JSON.stringify(value ?? null);
  } catch {
    return "";
  }
}

function syncFieldFingerprints(source = state) {
  return Object.fromEntries(SYNC_MAP_FIELDS.map((field) => [field, syncFieldFingerprint(source?.[field])]));
}

function dirtySyncFields(source = state) {
  return new Set(Array.isArray(source?.__dirtySyncFields) ? source.__dirtySyncFields : []);
}

function ensureSyncBaseline() {
  if (state.__lastSyncedFieldFingerprints && typeof state.__lastSyncedFieldFingerprints === "object") return;
  const localTime = Date.parse(state.__localChangedAt || "") || 0;
  const remoteTime = Date.parse(state.__lastKnownRemoteUpdatedAt || "") || 0;
  state.__lastSyncedFieldFingerprints = syncFieldFingerprints(state);
  state.__dirtySyncFields = localTime > remoteTime ? [...SYNC_MAP_FIELDS] : [];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function markDirtySyncFields() {
  ensureSyncBaseline();
  const baseline = state.__lastSyncedFieldFingerprints || {};
  const dirty = dirtySyncFields();
  SYNC_MAP_FIELDS.forEach((field) => {
    if (syncFieldFingerprint(state[field]) !== baseline[field]) dirty.add(field);
  });
  state.__dirtySyncFields = [...dirty];
}

function markSyncBaseline(source = state) {
  state.__lastSyncedFieldFingerprints = syncFieldFingerprints(source);
  state.__dirtySyncFields = [];
}

function syncDeviceId() {
  let deviceId = String(localStorage.getItem(SYNC_DEVICE_KEY) || "").trim();
  if (deviceId) return deviceId;
  const randomPart = globalThis.crypto?.randomUUID?.()
    || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
  deviceId = `device-${randomPart}`;
  localStorage.setItem(SYNC_DEVICE_KEY, deviceId);
  return deviceId;
}

function shortSyncRevision(value) {
  const revision = String(value || "").trim();
  if (!revision) return "";
  const suffix = revision.split("-").filter(Boolean).pop() || revision;
  return suffix.slice(-6).toUpperCase();
}

function formatSyncMoment(value) {
  const date = new Date(value || "");
  if (!Number.isFinite(date.getTime())) return "";
  return date.toLocaleString("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).replace(",", "");
}

function confirmedSyncStatusText(meta = {}) {
  const updatedAt = meta.updatedAt || state.__lastSyncedAt || state.__lastKnownRemoteUpdatedAt;
  const revision = meta.revision || state.__lastKnownRemoteRevision;
  const moment = formatSyncMoment(updatedAt);
  const label = shortSyncRevision(revision);
  if (moment && label) return `Синхронизировано ${moment} · ревизия ${label}`;
  if (moment) return `Синхронизировано ${moment}`;
  return "Сохранено и синхронизировано";
}

function applyConfirmedSyncMeta(meta = {}) {
  const updatedAt = meta.updatedAt || new Date().toISOString();
  if (meta.revision) state.__lastKnownRemoteRevision = meta.revision;
  state.__lastKnownRemoteUpdatedAt = updatedAt;
  state.__lastSyncedAt = updatedAt;
  state.__lastSyncedDeviceId = meta.deviceId || syncDeviceId();
  state.__localChangedAt = updatedAt;
  markSyncBaseline(state);
  if (devicePreferences.localStorageEnabled !== false) localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  setSaveStatus("synced", confirmedSyncStatusText(meta));
}

const JUNE_JULY_2026_WORKPLACE_MIGRATION = "june-july-2026-custom-workplaces-v1";
const JUNE_JULY_2026_WORKPLACE_ALIASES = [
  { pattern: /^цех\s*2$/i, name: "Цех 2" },
  { pattern: /^цех\s*5$/i, name: "Цех 5" },
  { pattern: /^рсц$/i, name: "РСЦ" },
];

function migrateJuneJuly2026Workplaces(source = {}) {
  const appSettings = source.appSettings && typeof source.appSettings === "object"
    ? { ...source.appSettings }
    : {};
  const configured = Array.isArray(appSettings.workplaces) ? [...appSettings.workplaces] : [];
  const configuredNames = new Set(configured.map((item) => normalizeName(typeof item === "string" ? item : item?.name)));
  ["Цех 2", "Цех 5", "РСЦ"].forEach((name) => {
    if (!configuredNames.has(normalizeName(name))) configured.push({ name, type: "production" });
  });
  appSettings.workplaces = configured;
  appSettings.hiddenWorkplaces = (Array.isArray(appSettings.hiddenWorkplaces) ? appSettings.hiddenWorkplaces : [])
    .filter((name) => !["Цех 2", "Цех 5", "РСЦ"].includes(String(name || "").trim()));

  const entries = (Array.isArray(source.entries) ? source.entries : []).map((entry) => {
    const date = String(entry?.date || "");
    if (date < "2026-06-01" || date > "2026-07-31") return entry;
    const place = String(entry?.actualPlace || "").trim();
    const target = JUNE_JULY_2026_WORKPLACE_ALIASES.find((alias) => alias.pattern.test(place))?.name;
    return target && target !== place ? { ...entry, actualPlace: target } : entry;
  });

  return {
    ...source,
    entries,
    appSettings,
    __dataMigrations: {
      ...(source.__dataMigrations && typeof source.__dataMigrations === "object" ? source.__dataMigrations : {}),
      [JUNE_JULY_2026_WORKPLACE_MIGRATION]: true,
    },
  };
}

const BADRETDINOV_JULY_4_2026_ENTRY_ID = "historical-entry-2026-07-04-4-121283";
const BADRETDINOV_JULY_4_2026_MIGRATION = "restore-badretdinov-2026-07-04-v1";

function migrateBadretdinovJuly4Shift(source = {}) {
  const correction = {
    id: BADRETDINOV_JULY_4_2026_ENTRY_ID,
    tab: "121283",
    date: "2026-07-04",
    name: "Бадретдинов Рустам Хабилович",
    role: "melter",
    hours: 12,
    brigade: "4",
    comment: "",
    shiftKind: "regular",
    updatedAt: "2026-07-24T00:00:00.000Z",
    shiftCount: 1,
    actualGrade: 5,
    actualPlace: "Печь 42",
    scheduleShift: "",
  };
  const entries = Array.isArray(source.entries) ? [...source.entries] : [];
  const absences = Array.isArray(source.absences) ? source.absences : [];
  const hasRelevantHistory = entries.some((entry) => String(entry?.tab || "") === correction.tab)
    || absences.some((absence) => (
      String(absence?.brigade || "") === correction.brigade
      && String(absence?.date || "") === correction.date
      && String(absence?.tab || "") === correction.tab
    ));
  if (!hasRelevantHistory) return source;
  const shiftExists = entries.some((entry) => (
    String(entry?.brigade || "") === correction.brigade
    && String(entry?.date || "") === correction.date
    && String(entry?.tab || "") === correction.tab
  ));
  if (!shiftExists) entries.push(correction);

  const correctionKeys = new Set([correction.id, syncMergeKey(correction)]);
  return {
    ...source,
    entries,
    deletedEntryIds: (Array.isArray(source.deletedEntryIds) ? source.deletedEntryIds : [])
      .filter((id) => !correctionKeys.has(String(id))),
    __dataMigrations: {
      ...(source.__dataMigrations && typeof source.__dataMigrations === "object" ? source.__dataMigrations : {}),
      [BADRETDINOV_JULY_4_2026_MIGRATION]: true,
    },
  };
}

function datedWorkerKey(item) {
  const date = String(item?.date || "").trim();
  const workerKey = sameWorkerKey(item?.tab, item?.name);
  if (!date || !workerKey || workerKey === "name:") return "";
  return `${itemBrigade(item)}|${date}|${workerKey}`;
}

function isAutomaticAbsence(absence) {
  return absence?.auto === true || absence?.reason === AUTO_ABSENCE_REASON;
}

function removedItemId(item) {
  return item?.id ? String(item.id) : "";
}

function dedupeWorkEntries(items = []) {
  const kept = new Map();
  const unkeyed = [];
  const removedIds = [];

  (Array.isArray(items) ? items : []).forEach((item, index) => {
    const key = datedWorkerKey(item);
    if (!key) {
      unkeyed.push({ item, index });
      return;
    }
    const existing = kept.get(key);
    if (!existing) {
      kept.set(key, { item, index });
      return;
    }
    const candidateWins = syncItemTime(item) >= syncItemTime(existing.item);
    const loser = candidateWins ? existing.item : item;
    const loserId = removedItemId(loser);
    if (loserId) removedIds.push(loserId);
    if (candidateWins) kept.set(key, { item, index });
  });

  return {
    items: [...unkeyed, ...kept.values()]
      .sort((a, b) => a.index - b.index)
      .map(({ item }) => item),
    removedIds: [...new Set(removedIds)],
  };
}

function normalizeAbsenceRecords(source = {}, entries = source.entries) {
  const workItems = [
    ...(Array.isArray(entries) ? entries : []),
    ...(Array.isArray(source.proletchikShifts) ? source.proletchikShifts : []),
    ...(Array.isArray(source.capitalRepairShifts) ? source.capitalRepairShifts : []),
  ];
  const workedKeys = new Set(workItems.map(datedWorkerKey).filter(Boolean));
  const absences = Array.isArray(source.absences) ? source.absences : [];
  const manualKeys = new Set(
    absences
      .filter((absence) => !isAutomaticAbsence(absence) && String(absence?.reason || "").trim())
      .map(datedWorkerKey)
      .filter(Boolean)
  );
  const kept = new Map();
  const unkeyed = [];
  const removedIds = [];

  absences.forEach((absence, index) => {
    const key = datedWorkerKey(absence);
    const automatic = isAutomaticAbsence(absence);
    if (automatic && key && (workedKeys.has(key) || manualKeys.has(key))) {
      const id = removedItemId(absence);
      if (id) removedIds.push(id);
      return;
    }
    if (!key) {
      unkeyed.push({ item: absence, index });
      return;
    }
    const existing = kept.get(key);
    if (!existing) {
      kept.set(key, { item: absence, index });
      return;
    }

    const existingAutomatic = isAutomaticAbsence(existing.item);
    const candidateWins = existingAutomatic !== automatic
      ? !automatic
      : syncItemTime(absence) >= syncItemTime(existing.item);
    const loser = candidateWins ? existing.item : absence;
    const loserId = removedItemId(loser);
    if (loserId) removedIds.push(loserId);
    if (candidateWins) kept.set(key, { item: absence, index });
  });

  return {
    items: [...unkeyed, ...kept.values()]
      .sort((a, b) => a.index - b.index)
      .map(({ item }) => item),
    removedIds: [...new Set(removedIds)],
  };
}

function removeWorkedAutoAbsences(source = {}) {
  return normalizeAbsenceRecords(source).items;
}

function canonicalEmployeeNamesByTab(source = {}) {
  const namesByTab = new Map();
  const remember = (tabValue, nameValue) => {
    const tab = String(tabValue || "").trim();
    const name = String(nameValue || "").trim();
    if (tab && name) namesByTab.set(tab, name);
  };

  BASE_EMPLOYEES.forEach((employee) => remember(employee.tab, employee.name));
  [...(Array.isArray(source.customEmployees) ? source.customEmployees : [])]
    .sort((a, b) => syncItemTime(a) - syncItemTime(b))
    .forEach((employee) => remember(employee.tab, employee.name));

  Object.entries(source.employeeEdits && typeof source.employeeEdits === "object" ? source.employeeEdits : {})
    .forEach(([key, edit]) => {
      if (!edit || typeof edit !== "object") return;
      const separatorIndex = key.indexOf(":");
      const sourceTab = separatorIndex >= 0 ? key.slice(separatorIndex + 1).trim() : "";
      const targetTab = String(edit.tab || sourceTab).trim();
      const name = String(edit.name || namesByTab.get(targetTab) || namesByTab.get(sourceTab) || "").trim();
      if (!name) return;
      remember(sourceTab, name);
      remember(targetTab, name);
    });

  return namesByTab;
}

function normalizeRecordEmployeeNames(items = [], namesByTab = new Map()) {
  return (Array.isArray(items) ? items : []).map((item) => {
    const tab = String(item?.tab || "").trim();
    const canonicalName = namesByTab.get(tab);
    if (!canonicalName || normalizeName(item?.name) === normalizeName(canonicalName)) return item;
    return { ...item, name: canonicalName };
  });
}

function normalizeVacationIds(items = []) {
  const seen = new Set();
  return (Array.isArray(items) ? items : []).map((item, index) => {
    if (!item || typeof item !== "object") return item;
    const originalId = String(item.id || "").trim();
    const baseId = originalId || stableSyncId("vacations", item, index) || `vacations|part:${index + 1}`;
    let id = baseId;
    let suffix = 1;
    while (seen.has(id)) {
      suffix += 1;
      id = `${baseId}#${suffix}`;
    }
    seen.add(id);
    return originalId === id ? item : { ...item, id };
  });
}

function normalizeAppStateData(source = {}) {
  source = migrateJuneJuly2026Workplaces(source);
  source = migrateBadretdinovJuly4Shift(source);
  const canonicalNames = canonicalEmployeeNamesByTab(source);
  source = {
    ...source,
    entries: normalizeRecordEmployeeNames(source.entries, canonicalNames),
    absences: normalizeRecordEmployeeNames(source.absences, canonicalNames),
    vacations: normalizeVacationIds(normalizeRecordEmployeeNames(source.vacations, canonicalNames)),
    customEmployees: normalizeRecordEmployeeNames(source.customEmployees, canonicalNames),
    proletchikShifts: normalizeRecordEmployeeNames(source.proletchikShifts, canonicalNames),
    capitalRepairShifts: normalizeRecordEmployeeNames(source.capitalRepairShifts, canonicalNames),
  };
  const normalizedEntries = dedupeWorkEntries(source.entries);
  const normalizedAbsences = normalizeAbsenceRecords(source, normalizedEntries.items);
  const cleaned = {
    ...source,
    vacationYear: Number.isInteger(Number(source.vacationYear)) ? Number(source.vacationYear) : Number(source.year || new Date().getFullYear()),
    entries: normalizedEntries.items,
    absences: normalizedAbsences.items,
    vacations: Array.isArray(source.vacations) ? source.vacations : [],
    customEmployees: Array.isArray(source.customEmployees) ? source.customEmployees : [],
    proletchikShifts: Array.isArray(source.proletchikShifts) ? source.proletchikShifts : [],
    capitalRepairShifts: Array.isArray(source.capitalRepairShifts) ? source.capitalRepairShifts : [],
    deletedEntryIds: mergeIdLists(source.deletedEntryIds, normalizedEntries.removedIds),
    deletedAbsenceIds: mergeIdLists(source.deletedAbsenceIds, normalizedAbsences.removedIds),
    employeeEdits: source.employeeEdits && typeof source.employeeEdits === "object" ? source.employeeEdits : {},
    dismissedTabsByBrigade: source.dismissedTabsByBrigade && typeof source.dismissedTabsByBrigade === "object" ? source.dismissedTabsByBrigade : {},
    employeePhones: source.employeePhones && typeof source.employeePhones === "object" ? source.employeePhones : {},
    vacationPriorities: source.vacationPriorities && typeof source.vacationPriorities === "object" ? source.vacationPriorities : {},
    vacationAllowances: source.vacationAllowances && typeof source.vacationAllowances === "object" ? source.vacationAllowances : {},
    vacationMonthLimits: source.vacationMonthLimits && typeof source.vacationMonthLimits === "object" ? source.vacationMonthLimits : {},
    vacationPolicySettings: source.vacationPolicySettings && typeof source.vacationPolicySettings === "object" ? source.vacationPolicySettings : {},
    appSettings: normalizeDepartmentSettings(source.appSettings && typeof source.appSettings === "object" ? source.appSettings : {}),
  };
  const keepByTab = new Map();
  const keepByName = new Set();
  [...cleaned.customEmployees]
    .sort((a, b) => syncItemTime(a) - syncItemTime(b))
    .forEach((employee) => {
      const brigade = itemBrigade(employee);
      const tab = String(employee?.tab || "").trim();
      const name = normalizeName(employee?.name);
      if (!tab || !name) return;
      const existingPosition = String(employee?.position || "").replace(/\s+/g, " ").trim();
      const normalizedPosition = normalizeEmployeePosition(existingPosition, employee?.place);
      const positionMigrated = !existingPosition && Boolean(normalizedPosition);
      const normalizedEmployee = {
        ...employee,
        tab,
        name: String(employee.name || "").trim(),
        brigade,
        position: normalizedPosition,
        custom: true,
        updatedAt: positionMigrated
          ? new Date().toISOString()
          : (employee.updatedAt || employee.__syncedAt || new Date().toISOString()),
      };
      if (positionMigrated) delete normalizedEmployee.__syncedAt;
      keepByTab.set(tab, normalizedEmployee);
    });
  cleaned.customEmployees = [...keepByTab.values()].filter((employee) => {
    const nameKey = normalizeName(employee.name);
    if (!nameKey) return false;
    if (keepByName.has(nameKey)) return false;
    keepByName.add(nameKey);
    return true;
  });
  return cleaned;
}

function isDismissedInState(source, tab, brigade) {
  const cleanTab = String(tab || "").trim();
  const brigadeKey = String(brigade || BASE_STAFF_BRIGADE);
  return Array.isArray(source?.dismissedTabsByBrigade?.[brigadeKey])
    && source.dismissedTabsByBrigade[brigadeKey].map(String).includes(cleanTab);
}

function remoteStateTime(remoteState) {
  return Date.parse(remoteState?.__remoteUpdatedAt || remoteState?.updatedAt || "") || 0;
}

function remoteStateRevision(remoteState) {
  return String(remoteState?.__remoteRevision || remoteState?.syncRevision || "").trim();
}

function shouldReplaceLocalWithRemote(remoteState, mode = "auto") {
  if (!remoteState || remoteState.__serverEmpty || mode === "save" || mode === "apply") return false;
  const remoteTime = remoteStateTime(remoteState);
  if (!remoteTime) return false;
  const localChangedAt = Date.parse(state.__localChangedAt || "") || 0;
  const lastKnownRemote = Date.parse(state.__lastKnownRemoteUpdatedAt || "") || 0;
  return remoteTime > lastKnownRemote && (!localChangedAt || remoteTime >= localChangedAt);
}

function acceptRemoteState(remoteState, mode = "auto") {
  const cleanedRemote = normalizeAppStateData(remoteState || {});
  const remoteRevision = remoteStateRevision(cleanedRemote);
  const remoteDeviceId = String(cleanedRemote.__remoteDeviceId || "").trim();
  const replaceLocal = shouldReplaceLocalWithRemote(cleanedRemote, mode);
  const previousDirtyFields = [...dirtySyncFields(state)];
  if (replaceLocal) {
    state = cleanedRemote;
  } else {
    state = normalizeAppStateData(mergeRemoteState(cleanedRemote));
  }
  const remoteStamp = cleanedRemote.__remoteUpdatedAt || cleanedRemote.updatedAt || new Date().toISOString();
  state.__lastKnownRemoteUpdatedAt = remoteStamp;
  state.__lastKnownRemoteRevision = remoteRevision;
  state.__lastSyncedAt = remoteStamp;
  state.__lastSyncedDeviceId = remoteDeviceId;
  state.__localChangedAt = remoteStamp;
  state.__lastSyncedFieldFingerprints = syncFieldFingerprints(cleanedRemote);
  state.__dirtySyncFields = replaceLocal ? [] : previousDirtyFields;
  delete state.__remoteUpdatedAt;
  delete state.__remoteRevision;
  delete state.__remoteDeviceId;
  if (document.body?.dataset && typeof document.documentElement?.style?.setProperty === "function") {
    applyDevicePreferences();
  } else {
    refreshSpecialWorkLabels();
  }
}

function mergeIdLists(...lists) {
  return [...new Set(lists.flatMap((list) => Array.isArray(list) ? list.filter(Boolean) : []))];
}

function rememberDeletedId(field, id) {
  if (!id) return;
  state[field] = mergeIdLists(state[field], [id]);
}

function forgetDeletedId(field, id) {
  if (!id) return;
  const cleanId = String(id);
  state[field] = (state[field] || []).filter((item) => String(item) !== cleanId);
}

function rememberDeletedEntry(entry) {
  if (!entry) return;
  rememberDeletedId("deletedEntryIds", entry.id);
  rememberDeletedId("deletedEntryIds", syncMergeKey(entry));
}

function forgetDeletedEntry(entry) {
  if (!entry) return;
  forgetDeletedId("deletedEntryIds", entry.id);
  forgetDeletedId("deletedEntryIds", syncMergeKey(entry));
}

function customEmployeeDeletedKeys(employee) {
  if (!employee) return [];
  const keys = [employee.id, syncMergeKey(employee)];
  const cleanTab = String(employee.tab || "").trim();
  const cleanName = normalizeName(employee.name);
  if (cleanTab) keys.push(`custom-tab:${cleanTab}`);
  if (cleanName) keys.push(`custom-name:${cleanName}`);
  return keys.filter(Boolean).map(String);
}

function rememberDeletedCustomEmployee(employee) {
  customEmployeeDeletedKeys(employee).forEach((key) => rememberDeletedId("deletedCustomEmployeeIds", key));
}

function forgetDeletedCustomEmployee(employee) {
  customEmployeeDeletedKeys(employee).forEach((key) => forgetDeletedId("deletedCustomEmployeeIds", key));
  const cleanTab = String(employee?.tab || "").trim();
  const cleanName = normalizeName(employee?.name);
  state.deletedCustomEmployeeIds = (state.deletedCustomEmployeeIds || []).filter((key) => {
    const cleanKey = String(key || "");
    const normalizedKey = normalizeName(cleanKey);
    if (cleanTab && cleanKey.includes(`|${cleanTab}|`)) return false;
    if (cleanName && normalizedKey.includes(cleanName)) return false;
    return true;
  });
}

function normalizeName(value) {
  return String(value || "").replace(/\s+/g, " ").trim().toLowerCase();
}

function currentBrigade() {
  return String(state.brigade || BASE_STAFF_BRIGADE);
}

function selectedShiftDate() {
  return state.selectedShiftDate || $("workplaceDateInput")?.value || $("dateInput")?.value || "";
}

function selectedShiftKindForDate(dateValue = selectedShiftDate()) {
  if (
    state.selectedShiftDate === dateValue
    && state.selectedShiftKind
    && startShiftForDate(dateValue, state.selectedShiftKind) === currentBrigade()
  ) {
    return state.selectedShiftKind;
  }
  return inferShiftKindForDate(dateValue);
}

function inferShiftKindForDate(dateValue = selectedShiftDate()) {
  if (dateValue && startShiftForDate(dateValue, "day") === currentBrigade()) return "day";
  if (dateValue && startShiftForDate(dateValue, "night") === currentBrigade()) return "night";
  return state.selectedShiftKind || "day";
}

function itemBrigade(item) {
  return String(item?.brigade || BASE_STAFF_BRIGADE);
}

function employeeEditKey(employee) {
  return `${itemBrigade(employee)}:${employee.tab}`;
}

function employeeEditSourceKey(brigade, tab) {
  const brigadeKey = String(brigade || BASE_STAFF_BRIGADE);
  const cleanTab = String(tab || "").trim();
  const directKey = `${brigadeKey}:${cleanTab}`;
  if ((state.employeeEdits || {})[directKey]) return directKey;
  const prefix = `${brigadeKey}:`;
  const found = Object.entries(state.employeeEdits || {})
    .find(([key, edit]) => key.startsWith(prefix) && String(edit?.tab || "").trim() === cleanTab);
  return found?.[0] || directKey;
}

function moveEmployeePhoneKey(oldBrigade, oldTab, oldName, newBrigade, newTab, newName) {
  const oldKey = `${String(oldBrigade || BASE_STAFF_BRIGADE)}:${String(oldTab || normalizeName(oldName)).trim()}`;
  const newKey = `${String(newBrigade || BASE_STAFF_BRIGADE)}:${String(newTab || normalizeName(newName)).trim()}`;
  if (oldKey === newKey || !state.employeePhones?.[oldKey]) return;
  state.employeePhones = { ...(state.employeePhones || {}) };
  if (!state.employeePhones[newKey]) state.employeePhones[newKey] = state.employeePhones[oldKey];
  delete state.employeePhones[oldKey];
}

function applyEmployeeEdit(employee) {
  const edit = state.employeeEdits?.[employeeEditKey(employee)];
  if (!edit) return { ...employee, position: employeePositionValue(employee) };
  const name = edit.name || employee.name;
  const tab = edit.tab || employee.tab;
  const place = edit.place || employee.place;
  const grade = Number(edit.grade || employee.grade);
  const position = normalizeEmployeePosition(edit.position || employee.position, place);
  return {
    ...employee,
    name,
    tab,
    place,
    grade,
    position,
    code: placeCode(place),
    section: employeeSectionForPlace(place),
    role: employeeRoleForPlace(place),
    edited: true,
  };
}

function touchEmployeeRecord(employee, changes = {}) {
  const next = {
    ...(employee || {}),
    ...changes,
    updatedAt: new Date().toISOString(),
  };
  delete next.__syncedAt;
  delete next._updatedAt;
  return next;
}

function updateEmployeeReferences(oldEmployee, oldBrigade, nextEmployee) {
  const oldKey = sameWorkerKey(oldEmployee?.tab, oldEmployee?.name);
  const brigadeKey = String(oldBrigade || itemBrigade(oldEmployee));
  const nextName = String(nextEmployee?.name || "").trim();
  const nextTab = String(nextEmployee?.tab || "").trim();
  if (!oldKey || (!nextName && !nextTab)) return false;

  let changed = false;
  state.entries = (state.entries || []).map((entry) => {
    if (itemBrigade(entry) !== brigadeKey) return entry;
    if (sameWorkerKey(entry.tab, entry.name) !== oldKey) return entry;
    changed = true;
    return {
      ...entry,
      name: nextName || entry.name,
      tab: nextTab || entry.tab,
      updatedAt: new Date().toISOString(),
    };
  });
  return changed;
}

function belongsToCurrentBrigade(item) {
  return itemBrigade(item) === currentBrigade();
}

function addCurrentBrigade(item) {
  return { ...item, brigade: currentBrigade() };
}

function currentDismissedTabs() {
  if (state.dismissedTabsByBrigade?.[currentBrigade()]) return state.dismissedTabsByBrigade[currentBrigade()];
  return currentBrigade() === BASE_STAFF_BRIGADE ? state.dismissedTabs || [] : [];
}

function setCurrentDismissedTabs(tabs) {
  state.dismissedTabsByBrigade = { ...(state.dismissedTabsByBrigade || {}), [currentBrigade()]: tabs };
  if (currentBrigade() === BASE_STAFF_BRIGADE) state.dismissedTabs = tabs;
}

function dismissedTabsForBrigade(brigade) {
  const brigadeKey = String(brigade || BASE_STAFF_BRIGADE);
  if (state.dismissedTabsByBrigade?.[brigadeKey]) return state.dismissedTabsByBrigade[brigadeKey];
  return brigadeKey === BASE_STAFF_BRIGADE ? state.dismissedTabs || [] : [];
}

function setDismissedTabsForBrigade(brigade, tabs) {
  const brigadeKey = String(brigade || BASE_STAFF_BRIGADE);
  state.dismissedTabsByBrigade = { ...(state.dismissedTabsByBrigade || {}), [brigadeKey]: tabs };
  if (brigadeKey === BASE_STAFF_BRIGADE) state.dismissedTabs = tabs;
}

function isDismissedInBrigade(tab, brigade) {
  return dismissedTabsForBrigade(brigade).includes(String(tab || "").trim());
}

function isDismissedEmployeeRecord(employee, brigade = itemBrigade(employee)) {
  if (!employee) return false;
  if (employee.custom) return false;
  return isDismissedInBrigade(employee.tab, brigade);
}

function allEmployeesForBrigade(brigade) {
  const brigadeKey = String(brigade || BASE_STAFF_BRIGADE);
  const base = BASE_EMPLOYEES
    .map((employee) => applyEmployeeEdit({ ...employee, brigade: itemBrigade(employee) }))
    .filter((employee) => itemBrigade(employee) === brigadeKey);
  const custom = (state.customEmployees || []).filter((employee) => itemBrigade(employee) === brigadeKey).map(applyEmployeeEdit);
  return [...base, ...custom].sort(compareEmployeeWorkplaceGrade);
}

function isCustomEmployeeInBrigade(tab, brigade) {
  const brigadeKey = String(brigade || BASE_STAFF_BRIGADE);
  return (state.customEmployees || []).some((employee) => employee.tab === String(tab || "").trim() && itemBrigade(employee) === brigadeKey);
}

function unifiedEmployees() {
  const base = BASE_EMPLOYEES.map((employee) => applyEmployeeEdit({ ...employee, brigade: itemBrigade(employee) }));
  return [...base, ...(state.customEmployees || []).map(applyEmployeeEdit)]
    .sort((a, b) => itemBrigade(a).localeCompare(itemBrigade(b), "ru") || compareEmployeeWorkplaceGrade(a, b));
}

function uniqueActiveEmployees(employees) {
  const selected = [];
  const seenTabs = new Set();
  const seenCustomNames = new Set();
  const ordered = [...(employees || [])].sort((a, b) => Number(Boolean(b.custom)) - Number(Boolean(a.custom)));
  ordered.forEach((employee) => {
    const tabKey = String(employee.tab || "").trim();
    const nameKey = normalizeName(employee.name);
    if (tabKey && seenTabs.has(tabKey)) return;
    if (!employee.custom && nameKey && seenCustomNames.has(nameKey)) return;
    selected.push(employee);
    if (tabKey) seenTabs.add(tabKey);
    if (employee.custom && nameKey) seenCustomNames.add(nameKey);
  });
  return selected.sort((a, b) => itemBrigade(a).localeCompare(itemBrigade(b), "ru") || compareEmployeeWorkplaceGrade(a, b));
}

function activeUnifiedEmployees() {
  return uniqueActiveEmployees(unifiedEmployees().filter((employee) => !isDismissedEmployeeRecord(employee, itemBrigade(employee))));
}

function unifiedEmployeeByName(name) {
  const normalized = normalizeName(name);
  const matches = unifiedEmployees().filter((employee) => normalizeName(employee.name) === normalized);
  return matches.find((employee) => itemBrigade(employee) === currentBrigade() && !isDismissedEmployeeRecord(employee, itemBrigade(employee)))
    || matches.find((employee) => !isDismissedEmployeeRecord(employee, itemBrigade(employee)))
    || matches[0];
}

function unifiedEmployeeByTab(tab) {
  const cleanTab = String(tab || "").trim();
  const matches = unifiedEmployees().filter((employee) => employee.tab === cleanTab);
  return matches.find((employee) => itemBrigade(employee) === currentBrigade() && !isDismissedEmployeeRecord(employee, itemBrigade(employee)))
    || matches.find((employee) => !isDismissedEmployeeRecord(employee, itemBrigade(employee)))
    || matches[0];
}

function employeeByName(name) {
  const normalized = normalizeName(name);
  return currentEmployees().find((employee) => normalizeName(employee.name) === normalized);
}

function employeeByTab(tab) {
  return currentEmployees().find((employee) => employee.tab === String(tab || "").trim());
}

function allEmployees() {
  return allEmployeesForBrigade(currentBrigade());
}

function currentEntries() {
  return (state.entries || []).filter(belongsToCurrentBrigade);
}

function currentMonthEntries() {
  return currentEntries().filter(entryBelongsToSelectedMonth);
}

function currentAbsences() {
  return (state.absences || []).filter(belongsToCurrentBrigade);
}

function currentProletchikShifts() {
  return (state.proletchikShifts || []).filter(belongsToCurrentBrigade);
}

function currentCapitalRepairShifts() {
  return (state.capitalRepairShifts || []).filter(belongsToCurrentBrigade);
}

function currentRepairPlans() {
  if (state.repairPlansByBrigade?.[currentBrigade()]) return state.repairPlansByBrigade[currentBrigade()];
  return currentBrigade() === BASE_STAFF_BRIGADE ? state.repairPlans || {} : {};
}

function setCurrentRepairPlans(plans) {
  state.repairPlansByBrigade = { ...(state.repairPlansByBrigade || {}), [currentBrigade()]: plans };
  if (currentBrigade() === BASE_STAFF_BRIGADE) state.repairPlans = plans;
}

function currentEmployees() {
  return uniqueActiveEmployees(allEmployees().filter((employee) => !isDismissedEmployeeRecord(employee, currentBrigade())));
}

function activeEmployeesForBrigade(brigade) {
  return uniqueActiveEmployees(allEmployeesForBrigade(brigade).filter((employee) => !isDismissedEmployeeRecord(employee, brigade)));
}

function vacationBrigade() {
  if ($("vacationBrigadeInput")) return String($("vacationBrigadeInput").value || "");
  return String(state.vacationBrigade ?? "");
}

function isAllVacationBrigades() {
  return vacationBrigade() === "";
}

function vacationEmployees() {
  const employees = isAllVacationBrigades() ? activeUnifiedEmployees() : activeEmployeesForBrigade(vacationBrigade());
  const departmentId = DEFAULT_DEPARTMENT_ID;
  const sectionId = String($("vacationSectionInput")?.value || state.vacationSectionId || "");
  if (!departmentId || !sectionId) return employees;
  const places = new Set(settingsWorkplaceRows()
    .filter((item) => item.departmentId === departmentId && item.sectionId === sectionId)
    .map((item) => item.name));
  return employees.filter((employee) => places.has(employee.place));
}

function belongsToVacationBrigade(item) {
  if (isAllVacationBrigades()) return true;
  return itemBrigade(item) === vacationBrigade();
}

function shiftStatusForEmployee(employee, date = selectedShiftDate(), brigade = itemBrigade(employee)) {
  const employeeBrigade = itemBrigade(employee);
  const currentSlot = currentStartShiftSlot();
  const statusKind = state.selectedShiftDate === date && state.selectedShiftKind
    ? state.selectedShiftKind
    : (currentSlot.dateValue === date ? currentSlot.kind : "day");
  const shiftBrigade = startShiftForDate(date, statusKind);
  if (!date) return { label: "Дата не выбрана", className: "warn" };
  if (employeeBrigade !== shiftBrigade) return { label: "Выходной", className: "weekend" };
  if (!brigadeWorksOnDate(date, shiftBrigade)) return { label: "Выходной", className: "weekend" };

  const key = absenceKey(employee);
  const worked = [
    ...(state.entries || []),
    ...(state.proletchikShifts || []),
    ...(state.capitalRepairShifts || []),
  ].some((item) => itemBrigade(item) === shiftBrigade && item.date === date && absenceKey(item) === key);
  if (worked) return { label: "Работает", className: "ok" };

  const absence = absenceForEmployee(date, employee, shiftBrigade);
  const reason = absence?.reason && absence.reason !== AUTO_ABSENCE_REASON ? absence.reason : "";
  if (reason) return { label: reason, className: "absence" };
  return { label: "Отсутствует", className: "warn" };
}

function absenceForEmployee(date, employee, brigade = currentBrigade()) {
  const key = absenceKey(employee);
  const matches = (state.absences || []).filter((item) =>
    itemBrigade(item) === String(brigade || currentBrigade())
    && item.date === date
    && absenceKey(item) === key
  );
  return matches.find((item) => item.reason && item.reason !== AUTO_ABSENCE_REASON) || matches[0];
}

function isCustomEmployee(tab) {
  return (state.customEmployees || []).some((employee) => employee.tab === String(tab || "").trim() && itemBrigade(employee) === currentBrigade());
}

function isDismissed(tab) {
  return currentDismissedTabs().includes(String(tab || "").trim());
}

function placeCode(place) {
  if (place === "РМ") return "РМ";
  const match = String(place || "").match(/\d+/);
  return match ? match[0] : place;
}

function printablePlace(place) {
  const text = String(place || "").trim();
  if (!text) return "";
  if (text === "РМ") return "РМ";
  if (/^печь\s*\d+$/i.test(text)) return placeCode(text);
  if (/^\d+$/.test(text) && !FURNACES.includes(text)) return `цех ${text}`;
  if (/^цех\s*\d+$/i.test(text)) return text.replace(/^цех\s*/i, "цех ");
  return text;
}

function isCustomTransferPlace(place) {
  const code = String(placeCode(place) || "");
  return Boolean(code) && code !== "РМ" && !FURNACES.includes(code);
}

function transferPlaceGroupValue(place) {
  return isCustomTransferPlace(place) ? printablePlace(place).toLowerCase() : String(place || "");
}

function mergeGradeLabel(previous, current) {
  const values = String(previous || "")
    .split("/")
    .concat(String(current || "").split("/"))
    .map((value) => value.trim())
    .filter(Boolean);
  return [...new Set(values)].join("/");
}

function isCastingPlaceValue(value) {
  const code = String(placeCode(value) || "");
  return Boolean(code) && !FURNACES.includes(code) && !/^\d+$/.test(code);
}

function isFurnacePlaceValue(value) {
  const code = String(placeCode(value) || "");
  return FURNACES.includes(code);
}

function canonicalWorkplaceKey(value) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  if (!text) return "";
  if (/^рм$/i.test(text) || /^разлив/i.test(text)) return "РМ";
  const furnaceMatch = /^печь\s*(\d+)$/i.exec(text);
  if (furnaceMatch) return `Печь ${Number(furnaceMatch[1])}`;
  const code = String(placeCode(text) || "").trim();
  if (FURNACES.includes(code)) return `Печь ${code}`;
  return text;
}

function sameWorkplaceKey(left, right) {
  return canonicalWorkplaceKey(left) === canonicalWorkplaceKey(right);
}

function emptyGradeRuleSet() {
  return Object.fromEntries([3, 4, 5, 6, 7].map((grade) => [String(grade), { minimum: 0, maximum: null }]));
}

function defaultGradeRulesForWorkplace(place) {
  const rules = emptyGradeRuleSet();
  const key = canonicalWorkplaceKey(place);
  if (/^Печь\s+\d+$/i.test(key)) {
    rules["7"] = { minimum: 1, maximum: 1 };
    rules["6"] = { minimum: 2, maximum: 2 };
  } else if (key === "РМ" || /^разлив/i.test(String(place || ""))) {
    rules["4"] = { minimum: 4, maximum: 4 };
    rules["3"] = { minimum: 0, maximum: 4 };
  }
  return rules;
}

function normalizeGradeRule(rule, fallback) {
  const minimum = Math.max(0, Number.isFinite(Number(rule?.minimum)) ? Number(rule.minimum) : Number(fallback.minimum || 0));
  const hasMaximum = Boolean(rule) && Object.prototype.hasOwnProperty.call(rule, "maximum");
  const rawMaximum = rule?.maximum;
  const maximum = !hasMaximum
    ? fallback.maximum
    : (rawMaximum === null || rawMaximum === "" ? null : Math.max(0, Number(rawMaximum)));
  return {
    minimum,
    maximum: maximum === null || maximum === undefined ? null : Math.max(minimum, maximum),
  };
}

function workplaceGradeRuleSet(place) {
  const key = canonicalWorkplaceKey(place);
  const defaults = defaultGradeRulesForWorkplace(key);
  const configured = appSettings().workplaceGradeRules?.[key] || appSettings().workplaceGradeRules?.[place] || {};
  return Object.fromEntries(Object.entries(defaults).map(([grade, fallback]) => [
    grade,
    normalizeGradeRule(configured[grade], fallback),
  ]));
}

function emptySpecialRuleSet(settings = appSettings(), departmentId = "") {
  const definitions = departmentId
    ? specialRoleDefinitionsForDepartment(departmentId, settings)
    : specialRoleDefinitions(settings);
  return Object.fromEntries(definitions.map((role) => [
    role.id,
    role.id === "proletchik"
      ? { minimum: 0, maximum: 1 }
      : { minimum: 0, maximum: null },
  ]));
}

function workplaceSpecialRuleSet(place) {
  const settings = appSettings();
  const key = canonicalWorkplaceKey(place);
  const departmentId = configuredDepartmentIdForWorkplace(key, settings);
  const defaults = emptySpecialRuleSet(settings, departmentId);
  const configured = settings.workplaceSpecialRules?.[key] || settings.workplaceSpecialRules?.[place] || {};
  return Object.fromEntries(Object.entries(defaults).map(([role, fallback]) => [
    role,
    normalizeGradeRule(configured[role], fallback),
  ]));
}

function normalizedSpecialRole(entryOrRole) {
  if (typeof entryOrRole === "object" && entryOrRole) {
    const explicitRole = canonicalSpecialRoleId(entryOrRole.role);
    if (explicitRole && explicitRole !== "subworker") return explicitRole;
    if (entryIsSubworker(entryOrRole)) return "subworker";
    return "";
  }
  return canonicalSpecialRoleId(entryOrRole);
}

function validateWorkplaceGradeLimit(date, place, grade) {
  if (appSettings().enforceGradeMaximums === false) return true;
  if (!date || !place) return true;
  const numericGrade = Number(grade || 0);
  const rule = workplaceGradeRuleSet(place)[String(numericGrade)];
  if (!rule || rule.maximum === null) return true;
  const rows = currentEntries().filter((entry) =>
    entry.date === date
    && sameWorkplaceKey(entry.actualPlace, place)
    && Number(entry.actualGrade || 0) === numericGrade
  );
  if (rows.length < rule.maximum) return true;
  const names = rows.map((entry) => entry.name).filter(Boolean).join(", ");
  alert(`${canonicalWorkplaceKey(place)}: нельзя добавить ${numericGrade} разряд.\nДопускается не более ${rule.maximum} ${pluralRu(rule.maximum, "человека", "человек", "человек")}.${names ? `\nУже добавлены: ${names}` : ""}`);
  return false;
}

function validateWorkplaceSpecialLimit(date, place, role) {
  const settings = appSettings();
  const normalizedRole = normalizedSpecialRole(role);
  if (!normalizedRole) return true;
  if (!specialRoleEnabledForWorkplace(normalizedRole, place, settings, selectedWorkplaceDepartmentId)) {
    const label = specialWorkLabel(normalizedRole, normalizedRole);
    const department = configuredDepartmentForWorkplace(place, settings)
      || settings.departments.find((item) => item.id === selectedWorkplaceDepartmentId);
    alert(`«${label}» не используется в подразделении «${department?.name || "выбранного рабочего места"}». Выберите другую роль или добавьте её в настройках.`);
    return false;
  }
  if (settings.enforceSpecialRoleMaximums === false || !date || !place) return true;
  const rule = workplaceSpecialRuleSet(place)[normalizedRole];
  if (!rule || rule.maximum === null) return true;
  const rows = currentEntries().filter((entry) =>
    entry.date === date
    && sameWorkplaceKey(entry.actualPlace, place)
    && normalizedSpecialRole(entry) === normalizedRole
  );
  if (rows.length < rule.maximum) return true;
  const names = rows.map((entry) => entry.name).filter(Boolean).join(", ");
  const label = specialWorkLabel(normalizedRole, normalizedRole);
  alert(`${canonicalWorkplaceKey(place)}: нельзя добавить «${label}».\nДопускается не более ${rule.maximum} ${pluralRu(rule.maximum, "человека", "человек", "человек")}.${names ? `\nУже добавлены: ${names}` : ""}`);
  return false;
}

function staffAdminHash(value) {
  const text = String(value || "");
  let hash = 0x811c9dc5;
  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return hash.toString(16).padStart(8, "0");
}

function requireStaffAdmin(action = "изменения штата") {
  const password = prompt(`Введите пароль администратора для действия: ${action}`);
  if (password === null) return false;
  const configuredHash = appSettings().adminPinHash || localStorage.getItem(STAFF_ADMIN_PIN_HASH_KEY) || STAFF_ADMIN_PIN_HASH;
  if (staffAdminHash(String(password).trim()) !== configuredHash) {
    alert("Неверный пароль администратора. Действие отменено.");
    return false;
  }
  return true;
}

function compareEmployeeWorkplaceGrade(a, b) {
  return placeSortOrder(a.place) - placeSortOrder(b.place)
    || String(a.place || "").localeCompare(String(b.place || ""), "ru")
    || Number(b.grade || 0) - Number(a.grade || 0)
    || String(a.name || "").localeCompare(String(b.name || ""), "ru");
}

function hoursForKind(kind, count = 1) {
  const perShift = kind === "repair" ? 11.5 : 12;
  return Number((perShift * Number(count || 0)).toFixed(1));
}

function isAverageShift(entry) {
  return entryOrdinaryShiftKind(entry, "average");
}

function entryOrdinaryShiftKind(entry, kind) {
  return !normalizedSpecialRole(entry) && entry?.shiftKind === kind;
}

function entryWorkedHours(entry) {
  return Number(entry.hours || hoursForKind(entry.shiftKind, entry.shiftCount || 1));
}

function entryBalanceHours(entry) {
  if (entryOrdinaryShiftKind(entry, "repair") || entryOrdinaryShiftKind(entry, "warmup")) {
    const nominal = 12 * Number(entry.shiftCount || 1);
    return Number(Math.max(0, nominal - entryLowPayLossHours(entry)).toFixed(1));
  }
  return entryWorkedHours(entry);
}

function entryLowPayLossHours(entry) {
  return entryOrdinaryShiftKind(entry, "repair") || entryOrdinaryShiftKind(entry, "warmup") ? entryWorkedHours(entry) : 0;
}

function entryBelongsToSelectedMonth(entry) {
  const date = new Date(String(entry.date) + "T00:00:00");
  return date.getFullYear() === Number(state.year) && date.getMonth() === Number(state.month);
}

function plannedLowPayLossHours(place) {
  const code = placeCode(place);
  if (!FURNACES.includes(String(code))) return 0;
  const plan = currentRepairPlans()[code] || { repair: 0, warmup: 0 };
  return Number((Number(plan.repair || 0) * 11.5 + Number(plan.warmup || 0) * 12).toFixed(1));
}

function placePayBalance(place, options = {}) {
  const code = placeCode(place);
  const entries = currentEntries().filter((entry) => {
    if (placeCode(entry.actualPlace) !== code) return false;
    if (!entryBelongsToSelectedMonth(entry)) return false;
    if (options.excludeGeneratedCapitalRepair && entry.generatedCapitalRepair) return false;
    if (options.excludeGeneratedProletchik && entry.generatedProletchik) return false;
    return true;
  });
  const worked = Number(entries.reduce((sum, entry) => sum + entryWorkedHours(entry), 0).toFixed(1));
  const lowPayLoss = Number(entries.reduce((sum, entry) => sum + entryLowPayLossHours(entry), 0).toFixed(1));
  const productive = Number(entries.reduce((sum, entry) => sum + entryBalanceHours(entry), 0).toFixed(1));
  const plannedLoss = plannedLowPayLossHours(place);
  const additionalPlannedLoss = Math.max(0, plannedLoss - lowPayLoss);
  const forecastProductive = Number(Math.max(0, productive - additionalPlannedLoss).toFixed(1));
  return { worked, productive, lowPayLoss, plannedLoss, forecastProductive };
}

function previousMonthRange() {
  const month = Number(state.month || 0);
  const year = Number(state.year || new Date().getFullYear());
  const start = new Date(year, month - 1, 1);
  const end = new Date(year, month, 0);
  return { start: dateInputValue(start), end: dateInputValue(end) };
}

function proletchikCarryoverCredit(place) {
  const code = placeCode(place);
  if (!FURNACES.includes(String(code))) return 0;
  const range = previousMonthRange();
  const rows = buildStatsRows(
    currentEntries().filter((entry) => entry.date >= range.start && entry.date <= range.end)
  ).filter((row) => FURNACES.map((item) => `Печь ${item}`).includes(row.place));
  if (!rows.length) return 0;
  const target = rows.find((row) => placeCode(row.place) === String(code));
  if (!target || !target.proletchikHours) return 0;
  const average = rows.reduce((sum, row) => sum + row.finalBalanceHours, 0) / rows.length;
  const overage = Number(Math.max(0, target.finalBalanceHours - average).toFixed(1));
  return Number(Math.min(overage, target.proletchikHours).toFixed(1));
}

function classifyEntry(entry) {
  const employee = employeeByTab(entry.tab) || employeeByName(entry.name);
  const unifiedEmployee = unifiedEmployeeByTab(entry.tab) || unifiedEmployeeByName(entry.name);
  const actualCode = placeCode(entry.actualPlace);
  const actualGrade = Number(entry.actualGrade);
  const reasons = [];

  if (!employee && unifiedEmployee) {
    reasons.push(entryIsSubworker(entry)
      ? `подработчик из бригады ${itemBrigade(unifiedEmployee)}`
      : `сотрудник из бригады ${itemBrigade(unifiedEmployee)}`);
  } else if (!employee) {
    reasons.push(entryIsSubworker(entry)
      ? "подработчик отсутствует в штатной базе"
      : "сотрудник отсутствует в штатной базе");
  }

  if (employee) {
    if (employee.role === "caster") {
      if (employee.grade !== actualGrade) reasons.push("машинист РМ работал не по своему разряду");
      if (actualCode !== "РМ") reasons.push("машинист РМ работал в другом месте");
    } else {
      if (employee.code !== actualCode) reasons.push("работал не на своей печи");
      if (employee.grade !== actualGrade) reasons.push("работал не по своему разряду");
    }
  }

  return {
    employee,
    mustTransfer: reasons.length > 0,
    reasons,
    basePlace: employee ? employee.place : (unifiedEmployee ? `бригада ${itemBrigade(unifiedEmployee)}, ${unifiedEmployee.place}` : "нет в базе"),
    baseGrade: employee ? employee.grade : (unifiedEmployee ? unifiedEmployee.grade : ""),
  };
}

function workplaceRowClass(row) {
  const role = String(row?.role || row?.type || "").toLowerCase();
  const kind = String(row?.kind || "").toLowerCase();
  if (normalizeCustomSpecialRoleId(row?.role)) return "workplace-row-custom";
  if (row?.isSubworker || role === "subworker" || kind.includes("подработка") || kind.includes("подработчик")) {
    return "workplace-row-subworker";
  }
  if (
    role === "capitalrepair" ||
    kind.includes("кап. ремонт") ||
    kind.includes("кап ремонт") ||
    kind.includes("капитальный ремонт")
  ) {
    return "workplace-row-capital-repair";
  }
  if (
    role === "proletchik" ||
    kind.includes("пролётчик") ||
    kind.includes("пролетчик")
  ) {
    return "workplace-row-special";
  }
  return "";
}

function entryCurrentBrigadeEmployee(entry) {
  return employeeByTab(entry?.tab) || employeeByName(entry?.name);
}

function entryIsSubworker(entry) {
  if (!entry) return false;
  if (entry.ordinaryExternal === true) return false;
  const explicitSpecialRole = canonicalSpecialRoleId(entry.role);
  if (explicitSpecialRole && explicitSpecialRole !== "subworker") return false;
  if (explicitSpecialRole === "subworker") return true;
  return !entryCurrentBrigadeEmployee(entry);
}

function automaticAssignmentRole(employee, place, fallbackDepartmentId = "") {
  const rawRole = String(employee?.role || "").trim();
  const specialRole = canonicalSpecialRoleId(rawRole);
  if (specialRole) {
    return specialRoleEnabledForWorkplace(specialRole, place, appSettings(), fallbackDepartmentId)
      ? specialRole
      : "regular";
  }
  if (rawRole) return rawRole;
  if (!employee && specialRoleEnabledForWorkplace("subworker", place, appSettings(), fallbackDepartmentId)) return "subworker";
  return "regular";
}

function init() {
  state = normalizeAppStateData(state);
  ensureSyncBaseline();
  applyPlatformMode();
  refreshConfiguredWorkplaces();
  applyDevicePreferences();
  applyScreenProfile();
  syncStateToCurrentMonth();
  fillStaticControls();
  bindEvents();
  showBrigadeStart();
  loadGithubDataOnStart();
}

function syncStateToCurrentMonth() {
  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();
  if (Number(state.month) === currentMonth && Number(state.year) === currentYear) return;

  state.month = currentMonth;
  state.year = currentYear;
  const todayValue = `${currentYear}-${String(currentMonth + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
  state.selectedShiftDate = todayValue;
  calendarCursor = { month: currentMonth, year: currentYear };
  startCalendarCursor = { month: currentMonth, year: currentYear };
  saveState({ sync: false, fromSync: true });
}

function isAndroidApp() {
  return Boolean(window.AndroidEmail);
}

function applyPlatformMode() {
  document.body.classList.toggle("android-app", isAndroidApp());
  document.body.classList.toggle("pc-app", !isAndroidApp());
}

function applyScreenProfile() {
  const width = window.innerWidth || document.documentElement?.clientWidth || 0;
  const height = window.innerHeight || document.documentElement?.clientHeight || 0;
  const shortest = Math.min(width, height);
  const longest = Math.max(width, height);
  const isLandscape = width > height;
  const coarsePointer = isAndroidApp() || Boolean(window.matchMedia?.("(pointer: coarse)")?.matches);
  const forcedMode = devicePreferences.displayMode || "auto";
  const isPhone = forcedMode === "phone" || (forcedMode === "auto" && shortest < 600);
  const isTablet = forcedMode === "tablet" || (forcedMode === "auto" && !isPhone && (coarsePointer || width < 1200));
  const isDesktop = forcedMode === "desktop" || (!isPhone && !isTablet);
  const appliedProfile = isPhone ? "phone" : (isTablet ? "tablet" : "desktop");
  document.body.dataset.screenProfile = appliedProfile;
  document.body.classList.toggle("screen-phone", isPhone);
  document.body.classList.toggle("screen-tablet", isTablet);
  document.body.classList.toggle("screen-desktop", isDesktop);
  document.body.classList.toggle("screen-landscape", isLandscape);
  document.body.classList.toggle("screen-portrait", !isLandscape);
  document.body.classList.toggle("screen-wide", longest >= 1180 && isLandscape);
  document.body.classList.toggle("screen-compact-height", height < 760);
}

function fillStaticControls() {
  refreshConfiguredWorkplaces();
  const previousVacationBrigade = String($("vacationBrigadeInput")?.value || "");
  $("monthSelect").innerHTML = MONTHS.map((name, index) => `<option value="${index}">${name}</option>`).join("");
  renderVacationDatePickerPeriodOptions();
  if ($("printVacationMonthInput")) $("printVacationMonthInput").innerHTML = MONTHS.map((name, index) => `<option value="${index}">${name}</option>`).join("");
  $("actualPlaceInput").innerHTML = PLACES.map((place) => `<option value="${place}">${place}</option>`).join("");
  $("newEmployeePlaceInput").innerHTML = employeeWorkplaceOptions().map((place) => `<option value="${place}">${place}</option>`).join("");
  if ($("newEmployeePositionInput")) {
    const selectedPosition = normalizeEmployeePosition(
      $("newEmployeePositionInput").value,
      $("newEmployeePlaceInput").value
    );
    $("newEmployeePositionInput").innerHTML = employeePositionOptionsHtml(selectedPosition);
  }
  if ($("globalEmployeePlaceInput")) {
    $("globalEmployeePlaceInput").innerHTML = employeeWorkplaceOptions().map((place) => `<option value="${place}">${place}</option>`).join("");
  }
  if ($("globalEmployeePositionInput")) {
    const selectedPosition = normalizeEmployeePosition(
      $("globalEmployeePositionInput").value,
      $("globalEmployeePlaceInput")?.value || ""
    );
    $("globalEmployeePositionInput").innerHTML = employeePositionOptionsHtml(selectedPosition);
  }
  renderStructureFilters();
  setGlobalStaffToCurrentShiftBrigade();
  refreshEmployeeList();
  $("monthSelect").value = state.month;
  if ($("vacationBrigadeInput")) {
    $("vacationBrigadeInput").value = ["1", "2", "3", "4"].includes(previousVacationBrigade) ? previousVacationBrigade : "";
  }
  syncVacationDateInputs(false);
  if ($("printVacationMonthInput")) $("printVacationMonthInput").value = state.month;
  $("yearInput").value = state.year;
  $("brigadeInput").value = state.brigade || "1";
  $("orderNumberInput").value = state.orderNumber;
  $("scheduleStartDateInput").value = state.scheduleStartDate || "";

  const today = new Date();
  const todayValue = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  const preservedDate = state.selectedShiftDate || $("workplaceDateInput")?.value || $("dateInput")?.value || todayValue;
  $("dateInput").value = preservedDate;
  $("statsDateInput").value = preservedDate;
  $("workplaceDateInput").value = preservedDate;
  state.selectedShiftDate = preservedDate;
  refreshEmployeeList();
  refreshSpecialWorkLabels();
  updateCurrentShiftDisplay();
}

function syncShiftControlsAfterStart(dateValue) {
  if ($("monthSelect")) $("monthSelect").value = state.month;
  if ($("yearInput")) $("yearInput").value = state.year;
  if ($("brigadeInput")) $("brigadeInput").value = state.brigade || "1";
  if ($("dateInput")) $("dateInput").value = dateValue;
  if ($("statsDateInput")) $("statsDateInput").value = dateValue;
  if ($("workplaceDateInput")) $("workplaceDateInput").value = dateValue;
  calendarCursor = { month: state.month, year: state.year };
  updateCurrentShiftDisplay();
}

function bindEvents() {
  applyCompactWorkplaceLabels();
  ensureSaveButtons();
  bindWorkplaceListAutoSelect();
  document.querySelectorAll("[data-save-now]").forEach((button) => {
    button.addEventListener("click", saveAndSyncNow);
  });
  $("backToStartBtn").addEventListener("click", handleBackButton);
  $("placesBackToStartBtn")?.addEventListener("click", backToStart);
  $("statsBackToStartBtn")?.addEventListener("click", backToStart);
  $("formsBackToStartBtn")?.addEventListener("click", backToStart);
  $("settingsBackToStartBtn")?.addEventListener("click", backToStart);
  $("startCalendarPrevBtn").addEventListener("click", () => moveStartCalendar(-1));
  $("startCalendarNextBtn").addEventListener("click", () => moveStartCalendar(1));
  $("openStartStaffBtn")?.addEventListener("click", () => openStartPanel("staff"));
  $("openStartVacationBtn")?.addEventListener("click", () => openStartPanel("vacation"));
  $("openStartPhonesBtn")?.addEventListener("click", () => openStartPanel("phones"));
  $("openStartSettingsBtn")?.addEventListener("click", () => openStartPanel("settings"));
  $("openStartColorsSettingsBtn")?.addEventListener("click", () => openSettingsFromStart("colors"));
  $("openStartSortingSettingsBtn")?.addEventListener("click", () => openSettingsFromStart("sorting"));
  $("openStartRulesSettingsBtn")?.addEventListener("click", () => openSettingsFromStart("rules"));
  document.querySelectorAll("[data-start-back]").forEach((button) => {
    button.addEventListener("click", closeStartPanel);
  });
  document.querySelectorAll(".main-tab[data-view]").forEach((tab) => {
    tab.addEventListener("click", () => setActiveView(tab.dataset.view));
  });
  $("calendarPrevBtn").addEventListener("click", () => moveCalendar(-1));
  $("calendarNextBtn").addEventListener("click", () => moveCalendar(1));
  $("workplaceForm").addEventListener("submit", addWorkplaceEntry);
  $("openWorkplaceFormBtn")?.addEventListener("click", () => {
    if (selectedWorkplace === "Отсутствующие" || selectedWorkplace === "Все") return;
    workplaceEditorOpened = true;
    workplaceTapReadyToOpen = "";
    clearWorkplaceForm();
    refreshEmployeeList();
    updateSelectedWorkplaceView();
    renderWorkplaceAddedList();
  });
  $("workplaceDateInput").addEventListener("change", () => {
    state.selectedShiftDate = $("workplaceDateInput").value;
    state.selectedShiftKind = inferShiftKindForDate($("workplaceDateInput").value);
    refreshEmployeeList();
    renderWorkplaceAddedList();
    renderAbsences();
  });
  $("workplaceEmployeeInput").addEventListener("input", prefillWorkplaceEmployee);
  $("workplaceEmployeeInput").addEventListener("change", prefillWorkplaceEmployee);
  $("workplaceEmployeeInput").addEventListener("blur", prefillWorkplaceEmployee);
  $("workplaceEmployeeSelect")?.addEventListener("change", selectWorkplaceEmployee);
  $("workplaceRoleInput").addEventListener("change", updateSelectedWorkplaceView);
  $("targetWorkplaceInput")?.addEventListener("change", refreshSpecialWorkLabels);
  $("workplaceShiftKindInput").addEventListener("change", updateWorkplaceHours);
  $("workplaceShiftCountInput")?.addEventListener("input", updateWorkplaceHours);
  $("workplaceClearBtn").addEventListener("click", clearWorkplaceForm);
  $("vacationSectionInput")?.addEventListener("change", (event) => {
    state.vacationSectionId = String(event.target.value || "");
    state.vacationBrigade = "";
    if ($("vacationBrigadeInput")) $("vacationBrigadeInput").value = "";
    resetVacationPlanDependentInputs();
    saveState({ sync: false, fromSync: true });
    renderVacations();
  });
  $("vacationBrigadeInput")?.addEventListener("change", (event) => {
    state.vacationBrigade = String(event.target.value || "");
    resetVacationPlanDependentInputs();
    saveState({ sync: false, fromSync: true });
    renderVacations();
  });
  $("vacationDatePickerPrevBtn")?.addEventListener("click", () => moveVacationDatePicker(-1));
  $("vacationDatePickerNextBtn")?.addEventListener("click", () => moveVacationDatePicker(1));
  $("vacationDatePickerMonthInput")?.addEventListener("change", handleVacationDatePickerPeriodChange);
  $("vacationDatePickerYearInput")?.addEventListener("change", handleVacationDatePickerPeriodChange);
  $("vacationDatePickerCloseBtn")?.addEventListener("click", () => closeVacationDatePicker());
  $("vacationDatePickerCancelBtn")?.addEventListener("click", () => closeVacationDatePicker());
  $("vacationShiftDatePicker")?.addEventListener("click", (event) => {
    if (event.target === event.currentTarget) closeVacationDatePicker();
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !$("vacationShiftDatePicker")?.classList.contains("hidden")) closeVacationDatePicker();
  });
  $("vacationStartDateInput")?.addEventListener("change", handleVacationStartDateChange);
  $("vacationEndDateInput")?.addEventListener("change", renderVacations);
  $("vacationEmployeeInput")?.addEventListener("change", () => {
    vacationSelectedEmployeeTab = String($("vacationEmployeeInput")?.value || "");
    resetVacationPeriodInputs();
    renderVacations();
  });
  $("vacationAddSelectedBtn")?.addEventListener("click", addSelectedVacationPart);
  $("vacationBalanceYearInput")?.addEventListener("change", (event) => {
    const year = Number(event.target.value);
    if (Number.isInteger(year)) {
      vacationBalanceYear = year;
      renderVacations();
    }
  });
  $("vacationStaffYearInput")?.addEventListener("change", (event) => {
    const year = Number(event.target.value);
    if (Number.isInteger(year)) vacationStaffOverviewYear = year;
    renderVacationStaffOverview(vacationStaffOverviewYear);
  });
  document.querySelectorAll("[data-vacation-mode]").forEach((button) => {
    button.addEventListener("click", () => setVacationViewMode(button.dataset.vacationMode));
  });
  $("statsDateInput")?.addEventListener("change", renderStats);
  $("statsEmployeeInput")?.addEventListener("change", renderStats);
  $("statsModeSelect")?.addEventListener("change", (event) => setStatsMode(event.target.value));
  $("monthSelect").addEventListener("change", (event) => updateSetting("month", Number(event.target.value)));
  $("yearInput").addEventListener("change", (event) => updateSetting("year", Number(event.target.value)));
  $("brigadeInput").addEventListener("change", (event) => updateSetting("brigade", event.target.value));
  $("orderNumberInput").addEventListener("input", (event) => updateSetting("orderNumber", event.target.value));
  $("scheduleStartDateInput").addEventListener("change", (event) => updateSetting("scheduleStartDate", event.target.value));

  removeUnusedShiftFields();
  $("employeeInput").addEventListener("change", prefillEmployee);
  $("dateInput").addEventListener("change", syncSelectedDate);
  $("actualPlaceInput")?.addEventListener("change", refreshSpecialWorkLabels);
  $("shiftKindInput").addEventListener("change", updateHours);
  $("shiftCountInput")?.addEventListener("input", updateHours);
  $("shiftForm").addEventListener("submit", addEntry);
  $("clearFormBtn").addEventListener("click", clearShiftForm);
  $("employeeForm").addEventListener("submit", addEmployee);
  bindEmployeePositionSuggestion($("newEmployeePlaceInput"), $("newEmployeePositionInput"));
  $("globalEmployeeForm")?.addEventListener("submit", addGlobalEmployee);
  bindEmployeePositionSuggestion($("globalEmployeePlaceInput"), $("globalEmployeePositionInput"));
  $("openGlobalEmployeeAddBtn")?.addEventListener("click", openGlobalEmployeeAddDialog);
  $("globalEmployeeBrigadeInput")?.addEventListener("change", renderGlobalStaff);
  $("globalEmployeePlaceInput")?.addEventListener("change", renderGlobalStaff);
  $("globalStaffFilterBrigade")?.addEventListener("change", renderGlobalStaff);
  $("globalStaffFilterPlace")?.addEventListener("change", handleGlobalStaffPlaceFilterChange);
  $("globalStaffFilterGrade")?.addEventListener("change", renderGlobalStaff);
  $("globalStaffFilterPosition")?.addEventListener("change", handleGlobalStaffPositionFilterChange);
  $("phoneFilterBrigade")?.addEventListener("change", renderPhoneNumbers);
  $("phoneFilterDepartment")?.addEventListener("change", () => {
    if ($("phoneFilterSection")) $("phoneFilterSection").value = "";
    renderHierarchyWorkplaceFilters("phoneFilterDepartment", "phoneFilterSection", "phoneFilterPlace");
    renderPhoneNumbers();
  });
  $("phoneFilterSection")?.addEventListener("change", () => {
    renderHierarchyWorkplaceFilters("phoneFilterDepartment", "phoneFilterSection", "phoneFilterPlace");
    renderPhoneNumbers();
  });
  $("phoneFilterPlace")?.addEventListener("change", renderPhoneNumbers);
  $("phoneSearchInput")?.addEventListener("input", renderPhoneNumbers);
  window.addEventListener("resize", () => {
    applyScreenProfile();
    lockHorizontalScrollSoon();
  });
  window.addEventListener("orientationchange", () => {
    setTimeout(() => {
      applyScreenProfile();
      render();
    }, 250);
  });
  $("clearMonthBtn").addEventListener("click", clearMonth);
  $("exportDataBtn")?.addEventListener("click", exportData);
  $("applyDataBtn")?.addEventListener("click", applyData);
  $("checkUpdateBtn")?.addEventListener("click", checkGithubUpdate);
  $("syncNowBtn")?.addEventListener("click", syncNow);
  $("importDataInput")?.addEventListener("change", importData);
  $("applyCapitalRepairBtn")?.addEventListener("click", applyCapitalRepairDistribution);
  $("applyProletchikBtn")?.addEventListener("click", applyProletchikDistribution);
  $("printSelectedFormBtn")?.addEventListener("click", () => printPreview(activeFormsSelection().targetId));
  $("emailSelectedFormBtn")?.addEventListener("click", () => prepareFormsEmail(activeFormsSelection().kind));
  $("printVacationMonthInput")?.addEventListener("change", renderVacationPrintPreview);

  document.querySelectorAll(".forms-document-tabs .tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      activatePreviewTab(tab.dataset.target);
    });
  });
  document.querySelectorAll(".smart-preview-tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".smart-preview-tab").forEach((item) => item.classList.remove("active"));
      document.querySelectorAll(".smart-preview").forEach((item) => item.classList.remove("active"));
      tab.classList.add("active");
      $(tab.dataset.smartPreviewTarget).classList.add("active");
    });
  });
}

function ensureSaveButtons() {
  const oldIds = [
    "startSaveDataBtn",
    "bottomSaveDataBtn",
    "placesSaveDataBtn",
    "statsSaveDataBtn",
    "formsSaveDataBtn",
    "settingsSaveDataBtn",
    "startStaffSaveDataBtn",
    "startVacationSaveDataBtn",
    "saveAllPhonesBtn",
  ];
  oldIds.forEach((id) => $(id)?.remove());

  const addButtonAfter = (anchor, id) => {
    if (!anchor || $(id)) return;
    const button = document.createElement("button");
    button.id = id;
    button.type = "button";
    button.className = "start-panel-save-button manual-save-button";
    button.dataset.saveNow = "true";
    button.textContent = "Сохранить";
    let row = anchor.closest(".manual-top-actions");
    if (!row) {
      row = document.createElement("div");
      row.className = "manual-top-actions";
      anchor.insertAdjacentElement("beforebegin", row);
      row.appendChild(anchor);
    }
    const existingStatus = row.querySelector("[data-save-status]");
    if (existingStatus) {
      row.insertBefore(button, existingStatus);
    } else {
      row.appendChild(button);
      const status = document.createElement("div");
      status.className = "save-state-indicator";
      status.dataset.saveStatus = "true";
      status.setAttribute("role", "status");
      status.setAttribute("aria-live", "polite");
      row.appendChild(status);
    }
  };

  addButtonAfter($("placesBackToStartBtn"), "placesSaveDataBtn");
  addButtonAfter($("statsBackToStartBtn"), "statsSaveDataBtn");
  addButtonAfter($("formsBackToStartBtn"), "formsSaveDataBtn");
  addButtonAfter($("settingsBackToStartBtn"), "settingsSaveDataBtn");
  addButtonAfter(document.querySelector(".start-staff-column [data-start-back]"), "startStaffSaveDataBtn");
  addButtonAfter(document.querySelector(".start-vacation-column [data-start-back]"), "startVacationSaveDataBtn");
  addButtonAfter(document.querySelector(".start-phones-column [data-start-back]"), "saveAllPhonesBtn");
  setSaveStatus(saveStatusState.kind, saveStatusState.text);
}

function setSaveStatus(kind, text) {
  saveStatusState = {
    kind: kind || "local",
    text: text || "Данные сохранены на устройстве",
  };
  document.querySelectorAll("[data-save-status]").forEach((status) => {
    status.className = `save-state-indicator is-${saveStatusState.kind}`;
    status.textContent = saveStatusState.text;
  });
}

let actionSyncTimer = null;

function bindActionSyncFeedback() {
  document.addEventListener("click", (event) => {
    const button = event.target.closest("button");
    if (!button) return;
    if (button.dataset.noAutoSync === "true") return;
    const text = String(button.textContent || "").trim().toLowerCase();
    const title = String(button.title || "").trim().toLowerCase();
    const actionText = `${text} ${title}`;
    if (!/(добавить|удалить|уволить|принять|перевести|умное распределение|×)/i.test(actionText)) return;
    scheduleActionSyncFeedback(stateFingerprint());
  }, true);

  document.addEventListener("submit", () => {
    scheduleActionSyncFeedback(stateFingerprint());
  }, true);
}

function bindAutoSavedFields() {
  document.addEventListener("change", (event) => {
    const phoneInput = event.target.closest("[data-phone-key]");
    if (phoneInput) {
      saveEmployeePhone(phoneInput.dataset.phoneKey);
      scheduleActionSyncFeedback("", 50);
      return;
    }

  });
}

function scheduleActionSyncFeedback(beforeFingerprint, delayMs = 300) {
  window.clearTimeout(actionSyncTimer);
  actionSyncTimer = window.setTimeout(() => {
    if (beforeFingerprint && beforeFingerprint === stateFingerprint()) return;
    commitActionSaveSync();
  }, delayMs);
}

function commitActionSaveSync() {
  saveState({ sync: false });
  void saveAndSyncNow();
}

function openStartPanel(panel) {
  const dashboard = document.querySelector(".start-dashboard");
  if (!dashboard) return;
  if (panel === "staff") {
    syncSelectedShiftToHighlightedSchedule();
    setGlobalStaffToCurrentShiftBrigade();
    renderGlobalStaff();
  }
  if (panel === "vacation") {
    vacationViewMode = "plan";
    vacationStaffOverviewYear = new Date().getFullYear();
    vacationBalanceYear = new Date().getFullYear();
    if ($("vacationSectionInput")) $("vacationSectionInput").value = "";
    if ($("vacationBrigadeInput")) $("vacationBrigadeInput").value = "";
    state.vacationDepartmentId = DEFAULT_DEPARTMENT_ID;
    state.vacationSectionId = "";
    state.vacationBrigade = "";
    vacationDatePickerCursor = vacationDatePickerDefaultCursor();
    resetVacationPlanDependentInputs();
    renderVacations();
  }
  if (panel === "phones") {
    renderPhoneNumbers();
  }
  dashboard.classList.toggle("show-staff", panel === "staff");
  dashboard.classList.toggle("show-vacation", panel === "vacation");
  dashboard.classList.toggle("show-phones", panel === "phones");
  dashboard.classList.toggle("show-settings", panel === "settings");
  dashboard.scrollTo({ top: 0, behavior: "smooth" });
}

function closeStartPanel() {
  const dashboard = document.querySelector(".start-dashboard");
  if (!dashboard) return;
  dashboard.classList.remove("show-staff", "show-vacation", "show-phones", "show-settings");
  dashboard.scrollTo({ top: 0, behavior: "smooth" });
}

function openSettingsFromStart(kind = "forms") {
  closeStartPanel();
  document.body.classList.remove("app-locked");
  setActiveView("settings", { skipHistory: true });
  // The start screen exposes dedicated Colors and Forms entries.
  // Keep any legacy/unknown route on a visible supported section.
  const supportedSections = ["colors", "forms", "rules"];
  settingsViewMode = supportedSections.includes(kind) ? kind : "forms";
  renderAppSettings();
  window.requestAnimationFrame(() => window.scrollTo({ top: 0, behavior: "smooth" }));
}

function bindWorkplaceListAutoSelect() {
  const list = $("workplaceList");
  if (!list) return;
  let scrollTimer = null;
  list.addEventListener("touchstart", () => {
    workplaceCarouselTouching = true;
    window.clearTimeout(workplaceCarouselTimer);
  }, { passive: true });
  list.addEventListener("touchend", () => {
    workplaceCarouselTouching = false;
    window.clearTimeout(scrollTimer);
    scrollTimer = setTimeout(settleWorkplaceCarousel, 120);
  }, { passive: true });
  list.addEventListener("scroll", () => {
    if (workplaceCarouselSkip) return;
    if (workplaceCarouselTouching) return;
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(settleWorkplaceCarousel, 260);
  }, { passive: true });
}

function settleWorkplaceCarousel() {
  if (workplaceCarouselTouching) return;
  normalizeWorkplaceCarousel();
  updateWorkplaceCardActive();
}

function selectCenteredWorkplaceCard() {
  const list = $("workplaceList");
  if (!list || !isMobileViewport()) return;
  const cards = [...list.querySelectorAll(".workplace-card[data-workplace-key]")];
  if (!cards.length) return;
  const listRect = list.getBoundingClientRect();
  const center = listRect.left + listRect.width / 2;
  const selectedCard = cards.reduce((best, card) => {
    const rect = card.getBoundingClientRect();
    if (rect.right < listRect.left || rect.left > listRect.right) return best;
    const distance = Math.abs(rect.left + rect.width / 2 - center);
    return !best || distance < best.distance ? { card, distance } : best;
  }, null)?.card;

  const key = selectedCard?.dataset.workplaceKey;
  if (!key) return;
  updateWorkplaceCardActive(selectedCard);
  if (key === selectedWorkplace) return;
  selectedWorkplace = key;
  workplaceEditorOpened = false;
  clearWorkplaceForm();
  refreshEmployeeList();
  updateWorkplaceCardActive(selectedCard);
  updateSelectedWorkplaceView();
  renderWorkplaceAddedList();
}

function normalizeWorkplaceCarousel() {
  const list = $("workplaceList");
  if (!list || !isMobileViewport() || list.dataset.carousel !== "true") return;
  const third = list.scrollWidth / 3;
  if (!third) return;
  let nextLeft = list.scrollLeft;
  if (list.scrollLeft < third * 0.55) {
    nextLeft = list.scrollLeft + third;
  } else if (list.scrollLeft > third * 1.45) {
    nextLeft = list.scrollLeft - third;
  }
  if (Math.abs(nextLeft - list.scrollLeft) < 2) return;
  workplaceCarouselSkip = true;
  list.scrollLeft = nextLeft;
  requestAnimationFrame(() => {
    workplaceCarouselSkip = false;
  });
}

function centerWorkplaceCarousel() {
  updateWorkplaceCardActive();
}

function cssEscape(value) {
  if (window.CSS?.escape) return window.CSS.escape(value);
  return String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}

function isMobileViewport() {
  return window.matchMedia("(max-width: 700px)").matches;
}

function updateWorkplaceCardActive(centerCard = null) {
  const list = $("workplaceList");
  const cards = [...document.querySelectorAll(".workplace-card[data-workplace-key]")];
  let activeCard = centerCard;
  if (!activeCard && list && list.dataset.carousel === "true") {
    const listRect = list.getBoundingClientRect();
    const center = listRect.left + listRect.width / 2;
    activeCard = cards.reduce((best, card) => {
      if (card.dataset.workplaceKey !== selectedWorkplace) return best;
      const rect = card.getBoundingClientRect();
      const distance = Math.abs(rect.left + rect.width / 2 - center);
      return !best || distance < best.distance ? { card, distance } : best;
    }, null)?.card;
  }
  cards.forEach((card) => {
    const active = list?.dataset.carousel === "true"
      ? (card.dataset.workplaceKey === selectedWorkplace && Number(card.dataset.carouselCopy || 0) === selectedWorkplaceCarouselCopy)
      : card.dataset.workplaceKey === selectedWorkplace;
    card.classList.toggle("active", active);
  });
}

function bindStartDashboardSwipe() {
  const dashboard = document.querySelector(".start-dashboard");
  if (!dashboard) return;
  let startX = 0;
  let startY = 0;
  let blockPageSwipe = false;

  dashboard.addEventListener("touchstart", (event) => {
    const touch = event.touches && event.touches[0];
    if (!touch) return;
    blockPageSwipe = Boolean(event.target.closest(
      "button, input, select, textarea, .global-staff-table-wrap, .vacation-table-wrap, .table-wrap, .staff-actions"
    ));
    startX = touch.clientX;
    startY = touch.clientY;
  }, { passive: true });

  dashboard.addEventListener("touchend", (event) => {
    const touch = event.changedTouches && event.changedTouches[0];
    if (!touch) return;
    if (blockPageSwipe) {
      blockPageSwipe = false;
      return;
    }
    const dx = touch.clientX - startX;
    const dy = touch.clientY - startY;
    const minSwipe = Math.min(150, Math.max(90, dashboard.clientWidth * 0.22));
    if (Math.abs(dx) < minSwipe || Math.abs(dx) < Math.abs(dy) * 1.35) return;
    const pageWidth = dashboard.clientWidth || window.innerWidth;
    const pageCount = Math.max(1, dashboard.children.length);
    const currentPage = Math.round(dashboard.scrollLeft / pageWidth);
    const nextPage = Math.max(0, Math.min(pageCount - 1, currentPage + (dx < 0 ? 1 : -1)));
    dashboard.scrollTo({
      left: nextPage * pageWidth,
      behavior: "smooth",
    });
  }, { passive: true });
}

function updateSetting(key, value) {
  state[key] = value;
  if (key === "month" || key === "year") {
    calendarCursor = { month: Number(state.month), year: Number(state.year) };
  }
  if (key === "brigade") {
    refreshEmployeeList();
  }
  saveState();
  updateCurrentShiftDisplay();
  render();
}

function showBrigadeStart() {
  document.body.classList.add("app-locked");
  setGlobalStaffToCurrentShiftBrigade();
  startCalendarCursor = { month: Number(state.month), year: Number(state.year) };
  renderStartScheduleCalendar();
}

function backToStart() {
  viewHistory = [];
  saveState();
  showBrigadeStart();
}

function handleBackButton() {
  if (activeView === "places" && workplaceEditorOpened) {
    workplaceEditorOpened = false;
    clearWorkplaceForm();
    renderWorkplaces();
    return;
  }

  const previousView = viewHistory.pop();
  if (previousView) {
    setActiveView(previousView, { skipHistory: true });
    return;
  }

  backToStart();
}

function chooseBrigade(brigade) {
  state.brigade = String(brigade || BASE_STAFF_BRIGADE);
  viewHistory = [];
  saveState();
  document.body.classList.remove("app-locked");
  fillStaticControls();
  refreshEmployeeList();
  render();
  setActiveView("places", { skipHistory: true });
}

function dateSerial(dateValue) {
  const date = new Date(`${dateValue}T00:00:00`);
  return Math.floor(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()) / 86400000);
}

function shiftSerial(dateValue, kind) {
  return dateSerial(dateValue) * 2 + (kind === "night" ? 1 : 0);
}

function startShiftForDate(dateValue, kind) {
  const anchorSerial = shiftSerial(START_SHIFT_ANCHOR_DATE, START_SHIFT_ANCHOR_KIND);
  const offset = shiftSerial(dateValue, kind) - anchorSerial;
  const index = ((offset % START_SHIFT_CYCLE.length) + START_SHIFT_CYCLE.length) % START_SHIFT_CYCLE.length;
  return START_SHIFT_CYCLE[index];
}

function startShiftForSerial(serial) {
  const anchorSerial = shiftSerial(START_SHIFT_ANCHOR_DATE, START_SHIFT_ANCHOR_KIND);
  const offset = serial - anchorSerial;
  const index = ((offset % START_SHIFT_CYCLE.length) + START_SHIFT_CYCLE.length) % START_SHIFT_CYCLE.length;
  return START_SHIFT_CYCLE[index];
}

function eligibleSubworkBrigade(dateValue = selectedShiftDate(), kind = selectedShiftKindForDate(dateValue)) {
  if (!dateValue || !kind) return "";
  const currentSerial = shiftSerial(dateValue, kind);
  const blocked = blockedSubworkBrigades(dateValue, kind);
  return ["1", "2", "3", "4"].find((brigade) => !blocked.has(brigade)) || "";
}

function blockedSubworkBrigades(dateValue = selectedShiftDate(), kind = selectedShiftKindForDate(dateValue)) {
  if (!dateValue || !kind) return new Set();
  const currentSerial = shiftSerial(dateValue, kind);
  return new Set([
    startShiftForSerial(currentSerial - 1),
    startShiftForSerial(currentSerial),
    startShiftForSerial(currentSerial + 1),
  ]);
}

function currentStartShiftSlot(now = new Date()) {
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  const minutes = now.getHours() * 60 + now.getMinutes();
  const dayStart = 7 * 60 + 30;
  const nightStart = 19 * 60 + 30;
  const date = new Date(year, now.getMonth(), now.getDate());

  if (minutes < dayStart) {
    date.setDate(date.getDate() - 1);
    return {
      dateValue: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`,
      kind: "night",
    };
  }

  const dateValue = `${year}-${month}-${day}`;
  return {
    dateValue,
    kind: minutes >= nightStart ? "night" : "day",
  };
}

function isCurrentStartShift(dateValue, kind) {
  const current = currentStartShiftSlot();
  return current.dateValue === dateValue && current.kind === kind;
}

function currentRealShiftBrigade() {
  const current = currentStartShiftSlot();
  return startShiftForDate(current.dateValue, current.kind);
}

function setGlobalStaffToCurrentShiftBrigade() {
  const input = $("globalEmployeeBrigadeInput");
  if (!input) return;
  input.value = currentRealShiftBrigade();
}

function syncSelectedShiftToHighlightedSchedule() {
  const current = currentStartShiftSlot();
  state.selectedShiftDate = current.dateValue;
  state.selectedShiftKind = current.kind;
}

function moveStartCalendar(delta) {
  const date = new Date(startCalendarCursor.year, startCalendarCursor.month + delta, 1);
  startCalendarCursor = { month: date.getMonth(), year: date.getFullYear() };
  renderStartScheduleCalendar();
}

function openStartShiftDepartment(dateValue, kind, departmentId) {
  try {
    const brigade = startShiftForDate(dateValue, kind);
    const date = new Date(`${dateValue}T00:00:00`);
    viewHistory = [];
    state.brigade = brigade;
    state.month = date.getMonth();
    state.year = date.getFullYear();
    state.selectedShiftDate = dateValue;
    state.selectedShiftKind = kind;
    saveState({ sync: false, fromSync: true });

    document.body.classList.remove("app-locked");
    syncShiftControlsAfterStart(dateValue);
    selectedWorkplaceDepartmentId = String(departmentId || "");
    selectedWorkplaceSectionId = "";
    workplaceHierarchyLevel = "sections";
    workplaceEditorOpened = false;
    workplaceCreateOpened = false;
    workplaceListSignature = "";
    setActiveView("places", { skipHistory: true, keepWorkplaceHierarchy: true });
  } catch (error) {
    console.error("Shift open failed", error);
    showAppMessage("Смена", "Не удалось открыть смену: " + error.message);
  }
}

function showStartShiftDepartmentPicker(dateValue, kind, departments) {
  lockHorizontalScrollSoon();
  document.querySelector(".app-message-backdrop")?.remove();
  const brigade = startShiftForDate(dateValue, kind);
  const backdrop = document.createElement("div");
  backdrop.className = "app-message-backdrop";
  const panel = document.createElement("div");
  panel.className = "app-message start-department-picker";
  panel.innerHTML = `
    <h3>Выберите подразделение</h3>
    <p>${escapeHtml(formatDate(dateValue))} · ${kind === "night" ? "Ночная" : "Дневная"} смена · Бригада ${escapeHtml(brigade)}</p>
    <label class="start-department-select-label">
      <span>Подразделение</span>
      <select class="start-department-select" aria-label="Подразделение">
        <option value="">Выбрать подразделение</option>
        ${departments.map((department) => `<option value="${escapeHtml(department.id)}">${escapeHtml(department.name)}</option>`).join("")}
      </select>
    </label>
    <div class="app-message-actions">
      <button type="button" class="secondary start-department-cancel">Отмена</button>
    </div>
  `;
  const select = panel.querySelector(".start-department-select");
  function close() {
    document.removeEventListener("keydown", handleKeydown);
    backdrop.remove();
    document.body.classList.remove("message-open");
    lockHorizontalScrollSoon();
  }
  function handleKeydown(event) {
    if (event.key === "Escape") close();
  }
  select.addEventListener("change", () => {
    const departmentId = String(select.value || "");
    if (!departmentId) return;
    close();
    openStartShiftDepartment(dateValue, kind, departmentId);
  });
  panel.querySelector(".start-department-cancel").addEventListener("click", close);
  backdrop.addEventListener("click", (event) => {
    if (event.target === backdrop) close();
  });
  backdrop.appendChild(panel);
  document.body.classList.add("message-open");
  document.body.appendChild(backdrop);
  document.addEventListener("keydown", handleKeydown);
  requestAnimationFrame(() => select.focus({ preventScroll: true }));
  lockHorizontalScrollSoon();
}

function chooseStartShift(dateValue, kind) {
  const department = configuredDepartments()[0];
  if (!department) {
    showAppMessage("Цех 7", "Не удалось открыть подразделение «Цех 7».");
    return;
  }
  openStartShiftDepartment(dateValue, kind, department.id);
}

function renderStartScheduleCalendar() {
  if (!$("startScheduleCalendar")) return;
  $("startCalendarTitle").textContent = `${MONTHS[startCalendarCursor.month]} ${startCalendarCursor.year}`;
  const first = new Date(startCalendarCursor.year, startCalendarCursor.month, 1);
  const daysInMonth = new Date(startCalendarCursor.year, startCalendarCursor.month + 1, 0).getDate();
  const mondayBasedStart = (first.getDay() + 6) % 7;
  const cells = [];
  const weekDays = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];

  for (const day of weekDays) {
    cells.push(`<div class="start-calendar-head">${day}</div>`);
  }
  for (let i = 0; i < mondayBasedStart; i += 1) {
    cells.push(`<div class="start-calendar-cell muted"></div>`);
  }

  for (let day = 1; day <= daysInMonth; day += 1) {
    const dateValue = `${startCalendarCursor.year}-${String(startCalendarCursor.month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    const dayBrigade = startShiftForDate(dateValue, "day");
    const nightBrigade = startShiftForDate(dateValue, "night");
    const dayCurrentClass = isCurrentStartShift(dateValue, "day") ? " current-shift" : "";
    const nightCurrentClass = isCurrentStartShift(dateValue, "night") ? " current-shift" : "";
    cells.push(`
      <div class="start-calendar-cell">
        <strong>${day}</strong>
        <button class="start-shift-button day${dayCurrentClass}" type="button" data-start-date="${dateValue}" data-start-kind="day" title="7:30-19:30, Бригада ${dayBrigade}">
          <span>День</span>
          <b>Бр. ${dayBrigade}</b>
        </button>
        <button class="start-shift-button night${nightCurrentClass}" type="button" data-start-date="${dateValue}" data-start-kind="night" title="19:30-7:30, Бригада ${nightBrigade}">
          <span>Ночь</span>
          <b>Бр. ${nightBrigade}</b>
        </button>
      </div>
    `);
  }

  $("startScheduleCalendar").innerHTML = cells.join("");
  $("startScheduleCalendar").querySelectorAll("[data-start-date]").forEach((button) => {
    button.addEventListener("click", () => chooseStartShift(button.dataset.startDate, button.dataset.startKind));
  });
}

function setActiveView(view, options = {}) {
  if (!view) return;
  if (view === "repair") view = "places";
  if (view === "print") view = "forms";
  if (!options.skipHistory && view !== activeView) {
    viewHistory.push(activeView);
    if (viewHistory.length > 12) viewHistory = viewHistory.slice(-12);
  }
  if (view === "places" && activeView !== "places" && !options.keepWorkplaceHierarchy) {
    workplaceHierarchyLevel = "sections";
    selectedWorkplaceDepartmentId = DEFAULT_DEPARTMENT_ID;
    selectedWorkplaceSectionId = "";
    workplaceEditorOpened = false;
    workplaceCreateOpened = false;
  }
  activeView = view;
  document.body.classList.toggle("settings-view-active", view === "settings");
  renderActiveView(view);
  document.body.classList.remove("print-view-active");
  document.querySelectorAll(".main-tab").forEach((tab) => {
    tab.classList.toggle("active", tab.dataset.view === view);
  });
  document.querySelectorAll(".app-view").forEach((panel) => {
    panel.classList.toggle("active", panel.dataset.viewPanel === view);
  });
  if (view === "schedule") renderCalendar();
  lockHorizontalScrollSoon();
}

function renderPrintDocuments() {
  renderEntries();
  renderTransferPreview();
  renderRepairPreview();
  renderMeetingPreview();
  renderVacationPrintPreview();
}

function renderActiveView(view = activeView) {
  if (view === "places") {
    renderWorkplaces();
    renderAbsentToday();
    return;
  }
  if (view === "stats") {
    renderStats();
    return;
  }
  if (view === "print") {
    renderPrintDocuments();
    return;
  }
  if (view === "forms") {
    renderPrintDocuments();
    return;
  }
  if (view === "settings") {
    renderAppSettings();
    return;
  }
  if (view === "schedule") {
    renderCalendar();
    return;
  }
  renderWorkplaces();
}

function settingsWorkplaceRows(configured = appSettings()) {
  const defaultDepartmentId = configured.departments[0]?.id || DEFAULT_DEPARTMENT_ID;
  const custom = (configured.workplaces || []).map((item) => typeof item === "string" ? { name: item, type: "other" } : item);
  const hidden = new Set((configured.hiddenWorkplaces || []).map(String));
  return [...BASE_WORKPLACE_DEFINITIONS.map((item) => ({ ...item, base: true, departmentId: item.departmentId || defaultDepartmentId })), ...custom]
    .filter((item, index, all) => item?.name && all.findIndex((candidate) => candidate?.name === item.name) === index)
    .filter((item) => BASE_WORKPLACE_DEFINITIONS.some((base) => base.name === item.name))
    .filter((item) => !hidden.has(item.name));
}

function configuredDepartments() {
  const settings = appSettings();
  const department = (settings.departments || []).find((item) => item.id === DEFAULT_DEPARTMENT_ID)
    || DEFAULT_DEPARTMENTS.find((item) => item.id === DEFAULT_DEPARTMENT_ID);
  return department ? [{ ...department }] : [];
}

function configuredDepartmentColor(departmentId, settings = appSettings()) {
  const id = String(departmentId || "");
  const index = Math.max(0, (settings.departments || []).findIndex((department) => department.id === id));
  return normalizeStructureColor(
    settings.departmentColors?.[id],
    DEFAULT_DEPARTMENT_COLORS[id] || suggestedDepartmentColor(index)
  );
}

function configuredDepartmentForWorkplace(place, settings = appSettings()) {
  const directDepartment = (settings.departments || []).find((department) => sameWorkplaceKey(department.name, place));
  if (directDepartment) return directDepartment;
  const workplace = settingsWorkplaceRows(settings).find((item) => sameWorkplaceKey(item.name, place));
  return (settings.departments || []).find((department) => department.id === workplace?.departmentId);
}

function configuredWorkplaceColorOverride(place, settings = appSettings()) {
  return normalizeOptionalStructureColor(settings.workplaceColors?.[canonicalWorkplaceKey(place)]);
}

function configuredWorkplaceColor(place, settings = appSettings()) {
  const ownColor = configuredWorkplaceColorOverride(place, settings);
  if (ownColor) return ownColor;
  const department = configuredDepartmentForWorkplace(place, settings);
  return configuredDepartmentColor(department?.id, settings);
}

function configuredSections(departmentId = "") {
  const settings = appSettings();
  const hidden = new Set(settings.hiddenSections || []);
  const scopedDepartmentId = String(departmentId || DEFAULT_DEPARTMENT_ID);
  return settings.sections
    .filter((section) => !hidden.has(section.id))
    .filter((section) => section.departmentId === scopedDepartmentId);
}

function configuredSectionLabel(section) {
  if (section?.id === "section-furnace-bay") return "Печи";
  if (section?.id === "section-casting-bay") return "Разливочные машины";
  return String(section?.name || "").trim();
}

function renderHierarchyFilterPair(departmentSelectId, sectionSelectId) {
  const departmentSelect = $(departmentSelectId);
  const sectionSelect = $(sectionSelectId);
  if (!departmentSelect || !sectionSelect) return { departmentId: "", sectionId: "" };
  const previousDepartment = String(departmentSelect.value || "");
  const previousSection = String(sectionSelect.value || "");
  const departments = configuredDepartments();
  departmentSelect.innerHTML = departments.map((department) => `
    <option value="${escapeHtml(department.id)}">${escapeHtml(department.name)}</option>
  `).join("");
  departmentSelect.value = departments.some((department) => department.id === previousDepartment)
    ? previousDepartment
    : (departments[0]?.id || "");
  departmentSelect.disabled = departments.length <= 1;
  const sections = departmentSelect.value ? configuredSections(departmentSelect.value) : [];
  sectionSelect.innerHTML = `<option value="">Все</option>${sections.map((section) => `
    <option value="${escapeHtml(section.id)}">${escapeHtml(configuredSectionLabel(section))}</option>
  `).join("")}`;
  sectionSelect.value = sections.some((section) => section.id === previousSection) ? previousSection : "";
  sectionSelect.disabled = !departmentSelect.value;
  return { departmentId: departmentSelect.value, sectionId: sectionSelect.value };
}

function workplaceMatchesHierarchy(place, departmentId = "", sectionId = "") {
  if (!departmentId && !sectionId) return true;
  const placeKey = statsPlaceKey(place);
  return settingsWorkplaceRows().some((workplace) => {
    const samePlace = workplace.name === place || statsPlaceKey(workplace.name) === placeKey;
    return samePlace
      && (!departmentId || workplace.departmentId === departmentId)
      && (!sectionId || workplace.sectionId === sectionId);
  });
}

function workplaceSummaryHomePlace(item) {
  const employee = employeeByTab(item?.tab) || employeeByName(item?.name);
  return employee?.place || item?.homePlace || item?.actualPlace || item?.place || "";
}

function workplaceMatchesDepartment(place, departmentId = "") {
  if (!departmentId) return true;
  if (workplaceMatchesHierarchy(place, departmentId, "")) return true;
  const department = configuredDepartments().find((item) => item.id === departmentId);
  return Boolean(department && statsPlaceKey(place) === statsPlaceKey(department.name));
}

function shiftRowMatchesSelectedHierarchy(item) {
  if (!selectedWorkplaceDepartmentId && !selectedWorkplaceSectionId) return true;
  const actualPlace = item?.actualPlace || item?.place || "";
  if (selectedWorkplaceSectionId) {
    return workplaceMatchesHierarchy(
      actualPlace || workplaceSummaryHomePlace(item),
      selectedWorkplaceDepartmentId,
      selectedWorkplaceSectionId,
    );
  }
  return workplaceMatchesDepartment(
    actualPlace || workplaceSummaryHomePlace(item),
    selectedWorkplaceDepartmentId,
  );
}

function missingEmployeeMatchesSelectedHierarchy(item) {
  if (!selectedWorkplaceDepartmentId && !selectedWorkplaceSectionId) return true;
  return workplaceMatchesHierarchy(
    workplaceSummaryHomePlace(item),
    selectedWorkplaceDepartmentId,
    selectedWorkplaceSectionId,
  );
}

function selectedHierarchyShiftRows(date) {
  return shiftOverviewRows(date).filter(shiftRowMatchesSelectedHierarchy);
}

function selectedHierarchyMissingEmployees(date) {
  return missingEmployeesForDate(date).filter(missingEmployeeMatchesSelectedHierarchy);
}

function renderHierarchyWorkplaceFilters(departmentSelectId, sectionSelectId, placeSelectId) {
  const hierarchy = renderHierarchyFilterPair(departmentSelectId, sectionSelectId);
  const placeSelect = $(placeSelectId);
  if (!placeSelect) return hierarchy;
  const previousPlace = placeSelect.value;
  const places = settingsWorkplaceRows()
    .filter((workplace) => workplaceMatchesHierarchy(workplace.name, hierarchy.departmentId, hierarchy.sectionId))
    .map((workplace) => workplace.name)
    .filter((place, index, all) => place !== "Другое место" && all.indexOf(place) === index);
  placeSelect.innerHTML = `<option value="">Все</option>${places.map((place) => `<option value="${escapeHtml(place)}">${escapeHtml(place)}</option>`).join("")}`;
  placeSelect.value = places.includes(previousPlace) ? previousPlace : "";
  return hierarchy;
}

function renderGlobalStaffHierarchyFilters() {
  const placeSelect = $("globalStaffFilterPlace");
  const previousGroup = String(placeSelect?.value || "");
  const groups = [
    { value: "furnaces", label: "Печи" },
    { value: "casting", label: "Разливочные машины" },
  ];
  if (placeSelect) {
      placeSelect.innerHTML = `<option value="">Все</option>${groups.map((group) => `
      <option value="${group.value}">${group.label}</option>
    `).join("")}`;
    placeSelect.value = groups.some((group) => group.value === previousGroup) ? previousGroup : "";
  }
  return {
    departmentId: DEFAULT_DEPARTMENT_ID,
    sectionId: "",
    workplaceGroup: placeSelect?.value || "",
  };
}

function openGlobalStaffWorkplaceCreation() {
  closeStartPanel();
  document.body.classList.remove("app-locked");
  selectedWorkplaceDepartmentId = DEFAULT_DEPARTMENT_ID;
  selectedWorkplaceSectionId = "";
  workplaceHierarchyLevel = "sections";
  workplaceEditorOpened = false;
  workplaceCreateOpened = false;
  workplaceListSignature = "";
  setActiveView("places", { skipHistory: true, keepWorkplaceHierarchy: true });
  toggleMainWorkplaceCreate(true);
}

function handleGlobalStaffPlaceFilterChange(event) {
  const placeSelect = event?.currentTarget || $("globalStaffFilterPlace");
  if (String(placeSelect?.value || "") !== GLOBAL_STAFF_ADD_WORKPLACE_ACTION) {
    if (String(placeSelect?.value || "") === GLOBAL_STAFF_DELETE_WORKPLACE_ACTION) {
      placeSelect.value = "";
      renderGlobalStaffWorkplaceDeleteOptions();
      toggleGlobalStaffWorkplaceDelete(true);
      toggleGlobalStaffPositionDelete(false);
      renderGlobalStaff();
      requestAnimationFrame(() => $("globalStaffWorkplaceDeleteSelect")?.focus({ preventScroll: true }));
      return;
    }
    renderGlobalStaff();
    return;
  }
  placeSelect.value = "";
  openGlobalStaffWorkplaceCreation();
}

function renderStructureFilters() {
  renderGlobalStaffHierarchyFilters();
  renderHierarchyWorkplaceFilters("phoneFilterDepartment", "phoneFilterSection", "phoneFilterPlace");
  selectedStatsDepartmentId = selectedWorkplaceDepartmentId;
  selectedStatsSectionId = selectedWorkplaceSectionId;
}

function activeSettingsDepartment() {
  const departments = configuredDepartments();
  const selected = departments.find((department) => department.id === selectedSettingsDepartmentId) || departments[0];
  selectedSettingsDepartmentId = selected?.id || "";
  return selected;
}

function setSettingsDepartment(departmentId) {
  selectedSettingsDepartmentId = String(departmentId || "");
  selectedSettingsSectionId = "";
  renderAppSettings();
}

function activeSettingsSection() {
  const sections = configuredSections(activeSettingsDepartment()?.id);
  const selected = sections.find((section) => section.id === selectedSettingsSectionId) || sections[0];
  selectedSettingsSectionId = selected?.id || "";
  return selected;
}

function setSettingsSection(sectionId) {
  selectedSettingsSectionId = String(sectionId || "");
  renderAppSettings();
}

function normalizeSettingsViewMode(mode) {
  const aliases = {
    screen: "rules",
    theme: "rules",
    administrator: "rules",
    instructions: "rules",
    appearance: "rules",
    data: "rules",
    statistics: "rules",
    about: "rules",
  };
  const normalized = aliases[String(mode || "")] || String(mode || "");
  return [
    "colors",
    "forms",
    "rules",
  ].includes(normalized) ? normalized : "forms";
}

function setSettingsViewMode(mode) {
  settingsViewMode = normalizeSettingsViewMode(mode);
  devicePreferences = { ...devicePreferences, settingsSection: settingsViewMode };
  saveDevicePreferences();
  renderAppSettings();
  window.requestAnimationFrame(() => {
    const panel = document.querySelector(".settings-tab-panel");
    panel?.focus({ preventScroll: true });
    panel?.scrollIntoView({ behavior: "smooth", block: "start" });
  });
}

function openWorkplaceRulesSettings(place) {
  selectedSettingsRulesWorkplace = String(place || "");
  setSettingsViewMode("rules");
  window.requestAnimationFrame(() => {
    document.querySelector(".settings-rule-editor")?.scrollIntoView({ behavior: "smooth", block: "start" });
  });
}

function openSettingsStartPanel(panel) {
  backToStart();
  window.setTimeout(() => openStartPanel(panel), 0);
}

function openSettingsAppView(view) {
  setActiveView(view);
  window.requestAnimationFrame(() => window.scrollTo({ top: 0, behavior: "smooth" }));
}

function settingsSwitch(key, label, checked, adminRequired = false) {
  return `<label class="settings-switch"><input type="checkbox" ${checked ? "checked" : ""} onchange="updateSharedSetting('${key}', this.checked, ${adminRequired})"><span>${escapeHtml(label)}</span></label>`;
}

function configuredFormSort(formKind, settings = appSettings()) {
  const allowedModes = ["date", "workplace", "alphabetical", "alphabetical-date", "workplace-date"];
  const modeKey = `${formKind}FormSortMode`;
  const directionKey = `${formKind}FormSortDirection`;
  const savedMode = settings[modeKey] || settings.formSortMode;
  const savedDirection = settings[directionKey] || settings.formSortDirection;
  return {
    mode: allowedModes.includes(savedMode) ? savedMode : "date",
    direction: savedDirection === "desc" ? "desc" : "asc",
  };
}

function formSortSettingsMarkup(formKind, title, settings) {
  const sort = configuredFormSort(formKind, settings);
  const modeKey = `${formKind}FormSortMode`;
  const directionKey = `${formKind}FormSortDirection`;
  return `
    <div class="settings-form-sort-item" aria-label="Сортировка бланка «${escapeHtml(title)}»">
      <strong>Порядок строк</strong>
      <div class="settings-grid two-columns">
        <label>Сортировать
          <select onchange="updateSharedSetting('${modeKey}', this.value, true)">
            <option value="date" ${sort.mode === "date" ? "selected" : ""}>По дате</option>
            <option value="workplace" ${sort.mode === "workplace" ? "selected" : ""}>По рабочему месту</option>
            <option value="alphabetical" ${sort.mode === "alphabetical" ? "selected" : ""}>По алфавиту</option>
            <option value="alphabetical-date" ${sort.mode === "alphabetical-date" ? "selected" : ""}>По алфавиту и дате</option>
            <option value="workplace-date" ${sort.mode === "workplace-date" ? "selected" : ""}>По рабочему месту и дате</option>
          </select>
        </label>
        <label>Направление
          <select onchange="updateSharedSetting('${directionKey}', this.value, true)">
            <option value="asc" ${sort.direction === "asc" ? "selected" : ""}>По возрастанию</option>
            <option value="desc" ${sort.direction === "desc" ? "selected" : ""}>По убыванию</option>
          </select>
        </label>
      </div>
    </div>
  `;
}

function renderAppSettings() {
  const root = $("appSettingsRoot");
  if (!root) return;
  settingsViewMode = normalizeSettingsViewMode(settingsViewMode);

  const settings = appSettings();
  const now = new Date();
  const year = now.getFullYear();
  const currentMonth = now.getMonth();
  const operationalYears = new Set([year]);
  ["entries", "absences", "vacations", "proletchikShifts", "capitalRepairShifts"].forEach((field) => {
    (state[field] || []).forEach((item) => {
      const match = /^([0-9]{4})-/.exec(String(item?.date || item?.start || item?.startDate || ""));
      if (match) operationalYears.add(Number(match[1]));
    });
  });
  const deleteYearOptions = [...operationalYears].sort((a, b) => b - a)
    .map((value) => `<option value="${value}" ${value === year ? "selected" : ""}>${value}</option>`).join("");
  const deleteMonthOptions = MONTHS.map((name, index) => `<option value="${index}" ${index === currentMonth ? "selected" : ""}>${name}</option>`).join("");

  const primaryTabs = [
    { key: "rules", label: "Правила", description: "Нормы и ограничения" },
  ];
  const secondaryTabs = [];
  const allTabs = [...primaryTabs, ...secondaryTabs];
  const scopeBadge = (kind, label) => `<span class="settings-scope-badge is-${kind}">${escapeHtml(label)}</span>`;
  const panelHeading = (title, description, kind = "shared", scope = "Для всех устройств") => `
    <div class="settings-section-heading settings-section-heading-main">
      <div><h3>${escapeHtml(title)}</h3><p>${escapeHtml(description)}</p></div>
      ${scopeBadge(kind, scope)}
    </div>`;

  const departments = configuredDepartments();
  const allSections = configuredSections();
  const sectionById = new Map(allSections.map((section) => [section.id, section]));
  const activeDepartment = activeSettingsDepartment();
  const activeDepartmentColor = configuredDepartmentColor(activeDepartment?.id, settings);
  const newDepartmentColor = suggestedDepartmentColor(departments.length);
  const sections = configuredSections(activeDepartment?.id);
  const activeSection = activeSettingsSection();
  const activeEmployees = activeUnifiedEmployees();
  const phoneCount = Object.values(state.employeePhones || {}).filter(Boolean).length;
  const departmentTabs = departments.map((department) => `
    <button type="button" class="${department.id === activeDepartment?.id ? "active" : ""}" aria-current="${department.id === activeDepartment?.id ? "true" : "false"}" onclick="setSettingsDepartment('${escapeJs(department.id)}')"><i class="settings-department-swatch" style="background:${escapeHtml(configuredDepartmentColor(department.id, settings))}"></i><span>${escapeHtml(department.name)}</span></button>
  `).join("");
  const sectionTabs = sections.map((section) => `
    <button type="button" class="${section.id === activeSection?.id ? "active" : ""}" aria-current="${section.id === activeSection?.id ? "true" : "false"}" onclick="setSettingsSection('${escapeJs(section.id)}')">${escapeHtml(configuredSectionLabel(section))}</button>
  `).join("");
  const workplaceRows = settingsWorkplaceRows()
    .filter((item) => item.departmentId === activeDepartment?.id && item.sectionId === activeSection?.id)
    .map((item) => {
      const assigned = activeEmployees.filter((employee) => employee.place === item.name).length;
      const ownColor = configuredWorkplaceColorOverride(item.name, settings);
      const workplaceColor = ownColor || configuredDepartmentColor(item.departmentId, settings);
      return `<div class="settings-workplace-row" style="--settings-workplace-color:${escapeHtml(workplaceColor)}">
        <div><strong>${escapeHtml(item.name)}</strong><span>${assigned ? `${assigned} штатных сотрудников` : "Нет назначенных сотрудников"}</span></div>
        <div class="settings-workplace-actions">
          <label class="settings-workplace-color-control"><span>${ownColor ? "Свой цвет" : "Цвет подразделения"}</span><input type="color" value="${escapeHtml(workplaceColor)}" aria-label="Цвет рабочего места ${escapeHtml(item.name)}" onchange="updateConfiguredWorkplaceColor('${escapeJs(item.name)}', this.value)"></label>
          ${ownColor ? `<button type="button" class="secondary" onclick="resetConfiguredWorkplaceColor('${escapeJs(item.name)}')">Цвет цеха</button>` : ""}
          <button type="button" class="secondary" onclick="openWorkplaceRulesSettings('${escapeJs(item.name)}')">Нормы</button>
          <button type="button" class="danger" onclick="deleteConfiguredWorkplace('${escapeJs(item.name)}')">Удалить</button>
        </div>
      </div>`;
    }).join("");
  const availableRuleWorkplaces = settingsWorkplaceRows();
  if (!availableRuleWorkplaces.some((item) => item.name === selectedSettingsRulesWorkplace)) {
    selectedSettingsRulesWorkplace = availableRuleWorkplaces[0]?.name || "";
  }
  const selectedRuleWorkplace = availableRuleWorkplaces.find((item) => item.name === selectedSettingsRulesWorkplace);
  const selectedRulePath = selectedRuleWorkplace
    ? [
      sectionById.get(selectedRuleWorkplace.sectionId)?.name,
      selectedRuleWorkplace.name,
    ].filter(Boolean).join(" → ")
    : "";
  const workplaceRuleOptions = availableRuleWorkplaces.map((item) => {
    const path = [
      sectionById.get(item.sectionId)?.name,
      item.name,
    ].filter(Boolean).join(" → ");
    return `<option value="${escapeHtml(item.name)}" ${item.name === selectedSettingsRulesWorkplace ? "selected" : ""}>${escapeHtml(path)}</option>`;
  }).join("");
  const workplaceRulesEditor = selectedSettingsRulesWorkplace
    ? renderWorkplaceRulesEditor(selectedSettingsRulesWorkplace)
    : `<div class="settings-empty-workplaces">Сначала добавьте рабочее место.</div>`;
  const departmentDeleteControl = activeDepartment?.id === DEFAULT_DEPARTMENT_ID
    ? `<span class="settings-system-badge">Основное подразделение</span>`
    : `<button type="button" class="danger" onclick="deleteConfiguredDepartment('${escapeJs(activeDepartment?.id || "")}')">Удалить подразделение</button>`;

  const panels = {
    workplaces: `<section class="settings-section" data-settings-section="workplaces">
      ${panelHeading("Рабочие места", "Настройка структуры по порядку: подразделение, участок, затем рабочее место.")}
      <ol class="settings-workflow-steps" aria-label="Порядок настройки">
        <li><div><strong>Подразделение</strong><span>Выберите или создайте цех</span></div></li>
        <li><div><strong>Участок</strong><span>Уточните часть подразделения</span></div></li>
        <li><div><strong>Рабочее место</strong><span>Добавьте печь или другое место</span></div></li>
      </ol>
      <form class="settings-add-department" onsubmit="addConfiguredDepartment(event)">
        <label>Новое подразделение<input id="settingsDepartmentName" required placeholder="Например: Цех 7"></label>
        <label class="settings-new-color-control"><span>Цвет</span><input id="settingsDepartmentColor" type="color" value="${escapeHtml(newDepartmentColor)}" aria-label="Цвет нового подразделения"></label>
        <button type="submit">Создать подразделение</button>
      </form>
      <nav class="settings-department-tabs" aria-label="Подразделения">${departmentTabs}</nav>
      <div class="settings-department-panel" style="--settings-department-color:${escapeHtml(activeDepartmentColor)}">
        <div class="settings-department-heading">
          <div><span>Подразделение</span><h4>${escapeHtml(activeDepartment?.name || "")}</h4></div>
          <div class="settings-department-heading-actions">
            <label class="settings-department-color-control"><span>Цвет рабочих мест</span><input type="color" value="${escapeHtml(activeDepartmentColor)}" aria-label="Цвет подразделения ${escapeHtml(activeDepartment?.name || "")}" onchange="updateConfiguredDepartmentColor('${escapeJs(activeDepartment?.id || "")}', this.value)"></label>
            ${departmentDeleteControl}
          </div>
        </div>
        <p class="settings-department-color-note">Этот цвет используется в статистике для всех рабочих мест подразделения. Для отдельного места ниже можно выбрать свой цвет.</p>
        <form class="settings-add-section" onsubmit="addConfiguredSection(event)">
          <label>Новый участок<input id="settingsSectionName" required placeholder="Например: Печи"></label>
          <button type="submit">Добавить участок</button>
        </form>
        <nav class="settings-section-tabs" aria-label="Участки подразделения">${sectionTabs || `<div class="settings-empty-workplaces">Сначала добавьте участок.</div>`}</nav>
        ${activeSection ? `<div class="settings-section-workplaces">
          <div class="settings-department-heading">
            <div><span>Участок</span><h4>${escapeHtml(activeSection.name)}</h4></div>
            <button type="button" class="danger" onclick="deleteConfiguredSection('${escapeJs(activeSection.id)}')">Удалить участок</button>
          </div>
          <div class="settings-path">${escapeHtml(activeDepartment?.name || "")} <span>→</span> ${escapeHtml(activeSection.name)}</div>
          <form class="settings-add-workplace" onsubmit="addConfiguredWorkplace(event)">
            <label>Новое рабочее место<input id="settingsWorkplaceName" required placeholder="Например: Печь 41 или Сортировка"></label>
            <label class="settings-new-color-control"><span>Цвет</span><input id="settingsWorkplaceColor" type="color" value="${escapeHtml(activeDepartmentColor)}" aria-label="Цвет нового рабочего места"></label>
            <button type="submit">Добавить рабочее место</button>
          </form>
          <div class="settings-workplace-list">${workplaceRows || `<div class="settings-empty-workplaces">На участке пока нет рабочих мест.</div>`}</div>
        </div>` : ""}
      </div>
    </section>`,

    people: `<section class="settings-section" data-settings-section="people">
      ${panelHeading("Люди", "Управление штатным списком, телефонами и цветовым отображением сотрудников.")}
      <div class="settings-action-grid">
        <article class="settings-action-card">
          <div><span>Штат</span><strong>${activeEmployees.length} активных сотрудников</strong><p>Приём, перевод, увольнение и фильтры по рабочим местам.</p></div>
          <button type="button" onclick="openSettingsStartPanel('staff')">Открыть единый штат</button>
        </article>
        <article class="settings-action-card">
          <div><span>Телефоны</span><strong>${phoneCount} номеров сохранено</strong><p>Номера сотрудников по бригадам и рабочим местам.</p></div>
          <button type="button" class="secondary" onclick="openSettingsStartPanel('phones')">Открыть телефоны</button>
        </article>
      </div>
      <div class="settings-subsection-heading"><div><h4>Цветовые обозначения</h4><p>Эти цвета одинаковы на всех устройствах.</p></div>${scopeBadge("shared", "Для всех устройств")}</div>
      <div class="settings-highlight-grid settings-color-cards">
        <article class="settings-color-card">
          ${settingsSwitch("highlightSubworkers", "Подсвечивать подработчиков", settings.highlightSubworkers !== false)}
          <label class="color-setting"><span>Цвет подработчиков</span><input type="color" value="${escapeHtml(settings.subworkerColor)}" ${settings.highlightSubworkers === false ? "disabled" : ""} onchange="updateSharedSetting('subworkerColor', this.value)"></label>
        </article>
        <article class="settings-color-card">
          ${settingsSwitch("highlightProletchik", "Подсвечивать пролётчика", settings.highlightProletchik !== false)}
          <label class="color-setting"><span>Цвет пролётчика</span><input type="color" value="${escapeHtml(settings.proletchikColor)}" ${settings.highlightProletchik === false ? "disabled" : ""} onchange="updateSharedSetting('proletchikColor', this.value)"></label>
        </article>
        <article class="settings-color-card">
          ${settingsSwitch("highlightCapitalRepair", "Подсвечивать капремонт", settings.highlightCapitalRepair !== false)}
          <label class="color-setting"><span>Цвет капремонта</span><input type="color" value="${escapeHtml(settings.capitalRepairColor)}" ${settings.highlightCapitalRepair === false ? "disabled" : ""} onchange="updateSharedSetting('capitalRepairColor', this.value)"></label>
        </article>
      </div>
    </section>`,

    colors: `<section class="settings-section" data-settings-section="colors">
      ${panelHeading("Цветовые обозначения", "Настройка цветов специальных работ.")}
      <div class="settings-highlight-grid settings-color-cards">
        <article class="settings-color-card">
          ${settingsSwitch("highlightSubworkers", "Подсвечивать подработчиков", settings.highlightSubworkers !== false)}
          <label class="color-setting"><span>Цвет подработчиков</span><input type="color" value="${escapeHtml(settings.subworkerColor)}" ${settings.highlightSubworkers === false ? "disabled" : ""} onchange="updateSharedSetting('subworkerColor', this.value)"></label>
        </article>
        <article class="settings-color-card">
          ${settingsSwitch("highlightProletchik", "Подсвечивать пролётчика", settings.highlightProletchik !== false)}
          <label class="color-setting"><span>Цвет пролётчика</span><input type="color" value="${escapeHtml(settings.proletchikColor)}" ${settings.highlightProletchik === false ? "disabled" : ""} onchange="updateSharedSetting('proletchikColor', this.value)"></label>
        </article>
        <article class="settings-color-card">
          ${settingsSwitch("highlightCapitalRepair", "Подсвечивать капремонт", settings.highlightCapitalRepair !== false)}
          <label class="color-setting"><span>Цвет капремонта</span><input type="color" value="${escapeHtml(settings.capitalRepairColor)}" ${settings.highlightCapitalRepair === false ? "disabled" : ""} onchange="updateSharedSetting('capitalRepairColor', this.value)"></label>
        </article>
      </div>
    </section>`,

    forms: `<section class="settings-section" data-settings-section="forms">
      ${panelHeading("Бланки", "Каждый вид бланка настраивается и сортируется отдельно.")}
      <div class="settings-form-list">
        <article class="settings-form-card">
          <div class="settings-form-card-heading"><div><span>01</span><h4>Переводы</h4></div><p>Какие назначения попадут в переводной бланк.</p></div>
          <div class="settings-switch-list">
            ${settingsSwitch("transferIncludeStandardWork", "Штатная работа на своём месте и по своему разряду", settings.transferIncludeStandardWork === true, true)}
            ${settingsSwitch("transferIncludeSubworkers", "Подработчики", settings.transferIncludeSubworkers !== false, true)}
            ${settingsSwitch("transferIncludeDifferentWorkplace", "Работа на другом рабочем месте", settings.transferIncludeDifferentWorkplace !== false, true)}
            ${settingsSwitch("transferIncludeDifferentGrade", "Работа по другому разряду", settings.transferIncludeDifferentGrade !== false, true)}
            ${settingsSwitch("transferMergeConsecutiveShifts", "Объединять соседние смены в один период", settings.transferMergeConsecutiveShifts !== false, true)}
          </div>
          ${formSortSettingsMarkup("transfer", "Переводы", settings)}
        </article>
        <article class="settings-form-card">
          <div class="settings-form-card-heading"><div><span>02</span><h4>Ремонт / разогрев</h4></div><p>Группировка и порядок строк ремонтных работ.</p></div>
          <div class="settings-switch-list">
            ${settingsSwitch("repairMergeConsecutiveShifts", "Объединять соседние смены ремонта и разогрева", settings.repairMergeConsecutiveShifts !== false, true)}
          </div>
          ${formSortSettingsMarkup("repair", "Ремонт / разогрев", settings)}
        </article>
        <article class="settings-form-card">
          <div class="settings-form-card-heading"><div><span>03</span><h4>Встречно-сменные</h4></div><p>Состав сотрудников и порядок строк.</p></div>
          <div class="settings-switch-list">
            ${settingsSwitch("meetingIncludeEmployeesWithoutShifts", "Добавлять сотрудников без смен", settings.meetingIncludeEmployeesWithoutShifts !== false, true)}
          </div>
          ${formSortSettingsMarkup("meeting", "Встречно-сменные", settings)}
        </article>
        <article class="settings-form-card">
          <div class="settings-form-card-heading"><div><span>04</span><h4>Отпуска</h4></div><p>Порядок сотрудников в графике отпусков.</p></div>
          ${formSortSettingsMarkup("vacation", "Отпуска", settings)}
        </article>
      </div>
      <div class="settings-info-card"><strong>Как применяются изменения</strong><span>Новый состав и сортировка видны на этом устройстве сразу. Нажмите «Сохранить» сверху, чтобы передать настройки на другие устройства. Пустые строки остаются внизу бланка.</span></div>
    </section>`,

    rules: `<section class="settings-section" data-settings-section="rules">
      ${panelHeading("Правила", "Ограничения назначений и нормы комплектации рабочих мест.")}
      <div class="settings-rule-groups settings-rule-groups-focused">
        <section class="settings-rule-group">
          <div class="settings-section-heading"><h4>Контроль назначений</h4><p>Как программа реагирует на нехватку и превышение нормы.</p></div>
          <div class="settings-switch-list">
            ${settingsSwitch("enforceGradeMaximums", "Запрещать превышение максимума по разрядам", settings.enforceGradeMaximums !== false, true)}
            ${settingsSwitch("enforceSpecialRoleMaximums", "Запрещать превышение максимума специальных работ", settings.enforceSpecialRoleMaximums !== false, true)}
            ${settingsSwitch("showMinimumStaffingWarnings", "Показывать нехватку по минимальным нормам", settings.showMinimumStaffingWarnings !== false, true)}
          </div>
        </section>
        <section class="settings-rule-group settings-rule-workplace-card">
          <div class="settings-section-heading"><h4>Нормы рабочего места</h4><p>Выберите место и задайте минимумы и максимумы по разрядам, спецработам и должностям.</p></div>
          ${availableRuleWorkplaces.length ? `<label class="settings-rule-picker">Рабочее место<select onchange="selectWorkplaceRules(this.value)">${workplaceRuleOptions}</select></label>
            <div class="settings-path">${escapeHtml(selectedRulePath)}</div>
            ${workplaceRulesEditor}` : workplaceRulesEditor}
        </section>
      </div>
      <div class="settings-info-card"><strong>Специальные работы и должности</strong><span>У каждого подразделения свой набор ролей. Можно создавать новые, менять название и цвет, удалять из выбранного подразделения и возвращать обратно. Старые смены и статистика при этом сохраняются.</span></div>
      <div class="settings-footer-actions"><button type="button" class="secondary" onclick="setSettingsViewMode('workplaces')">Перейти к рабочим местам</button></div>
    </section>`,

    instructions: `<section class="settings-section" data-settings-section="instructions">
      ${panelHeading("Инструкции", "Короткие подсказки по основным задачам программы.", "info", "Справка")}
      <div class="settings-quick-start">
        <h4>Быстрый старт</h4>
        <ol><li>Создайте или выберите рабочие места.</li><li>Проверьте штат и телефоны сотрудников.</li><li>Настройте состав и сортировку каждого бланка.</li><li>Задайте лимиты отпусков и нормы рабочих мест.</li><li>Нажмите «Сохранить», чтобы синхронизировать общие изменения.</li></ol>
      </div>
      <div class="settings-guide">
        <details open><summary>Как добавить рабочее место</summary><div><p>Откройте «Рабочие места». Выберите подразделение, затем участок и введите название нового места.</p><button type="button" class="secondary" onclick="setSettingsViewMode('workplaces')">Открыть рабочие места</button></div></details>
        <details><summary>Где принять, перевести или уволить сотрудника</summary><div><p>Откройте «Люди» и нажмите «Открыть единый штат». Все кадровые действия находятся там.</p><button type="button" class="secondary" onclick="setSettingsViewMode('people')">Открыть раздел «Люди»</button></div></details>
        <details><summary>Как настроить бланки отдельно</summary><div><p>В разделе «Бланки» есть четыре самостоятельные карточки: переводы, ремонт / разогрев, встречно-сменные и отпуска.</p><button type="button" class="secondary" onclick="setSettingsViewMode('forms')">Открыть настройки бланков</button></div></details>
        <details><summary>Где изменить лимит отпусков</summary><div><p>Выберите год, бригаду и месяц в разделе «Отпуска». Значение «Все» создаёт общее правило.</p><button type="button" class="secondary" onclick="setSettingsViewMode('vacation')">Открыть отпуска</button></div></details>
        <details><summary>Как задать нормы рабочего места</summary><div><p>В разделе «Правила» выберите рабочее место, затем укажите минимум и максимум для каждого разряда.</p><button type="button" class="secondary" onclick="setSettingsViewMode('rules')">Открыть правила</button></div></details>
        <details><summary>Как настроить спецработы и должности</summary><div><p>В разделе «Правила» выберите рабочее место нужного подразделения. Там можно создать, переименовать, перекрасить, удалить или вернуть любую роль. Изменение состава действует только в выбранном подразделении, а старые записи сохраняются.</p><button type="button" class="secondary" onclick="setSettingsViewMode('rules')">Открыть правила</button></div></details>
        <details><summary>Что сохраняется на всех устройствах</summary><div><p>Разделы с меткой «Для всех устройств» сохраняются в общих данных. Настройки с меткой «На этом устройстве» остаются только на текущем телефоне, планшете или компьютере.</p></div></details>
      </div>
    </section>`,

    statistics: `<section class="settings-section" data-settings-section="statistics">
      ${panelHeading("Статистика", "Выберите стартовый отчёт и виды работ, которые участвуют в расчётах.")}
      <label>Раздел при открытии<select onchange="updateSharedSetting('statisticsDefaultMode', this.value)">
        <option value="month" ${settings.statisticsDefaultMode === "month" ? "selected" : ""}>Общая статистика за месяц</option>
        <option value="shift" ${settings.statisticsDefaultMode === "shift" ? "selected" : ""}>По сменам</option>
        <option value="employee" ${settings.statisticsDefaultMode === "employee" ? "selected" : ""}>Индивидуальная за месяц</option>
        <option value="sick" ${settings.statisticsDefaultMode === "sick" ? "selected" : ""}>Больничный за месяц</option>
        <option value="proletchik" ${settings.statisticsDefaultMode === "proletchik" ? "selected" : ""}>Пролётчик</option>
        <option value="subworker" ${settings.statisticsDefaultMode === "subworker" ? "selected" : ""}>Подработчик</option>
        <option value="capital-repair" ${settings.statisticsDefaultMode === "capital-repair" ? "selected" : ""}>Капремонт</option>
      </select></label>
      <div class="settings-switch-list">
        ${settingsSwitch("statsIncludeProletchik", "Показывать с пролётчиком", settings.statsIncludeProletchik !== false)}
        ${settingsSwitch("statsIncludeSubworkers", "Показывать с подработчиками", settings.statsIncludeSubworkers !== false)}
        ${settingsSwitch("statsIncludeCapitalRepair", "Показывать с капремонтом", settings.statsIncludeCapitalRepair !== false)}
        ${settingsSwitch("statsIncludeRepair", "Показывать ремонт", settings.statsIncludeRepair !== false)}
        ${settingsSwitch("statsIncludeWarmup", "Показывать разогрев", settings.statsIncludeWarmup !== false)}
        ${settingsSwitch("statsShowZeroRows", "Показывать строки с нулевыми значениями", settings.statsShowZeroRows !== false)}
      </div>
    </section>`,

    appearance: `<section class="settings-section" data-settings-section="appearance">
      ${panelHeading("Внешний вид", "Размер, плотность и тема интерфейса текущего устройства.", "device", "На этом устройстве")}
      <div class="settings-grid two-columns">
        <label>Режим экрана<select onchange="updateDevicePreference('displayMode', this.value)">
          <option value="auto" ${devicePreferences.displayMode === "auto" ? "selected" : ""}>Автоматически</option>
          <option value="phone" ${devicePreferences.displayMode === "phone" ? "selected" : ""}>Смартфон</option>
          <option value="tablet" ${devicePreferences.displayMode === "tablet" ? "selected" : ""}>Планшет</option>
          <option value="desktop" ${devicePreferences.displayMode === "desktop" ? "selected" : ""}>Компьютер</option>
        </select></label>
        <label>Размер элементов<select onchange="updateDevicePreference('interfaceDensity', this.value)">
          <option value="compact" ${devicePreferences.interfaceDensity === "compact" ? "selected" : ""}>Компактный</option>
          <option value="comfortable" ${devicePreferences.interfaceDensity === "comfortable" ? "selected" : ""}>Обычный</option>
          <option value="spacious" ${devicePreferences.interfaceDensity === "spacious" ? "selected" : ""}>Крупный</option>
        </select></label>
        <label>Оформление<select onchange="updateDevicePreference('theme', this.value)">
          <option value="light" ${devicePreferences.theme === "light" ? "selected" : ""}>Светлое</option>
          <option value="dark" ${devicePreferences.theme === "dark" ? "selected" : ""}>Тёмное</option>
          <option value="contrast" ${devicePreferences.theme === "contrast" ? "selected" : ""}>Высокая контрастность</option>
        </select></label>
      </div>
      <div class="settings-info-card"><strong>Применено сейчас</strong><span>${devicePreferences.displayMode === "auto" ? "Режим определяется автоматически" : `Профиль «${devicePreferences.displayMode === "phone" ? "Смартфон" : devicePreferences.displayMode === "tablet" ? "Планшет" : "Компьютер"}»`} · ${devicePreferences.interfaceDensity === "compact" ? "компактный" : devicePreferences.interfaceDensity === "spacious" ? "крупный" : "обычный"} размер · ${devicePreferences.theme === "dark" ? "тёмная" : devicePreferences.theme === "contrast" ? "контрастная" : "светлая"} тема.</span></div>
    </section>`,

    data: `<section class="settings-section admin-settings-section" data-settings-section="data">
      ${panelHeading("Данные и доступ", "Хранение на текущем устройстве, синхронизация и защищённые действия.", "device", "Смешанные настройки")}
      <div class="settings-data-grid">
        <section class="settings-data-card">
          <div class="settings-subsection-heading"><div><h4>Хранение и синхронизация</h4><p>Параметры только этого устройства.</p></div>${scopeBadge("device", "На этом устройстве")}</div>
          <div class="settings-switch-list">
            <label class="settings-switch"><input type="checkbox" ${devicePreferences.localStorageEnabled !== false ? "checked" : ""} onchange="updateDevicePreference('localStorageEnabled', this.checked)"><span>Сохранять данные локально</span></label>
            <label class="settings-switch"><input type="checkbox" ${devicePreferences.serverStorageEnabled !== false ? "checked" : ""} onchange="updateDevicePreference('serverStorageEnabled', this.checked)"><span>Использовать серверную синхронизацию</span></label>
            <label class="settings-switch"><input type="checkbox" ${devicePreferences.startupSyncEnabled !== false ? "checked" : ""} onchange="updateDevicePreference('startupSyncEnabled', this.checked)"><span>Синхронизировать при запуске</span></label>
          </div>
        </section>
        <section class="settings-data-card">
          <div class="settings-subsection-heading"><div><h4>Пароль администратора</h4><p>Защищает правила, штат и удаление данных.</p></div>${scopeBadge("admin", "Требуется пароль")}</div>
          <button type="button" class="secondary" onclick="changeAdminPassword()">Изменить пароль администратора</button>
        </section>
      </div>
      <details class="settings-danger-zone">
        <summary>Опасные действия</summary>
        <div class="settings-danger-zone-body">
          <p>Удаление выполняется только после пароля и подтверждения. Настройки программы при этом сохраняются.</p>
          <div class="settings-period-delete">
            <label>Год<select id="settingsDeleteYear" aria-label="Год для удаления"><option value="*">Все годы</option>${deleteYearOptions}</select></label>
            <label>Месяц<select id="settingsDeleteMonth" aria-label="Месяц для удаления"><option value="">Весь год</option>${deleteMonthOptions}</select></label>
            <button type="button" class="danger" data-no-auto-sync="true" onclick="deleteOperationalPeriod()">Удалить данные выбранного периода</button>
          </div>
          <button type="button" class="danger danger-strong" data-no-auto-sync="true" onclick="deleteAllApplicationData()">Удалить рабочие данные и весь активный штат</button>
          <p class="settings-danger-note">После удаления нажмите «Сохранить» сверху, чтобы синхронизировать его с другими устройствами.</p>
        </div>
      </details>
    </section>`,

    about: `<section class="settings-section" data-settings-section="about">
      ${panelHeading("О программе", "Табель рабочих мест для планирования смен и подготовки бланков.", "info", "Справка")}
      <div class="settings-about-grid">
        <div><span>Версия</span><strong>${escapeHtml(APP_VERSION)}</strong></div>
        <div><span>Разработчик</span><strong>Борисов А.С.</strong></div>
        <div><span>Устройство</span><strong>${escapeHtml(document.body.dataset.screenProfile || "автоматически")}</strong></div>
        <div><span>Сервер</span><strong>${devicePreferences.serverStorageEnabled === false ? "отключён" : "включён"}</strong></div>
      </div>
      <div class="settings-info-card"><strong>Назначение</strong><span>Учёт рабочих мест, смен, отсутствий, отпусков, статистики и четырёх видов производственных бланков.</span></div>
    </section>`,
  };

  const navGroup = (title, tabs) => `<div class="app-settings-nav-group">
    <span class="app-settings-nav-group-title">${escapeHtml(title)}</span>
    ${tabs.map((tab) => `<button type="button" class="app-settings-nav-button ${settingsViewMode === tab.key ? "active" : ""}" aria-current="${settingsViewMode === tab.key ? "page" : "false"}" onclick="setSettingsViewMode('${tab.key}')">
      <span class="app-settings-nav-copy"><strong>${escapeHtml(tab.label)}</strong><small>${escapeHtml(tab.description)}</small></span>
    </button>`).join("")}
  </div>`;
  const showSettingsNavigation = !["colors", "forms", "statistics"].includes(settingsViewMode);
  root.innerHTML = `<div class="app-settings-layout${showSettingsNavigation ? "" : " app-settings-layout-focused"}">
    ${showSettingsNavigation ? `<aside class="app-settings-sidebar" aria-label="Разделы настроек">
      <div class="app-settings-sidebar-heading"><strong>Настройки</strong><span>Выберите задачу</span></div>
      <nav class="app-settings-nav">${navGroup("Основные", primaryTabs)}${navGroup("Дополнительно", secondaryTabs)}</nav>
    </aside>` : ""}
    <div class="app-settings-content">
      ${showSettingsNavigation ? `<div class="app-settings-menu">
        <nav class="app-settings-mobile-nav" aria-label="Разделы настроек">
          ${navGroup("Основные", primaryTabs)}
          ${navGroup("Дополнительно", secondaryTabs)}
        </nav>
      </div>` : ""}
      <div class="settings-tab-panel" id="settingsTabPanel" tabindex="-1">${panels[settingsViewMode] || panels[allTabs[0].key]}</div>
    </div>
  </div>`;
}

function updateDevicePreference(key, value) {
  devicePreferences = { ...devicePreferences, [key]: value };
  saveDevicePreferences();
  if (key === "localStorageEnabled" && value !== false) localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  if (devicePreferences.localStorageEnabled === false && devicePreferences.serverStorageEnabled === false) {
    showAppMessage("Хранение отключено", "Локальное и серверное сохранение выключены. Новые изменения сохранятся только до закрытия приложения.");
  }
  applyScreenProfile();
  renderActiveView(activeView);
}

function updateSharedSetting(key, value, adminRequired = false) {
  if (adminRequired && !requireStaffAdmin(`изменить правило «${key}»`)) return renderAppSettings();
  state.appSettings = { ...appSettings(), [key]: value };
  saveState();
  applyDevicePreferences();
  if (key === "statisticsDefaultMode") statsMode = value;
  renderAppSettings();
}

function gradeRuleSelectOptions(selected, unlimited = false) {
  const values = Array.from({ length: 31 }, (_, index) => index);
  return `${unlimited ? `<option value="" ${selected === null ? "selected" : ""}>Без ограничения</option>` : ""}${values
    .map((value) => `<option value="${value}" ${Number(selected) === value ? "selected" : ""}>${value}</option>`).join("")}`;
}

function renderWorkplaceRulesEditor(place) {
  const settings = appSettings();
  const rules = workplaceGradeRuleSet(place);
  const specialRules = workplaceSpecialRuleSet(place);
  const department = configuredDepartmentForWorkplace(place, settings);
  const departmentId = department?.id || "";
  const roleDefinitions = specialRoleDefinitionsForDepartment(departmentId, settings);
  return `<section class="settings-rule-editor">
    <div class="settings-section-heading">
      <h4>Нормы рабочего места: ${escapeHtml(place)}</h4>
      <p>Минимум используется для контроля комплектации, «не более» запрещает лишнее назначение.</p>
    </div>
    <form onsubmit="saveWorkplaceRules(event, '${escapeJs(place)}')">
      <div class="settings-rules-header"><span>Разряд</span><span>Минимум</span><span>Не более</span></div>
      ${[7, 6, 5, 4, 3].map((grade) => `<div class="settings-rule-row">
        <strong>${grade} разряд</strong>
        <select name="grade-${grade}-minimum" aria-label="${grade} разряд минимум">${gradeRuleSelectOptions(rules[String(grade)].minimum)}</select>
        <select name="grade-${grade}-maximum" aria-label="${grade} разряд не более">${gradeRuleSelectOptions(rules[String(grade)].maximum, true)}</select>
      </div>`).join("")}
      <div class="settings-special-work">
        <h4>Спецработы и должности рабочего места</h4>
        <p>Минимум и «не более» ниже относятся только к месту «${escapeHtml(place)}». Старые записи сохраняются.</p>
        <div class="settings-special-work-list">
          ${roleDefinitions.map((role) => `<article class="settings-special-work-card">
            <div class="settings-special-work-card-head">
              <div class="settings-special-work-identity">
                <strong class="settings-special-work-name">${escapeHtml(role.name)}</strong>
              </div>
            </div>
            <div class="settings-special-work-norms">
              <label>Минимум<select name="role-${escapeHtml(role.id)}-minimum" aria-label="${escapeHtml(role.name)} минимум">${gradeRuleSelectOptions(specialRules[role.id]?.minimum || 0)}</select></label>
              <label>Не более<select name="role-${escapeHtml(role.id)}-maximum" aria-label="${escapeHtml(role.name)} не более">${gradeRuleSelectOptions(specialRules[role.id]?.maximum ?? null, true)}</select></label>
            </div>
            <div class="settings-special-work-actions">
              <button type="button" class="danger" onclick="setDepartmentSpecialRoleEnabled('${escapeJs(role.id)}', false, '${escapeJs(place)}')">Удалить</button>
            </div>
          </article>`).join("") || `<div class="settings-special-work-empty">В этом подразделении пока нет специальных работ и должностей. Создайте новую роль или добавьте ранее созданную ниже.</div>`}
        </div>
        <p class="settings-special-work-shared-note">Название и цвет роли общие для всех подразделений, где она используется. Изменение не удаляет и не переписывает старые смены.</p>
      </div>
      <button type="submit">Сохранить роли и нормы для «${escapeHtml(place)}»</button>
    </form>
  </section>`;
}

function workplaceRulesHaveUnsavedDraft(place) {
  const form = document.querySelector(".settings-rule-editor > form");
  if (!form) return false;
  const gradeRules = workplaceGradeRuleSet(place);
  for (const grade of [3, 4, 5, 6, 7]) {
    const minimum = Math.max(0, Number(form.elements[`grade-${grade}-minimum`]?.value || 0));
    const maximumValue = form.elements[`grade-${grade}-maximum`]?.value ?? "";
    const maximum = maximumValue === "" ? null : Math.max(0, Number(maximumValue));
    const saved = gradeRules[String(grade)];
    if (minimum !== saved.minimum || maximum !== saved.maximum) return true;
  }
  const settings = appSettings();
  const specialRules = workplaceSpecialRuleSet(place);
  const departmentId = configuredDepartmentIdForWorkplace(place, settings);
  for (const role of specialRoleDefinitionsForDepartment(departmentId, settings)) {
    const name = String(form.elements[`role-${role.id}`]?.value || "").replace(/\s+/g, " ").trim().slice(0, 80);
    const color = normalizeStructureColor(form.elements[`role-${role.id}-color`]?.value, role.color);
    const minimum = Math.max(0, Number(form.elements[`role-${role.id}-minimum`]?.value || 0));
    const maximumValue = form.elements[`role-${role.id}-maximum`]?.value ?? "";
    const maximum = maximumValue === "" ? null : Math.max(0, Number(maximumValue));
    const saved = specialRules[role.id] || { minimum: 0, maximum: null };
    if (name !== role.name || color !== role.color || minimum !== saved.minimum || maximum !== saved.maximum) return true;
  }
  return false;
}

function ensureWorkplaceRulesSavedBeforeRoleChange(place) {
  if (!workplaceRulesHaveUnsavedDraft(place)) return true;
  showAppMessage(
    "Сначала сохраните изменения",
    "В нормах, названиях или цветах есть несохранённые изменения. Нажмите «Сохранить нормы рабочего места», затем добавьте, уберите или верните должность."
  );
  return false;
}

function settingsWithDepartmentSpecialRoleEnabled(settings, departmentId, roleValue, enabled, updatedAt = new Date().toISOString()) {
  const roleId = canonicalSpecialRoleId(roleValue);
  const cleanDepartmentId = String(departmentId || "").trim();
  if (!roleId || !cleanDepartmentId) return settings;
  const departmentSpecialRoleStates = {
    ...(settings.departmentSpecialRoleStates || {}),
    [cleanDepartmentId]: {
      ...(settings.departmentSpecialRoleStates?.[cleanDepartmentId] || {}),
      [roleId]: { enabled: enabled === true, updatedAt },
    },
  };
  const enabledCustomRoleIds = new Set();
  Object.values(departmentSpecialRoleStates).forEach((roleStates) => {
    Object.entries(roleStates || {}).forEach(([candidateRoleId, roleState]) => {
      if (roleState?.enabled === true && normalizeCustomSpecialRoleId(candidateRoleId)) enabledCustomRoleIds.add(candidateRoleId);
    });
  });
  const customSpecialRoles = configuredCustomSpecialRoles(settings, { includeArchived: true }).map((role) => {
    const archived = !enabledCustomRoleIds.has(role.id);
    return archived === role.archived ? role : { ...role, archived, updatedAt };
  });
  return {
    ...settings,
    specialRoleScopeVersion: SPECIAL_ROLE_SCOPE_VERSION,
    departmentSpecialRoleStates,
    customSpecialRoles,
  };
}

function addCustomSpecialRole(place = "") {
  if (!ensureWorkplaceRulesSavedBeforeRoleChange(place)) return;
  if (!requireStaffAdmin("добавить специальную работу или должность")) return;
  const name = String($("settingsNewSpecialRoleName")?.value || "").replace(/\s+/g, " ").trim().slice(0, 80);
  if (!name) {
    showAppMessage("Специальные работы", "Укажите название новой работы или должности.");
    return;
  }
  const settings = appSettings();
  const department = configuredDepartmentForWorkplace(place, settings);
  if (!department) {
    showAppMessage("Специальные работы", "Не удалось определить подразделение выбранного рабочего места.");
    return;
  }
  const allDefinitions = specialRoleDefinitions(settings, { includeArchived: true });
  const duplicate = allDefinitions.find((role) => role.name.toLocaleLowerCase("ru") === name.toLocaleLowerCase("ru"));
  if (duplicate) {
    if (specialRoleEnabledForDepartment(duplicate.id, department.id, settings)) {
      showAppMessage("Специальные работы", `«${name}» уже используется в подразделении «${department.name}».`);
      return;
    }
    if (!confirm(`Роль «${name}» уже создана, но не используется в подразделении «${department.name}». Добавить её?`)) return;
    state.appSettings = settingsWithDepartmentSpecialRoleEnabled(settings, department.id, duplicate.id, true);
    saveState();
    applyDevicePreferences();
    selectedSettingsRulesWorkplace = place || selectedSettingsRulesWorkplace;
    showAppMessage("Специальные работы", `Роль «${name}» добавлена в подразделение «${department.name}». Ранее заданные нормы сохранены.`);
    renderAppSettings();
    return;
  }
  const randomPart = String(globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`)
    .toLowerCase().replace(/[^a-z0-9-]+/g, "-");
  const id = normalizeCustomSpecialRoleId(`${CUSTOM_SPECIAL_ROLE_PREFIX}${randomPart}`);
  if (!id) {
    showAppMessage("Специальные работы", "Не удалось создать безопасный идентификатор. Повторите добавление.");
    return;
  }
  const color = normalizeStructureColor(
    $("settingsNewSpecialRoleColor")?.value,
    suggestedCustomSpecialRoleColor(configuredCustomSpecialRoles(settings, { includeArchived: true }).length)
  );
  const settingsWithRole = {
    ...settings,
    customSpecialRoles: [
      ...configuredCustomSpecialRoles(settings, { includeArchived: true }),
      { id, name, color, archived: true, updatedAt: new Date().toISOString() },
    ],
  };
  state.appSettings = settingsWithDepartmentSpecialRoleEnabled(settingsWithRole, department.id, id, true);
  saveState();
  applyDevicePreferences();
  selectedSettingsRulesWorkplace = place || selectedSettingsRulesWorkplace;
  showAppMessage("Специальные работы", `Роль «${name}» создана и добавлена в подразделение «${department.name}». Задайте нормы для выбранного рабочего места.`);
  renderAppSettings();
}

function setDepartmentSpecialRoleEnabled(roleValue, enabled, place = "") {
  if (!ensureWorkplaceRulesSavedBeforeRoleChange(place)) return;
  const id = canonicalSpecialRoleId(roleValue);
  const settings = appSettings();
  const role = specialRoleDefinition(id, settings, { includeArchived: true });
  const department = configuredDepartmentForWorkplace(place, settings);
  if (!role || !department) return;
  const action = enabled ? `добавить «${role.name}» в «${department.name}»` : `удалить «${role.name}» из «${department.name}»`;
  if (!requireStaffAdmin(action)) return;
  if (!enabled && !confirm(`Удалить роль «${role.name}» из подразделения «${department.name}»?\nОна исчезнет только из новых назначений этого подразделения. Старые записи, статистика и нормы сохранятся. В других подразделениях ничего не изменится.`)) return;
  state.appSettings = settingsWithDepartmentSpecialRoleEnabled(settings, department.id, id, enabled === true);
  saveState();
  applyDevicePreferences();
  selectedSettingsRulesWorkplace = place || selectedSettingsRulesWorkplace;
  showAppMessage("Специальные работы", enabled
    ? `Роль «${role.name}» снова доступна в подразделении «${department.name}». Ранее заданные нормы сохранены.`
    : `Роль «${role.name}» удалена из подразделения «${department.name}». История сохранена.`);
  renderAppSettings();
}

function setCustomSpecialRoleArchived(roleId, archived, place = "") {
  setDepartmentSpecialRoleEnabled(roleId, archived !== true, place);
}

function selectWorkplaceRules(place) {
  selectedSettingsRulesWorkplace = String(place || "");
  renderAppSettings();
  document.querySelector(".settings-rule-editor")?.scrollIntoView({ behavior: "smooth", block: "start" });
}

function saveWorkplaceRules(event, place) {
  event.preventDefault();
  if (!requireStaffAdmin(`изменить правила рабочего места ${place}`)) return;
  const form = event.currentTarget;
  const gradeRules = {};
  for (const grade of [3, 4, 5, 6, 7]) {
    const minimum = Math.max(0, Number(form.elements[`grade-${grade}-minimum`]?.value || 0));
    const maximumValue = form.elements[`grade-${grade}-maximum`]?.value ?? "";
    const maximum = maximumValue === "" ? null : Math.max(0, Number(maximumValue));
    if (maximum !== null && maximum < minimum) {
      showAppMessage("Правила разрядов", `${grade} разряд: значение «не более» не может быть меньше минимума.`);
      return;
    }
    gradeRules[String(grade)] = { minimum, maximum };
  }
  const settings = appSettings();
  const departmentId = configuredDepartmentIdForWorkplace(place, settings);
  const roleDefinitions = specialRoleDefinitionsForDepartment(departmentId, settings);
  const specialRules = {
    ...(settings.workplaceSpecialRules?.[canonicalWorkplaceKey(place)] || settings.workplaceSpecialRules?.[place] || {}),
  };
  const roleUpdates = new Map();
  const activeRoleIds = new Set(roleDefinitions.map((role) => role.id));
  const usedNames = new Set(specialRoleDefinitions(settings, { includeArchived: true })
    .filter((role) => !activeRoleIds.has(role.id))
    .map((role) => role.name.toLocaleLowerCase("ru")));
  for (const role of roleDefinitions) {
    const name = String(form.elements[`role-${role.id}`]?.value || "").replace(/\s+/g, " ").trim().slice(0, 80) || role.name;
    const nameKey = name.toLocaleLowerCase("ru");
    if (usedNames.has(nameKey)) {
      showAppMessage("Правила специальных работ", `Название «${name}» повторяется. Укажите разные названия.`);
      return;
    }
    usedNames.add(nameKey);
    const color = normalizeStructureColor(form.elements[`role-${role.id}-color`]?.value, role.color);
    const minimum = Math.max(0, Number(form.elements[`role-${role.id}-minimum`]?.value || 0));
    const maximumValue = form.elements[`role-${role.id}-maximum`]?.value ?? "";
    const maximum = maximumValue === "" ? null : Math.max(0, Number(maximumValue));
    if (maximum !== null && maximum < minimum) {
      showAppMessage("Правила специальных работ", `${name}: значение «не более» не может быть меньше минимума.`);
      return;
    }
    specialRules[role.id] = { minimum, maximum };
    roleUpdates.set(role.id, { name, color });
  }
  const roleUpdateTime = new Date().toISOString();
  const customSpecialRoles = configuredCustomSpecialRoles(settings, { includeArchived: true }).map((role) => {
    const update = roleUpdates.get(role.id);
    if (!update) return role;
    const changed = update.name !== role.name || update.color !== role.color;
    return { ...role, ...update, ...(changed ? { updatedAt: roleUpdateTime } : {}) };
  });
  state.appSettings = {
    ...settings,
    workplaceGradeRules: {
      ...(settings.workplaceGradeRules || {}),
      [canonicalWorkplaceKey(place)]: gradeRules,
    },
    workplaceSpecialRules: {
      ...(settings.workplaceSpecialRules || {}),
      [canonicalWorkplaceKey(place)]: specialRules,
    },
    specialWorkLabels: {
      ...(settings.specialWorkLabels || {}),
      proletchik: roleUpdates.get("proletchik")?.name || settings.specialWorkLabels?.proletchik || "Пролётчик",
      capitalRepair: roleUpdates.get("capitalRepair")?.name || settings.specialWorkLabels?.capitalRepair || "Капремонт",
      subworker: roleUpdates.get("subworker")?.name || settings.specialWorkLabels?.subworker || "Подработчик",
    },
    proletchikColor: roleUpdates.get("proletchik")?.color || settings.proletchikColor,
    capitalRepairColor: roleUpdates.get("capitalRepair")?.color || settings.capitalRepairColor,
    subworkerColor: roleUpdates.get("subworker")?.color || settings.subworkerColor,
    customSpecialRoles,
  };
  saveState();
  applyDevicePreferences();
  showAppMessage("Правила рабочего места", `Настройки «${place}» сохранены.`);
  renderAppSettings();
}

function updateConfiguredDepartmentColor(departmentId, value) {
  const settings = appSettings();
  const department = settings.departments.find((item) => item.id === departmentId);
  if (!department) return;
  const color = normalizeStructureColor(value, configuredDepartmentColor(departmentId, settings));
  state.appSettings = {
    ...settings,
    departmentColors: { ...(settings.departmentColors || {}), [departmentId]: color },
  };
  saveState();
  renderAppSettings();
}

function updateConfiguredWorkplaceColor(place, value) {
  if (!settingsWorkplaceRows().some((item) => sameWorkplaceKey(item.name, place))) return;
  const settings = appSettings();
  const key = canonicalWorkplaceKey(place);
  const department = configuredDepartmentForWorkplace(place, settings);
  const departmentColor = configuredDepartmentColor(department?.id, settings);
  const color = normalizeStructureColor(value, configuredWorkplaceColor(place, settings));
  const workplaceColors = { ...(settings.workplaceColors || {}) };
  if (color === departmentColor) delete workplaceColors[key];
  else workplaceColors[key] = color;
  state.appSettings = {
    ...settings,
    workplaceColors,
  };
  saveState();
  renderAppSettings();
}

function resetConfiguredWorkplaceColor(place) {
  const settings = appSettings();
  const workplaceColors = { ...(settings.workplaceColors || {}) };
  delete workplaceColors[canonicalWorkplaceKey(place)];
  state.appSettings = { ...settings, workplaceColors };
  saveState();
  renderAppSettings();
}

function addConfiguredWorkplace(event) {
  event.preventDefault();
  const name = canonicalWorkplaceKey($("settingsWorkplaceName")?.value);
  if (!name) return;
  const settings = appSettings();
  const department = activeSettingsDepartment();
  const section = activeSettingsSection();
  if (!department || !section) {
    showAppMessage("Рабочие места", "Сначала создайте структурное подразделение и участок.");
    return;
  }
  const nameKey = normalizeName(canonicalWorkplaceKey(name));
  const storedWorkplaces = (settings.workplaces || []).map((item) => typeof item === "string" ? { name: item } : item);
  if (storedWorkplaces.some((item) => normalizeName(canonicalWorkplaceKey(item?.name)) === nameKey)
    || BASE_WORKPLACE_DEFINITIONS.some((item) => normalizeName(canonicalWorkplaceKey(item.name)) === nameKey)) {
    showAppMessage("Рабочие места", "Рабочее место с таким названием уже существует.");
    return;
  }
  if (!requireStaffAdmin("добавить рабочее место")) return;
  const type = /^печь(?:\s|$)/i.test(name) ? "furnace" : "production";
  const departmentColor = configuredDepartmentColor(department.id, settings);
  const selectedColor = normalizeStructureColor($("settingsWorkplaceColor")?.value, departmentColor);
  const workplaceColors = { ...(settings.workplaceColors || {}) };
  const workplaceKey = canonicalWorkplaceKey(name);
  if (selectedColor === departmentColor) delete workplaceColors[workplaceKey];
  else workplaceColors[workplaceKey] = selectedColor;
  const hidden = new Set(settings.hiddenWorkplaces || []);
  [...hidden].forEach((hiddenName) => {
    if (normalizeName(canonicalWorkplaceKey(hiddenName)) === nameKey) hidden.delete(hiddenName);
  });
  state.appSettings = {
    ...settings,
    workplaces: [...(settings.workplaces || []), { name, type, departmentId: department.id, sectionId: section.id }],
    workplaceColors,
    hiddenWorkplaces: [...hidden],
  };
  saveState();
  refreshConfiguredWorkplaces();
  clearWorkplaceCache();
  fillStaticControls();
  renderWorkplaces();
  renderAppSettings();
}

function addConfiguredDepartment(event) {
  event.preventDefault();
  if (!requireStaffAdmin("создать структурное подразделение")) return;
  const name = String($("settingsDepartmentName")?.value || "").trim();
  if (!name) return;
  const settings = appSettings();
  if (settings.departments.some((department) => department.name.toLowerCase() === name.toLowerCase())) {
    showAppMessage("Структурные подразделения", "Подразделение с таким названием уже существует.");
    return;
  }
  const defaultDepartment = DEFAULT_DEPARTMENTS.find((item) => item.name.toLowerCase() === name.toLowerCase());
  const id = defaultDepartment?.id || globalThis.crypto?.randomUUID?.() || `department-${Date.now().toString(36)}`;
  const color = normalizeStructureColor(
    $("settingsDepartmentColor")?.value,
    DEFAULT_DEPARTMENT_COLORS[id] || suggestedDepartmentColor(settings.departments.length)
  );
  const hiddenDepartments = new Set(settings.hiddenDepartments || []);
  hiddenDepartments.delete(id);
  state.appSettings = {
    ...settings,
    departments: [...settings.departments, { id, name }],
    departmentColors: { ...(settings.departmentColors || {}), [id]: color },
    hiddenDepartments: [...hiddenDepartments],
  };
  selectedSettingsDepartmentId = id;
  saveState();
  renderAppSettings();
}

function addConfiguredSection(event) {
  event.preventDefault();
  const department = activeSettingsDepartment();
  if (!department || !requireStaffAdmin(`добавить участок в ${department.name}`)) return;
  const name = String($("settingsSectionName")?.value || "").trim();
  if (!name) return;
  const settings = appSettings();
  if (configuredSections(department.id).some((section) => section.name.toLowerCase() === name.toLowerCase())) {
    showAppMessage("Участки", "В этом подразделении уже есть участок с таким названием.");
    return;
  }
  const id = globalThis.crypto?.randomUUID?.() || `section-${Date.now().toString(36)}`;
  state.appSettings = { ...settings, sections: [...settings.sections, { id, departmentId: department.id, name }] };
  selectedSettingsSectionId = id;
  saveState();
  renderAppSettings();
}

function deleteConfiguredSection(sectionId) {
  const section = configuredSections().find((item) => item.id === sectionId);
  if (!section || !requireStaffAdmin(`удалить участок ${section.name}`)) return;
  const children = settingsWorkplaceRows().filter((item) => item.sectionId === sectionId);
  if (children.length) {
    showAppMessage("Участки", "Сначала удалите рабочие места этого участка.");
    return;
  }
  if (!window.confirm(`Удалить участок «${section.name}»?`)) return;
  const settings = appSettings();
  const hiddenSections = new Set(settings.hiddenSections || []);
  hiddenSections.add(sectionId);
  state.appSettings = {
    ...settings,
    sections: settings.sections.filter((item) => item.id !== sectionId),
    hiddenSections: [...hiddenSections],
  };
  selectedSettingsSectionId = "";
  saveState();
  renderAppSettings();
}

function deleteConfiguredDepartment(departmentId) {
  const department = configuredDepartments().find((item) => item.id === departmentId);
  if (department?.id === DEFAULT_DEPARTMENT_ID) {
    showAppMessage("Структурные подразделения", "Основное подразделение нельзя удалить. Его название и состав участков можно использовать как основу структуры.");
    return;
  }
  if (!department || !requireStaffAdmin(`удалить подразделение ${department.name}`)) return;
  const children = configuredSections(departmentId);
  const departmentWorkplaces = settingsWorkplaceRows().filter((item) => item.departmentId === departmentId);
  if (children.length || departmentWorkplaces.length) {
    showAppMessage(
      "Структурные подразделения",
      departmentWorkplaces.length
        ? "Сначала удалите рабочие места и участки этого подразделения."
        : "Сначала удалите участки этого подразделения."
    );
    return;
  }
  if (!window.confirm(`Удалить подразделение «${department.name}»?`)) return;
  const settings = appSettings();
  const departments = settings.departments.filter((item) => item.id !== departmentId);
  if (!departments.length) {
    showAppMessage("Структурные подразделения", "Должно остаться хотя бы одно подразделение.");
    return;
  }
  const hiddenDepartments = new Set(settings.hiddenDepartments || []);
  hiddenDepartments.add(departmentId);
  hiddenDepartments.delete(DEFAULT_DEPARTMENT_ID);
  state.appSettings = { ...settings, departments, hiddenDepartments: [...hiddenDepartments] };
  if (selectedWorkplaceDepartmentId === departmentId) {
    workplaceHierarchyLevel = "departments";
    selectedWorkplaceDepartmentId = "";
    selectedWorkplaceSectionId = "";
    selectedWorkplace = "";
    workplaceEditorOpened = false;
  }
  if (state.vacationDepartmentId === departmentId) {
    state.vacationDepartmentId = "";
    state.vacationSectionId = "";
  }
  selectedSettingsDepartmentId = departments[0].id;
  saveState();
  renderAppSettings();
  showAppMessage(
    "Подразделение удалено",
    `«${department.name}» удалено. Чтобы передать изменение на другие устройства, нажмите «Сохранить».`
  );
}

function deleteConfiguredWorkplace(name) {
  const assigned = activeUnifiedEmployees().filter((employee) => employee.place === name);
  if (assigned.length) {
    showAppMessage(
      "Рабочее место используется",
      `На рабочем месте «${name}» числится ${assigned.length} сотрудников. Сначала переведите или увольте их в разделе «Люди».`
    );
    return false;
  }
  if (!requireStaffAdmin(`удалить рабочее место ${name}`)) return false;
  if (!window.confirm(`Удалить рабочее место «${name}»? Отработанные смены сохранятся в истории.`)) return false;
  const settings = appSettings();
  const hidden = new Set(settings.hiddenWorkplaces || []);
  hidden.add(name);
  const workplaces = (settings.workplaces || []).filter((item) => {
    const itemName = typeof item === "string" ? item : item?.name;
    return String(itemName || "").trim() !== name;
  });
  state.appSettings = { ...settings, workplaces, hiddenWorkplaces: [...hidden] };
  saveState();
  refreshConfiguredWorkplaces();
  clearWorkplaceCache();
  fillStaticControls();
  renderWorkplaces();
  renderAppSettings();
  return true;
}

function changeAdminPassword() {
  if (!requireStaffAdmin("изменить пароль администратора")) return;
  const first = prompt("Введите новый пароль администратора (не менее 4 символов):");
  if (first === null) return;
  if (String(first).trim().length < 4) return showAppMessage("Пароль", "Пароль должен содержать не менее 4 символов.");
  const second = prompt("Повторите новый пароль:");
  if (String(first).trim() !== String(second || "").trim()) return showAppMessage("Пароль", "Пароли не совпадают.");
  localStorage.setItem(STAFF_ADMIN_PIN_HASH_KEY, staffAdminHash(String(first).trim()));
  state.appSettings = { ...appSettings(), adminPinHash: staffAdminHash(String(first).trim()) };
  saveState();
  showAppMessage("Пароль", "Пароль администратора изменён. Нажмите «Сохранить», чтобы синхронизировать его с другими устройствами.");
}

function rememberItemsAsDeleted(items, deletedField) {
  (items || []).forEach((item) => item?.id && rememberDeletedId(deletedField, item.id));
}

function itemInPeriod(item, year = null, month = null) {
  const value = String(item?.date || item?.start || item?.startDate || "");
  const parsed = /^([0-9]{4})-([0-9]{2})/.exec(value);
  if (!parsed || (year !== null && Number(parsed[1]) !== year)) return false;
  return month === null || Number(parsed[2]) - 1 === month;
}

function deleteOperationalPeriod() {
  if (!requireStaffAdmin("удалить данные периода")) return;
  const yearValue = $("settingsDeleteYear")?.value ?? "*";
  const year = yearValue === "*" ? null : Number(yearValue);
  const monthValue = $("settingsDeleteMonth")?.value ?? "";
  const month = monthValue === "" ? null : Number(monthValue);
  const label = year === null
    ? (month === null ? "все годы" : `${MONTHS[month]} за все годы`)
    : (month === null ? `${year} год` : `${MONTHS[month]} ${year}`);
  if (!confirm(`Удалить рабочие смены, отсутствия и отпуска за ${label}? Штат сотрудников останется.`)) return;
  const fields = [
    ["entries", "deletedEntryIds"], ["absences", "deletedAbsenceIds"], ["vacations", "deletedVacationIds"],
    ["proletchikShifts", "deletedProletchikShiftIds"], ["capitalRepairShifts", "deletedCapitalRepairShiftIds"],
  ];
  fields.forEach(([field, deletedField]) => {
    const removed = (state[field] || []).filter((item) => itemInPeriod(item, year, month));
    rememberItemsAsDeleted(removed, deletedField);
    state[field] = (state[field] || []).filter((item) => !itemInPeriod(item, year, month));
  });
  saveState();
  render();
  showAppMessage("Очистка", `Данные за ${label} удалены на устройстве. Нажмите «Сохранить», чтобы синхронизировать удаление.`);
}

function deleteAllApplicationData() {
  if (!requireStaffAdmin("удалить все данные и весь штат")) return;
  const phrase = prompt("Для подтверждения введите: УДАЛИТЬ ВСЕ");
  if (phrase !== "УДАЛИТЬ ВСЕ") return showAppMessage("Очистка", "Подтверждение не совпало. Данные не удалены.");
  rememberItemsAsDeleted(state.entries, "deletedEntryIds");
  rememberItemsAsDeleted(state.absences, "deletedAbsenceIds");
  rememberItemsAsDeleted(state.vacations, "deletedVacationIds");
  rememberItemsAsDeleted(state.proletchikShifts, "deletedProletchikShiftIds");
  rememberItemsAsDeleted(state.capitalRepairShifts, "deletedCapitalRepairShiftIds");
  rememberItemsAsDeleted(state.customEmployees, "deletedCustomEmployeeIds");
  state.entries = [];
  state.absences = [];
  state.vacations = [];
  state.proletchikShifts = [];
  state.capitalRepairShifts = [];
  state.customEmployees = [];
  state.employeeEdits = {};
  state.employeePhones = {};
  state.vacationPriorities = {};
  state.vacationAllowances = {};
  state.repairPlans = {};
  state.repairPlansByBrigade = {};
  state.dismissedTabsByBrigade = BASE_EMPLOYEES.reduce((result, employee) => {
    const brigade = itemBrigade(employee);
    result[brigade] = [...new Set([...(result[brigade] || []), String(employee.tab)])];
    return result;
  }, {});
  saveState();
  fillStaticControls();
  render();
  showAppMessage("Очистка", "Все рабочие данные и штат удалены. Нажмите «Сохранить», чтобы синхронизировать удаление.");
}

function openPrintPreview(targetId) {
  setActiveView("forms");
  activatePreviewTab(targetId);
  const target = $(targetId);
  if (target) setTimeout(() => target.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "start" }), 50);
}

function activatePreviewTab(targetId) {
  document.querySelectorAll(".forms-document-tabs .tab").forEach((item) => {
    const isActive = item.dataset.target === targetId;
    item.classList.toggle("active", isActive);
    item.setAttribute("aria-selected", String(isActive));
  });
  document.querySelectorAll('[data-view-panel="forms"] .preview').forEach((item) => item.classList.toggle("active", item.id === targetId));
}

function activeFormsSelection() {
  const activeTab = document.querySelector(".forms-document-tabs .tab.active");
  return {
    targetId: activeTab?.dataset.target || "transferPreview",
    kind: activeTab?.dataset.formKind || "transfer",
  };
}

function lockHorizontalScroll() {
  const top = window.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0;
  window.scrollTo(0, top);
  document.documentElement.scrollLeft = 0;
  document.body.scrollLeft = 0;
  const scrollingElement = document.scrollingElement;
  if (scrollingElement) scrollingElement.scrollLeft = 0;
  document.querySelectorAll(".layout, .panel, .app-view.active:not([data-view-panel='print']), .stats-chart, .stats-workplace-cards, .app-message-backdrop").forEach((element) => {
    element.scrollLeft = 0;
  });
}

function lockHorizontalScrollSoon() {
  lockHorizontalScroll();
  requestAnimationFrame(lockHorizontalScroll);
  setTimeout(lockHorizontalScroll, 50);
  setTimeout(lockHorizontalScroll, 200);
}

function moveCalendar(delta) {
  const date = new Date(calendarCursor.year, calendarCursor.month + delta, 1);
  calendarCursor = { month: date.getMonth(), year: date.getFullYear() };
  renderCalendar();
}

function prefillEmployee() {
  const employee = unifiedEmployeeByName($("employeeInput").value);
  if (!employee) return;
  $("tabInput").value = employee.tab;
  $("actualPlaceInput").value = employee.place;
  $("actualGradeInput").value = employee.grade;
  refreshSpecialWorkLabels();
  $("roleInput").value = "auto";
}

function syncSelectedDate() {
  state.selectedShiftDate = $("dateInput").value;
  state.selectedShiftKind = inferShiftKindForDate($("dateInput").value);
  $("statsDateInput").value = $("dateInput").value;
  $("workplaceDateInput").value = $("dateInput").value;
  refreshEmployeeList();
  updateCurrentShiftDisplay();
  renderAbsentToday();
  renderAbsences();
}

function getShiftForDate(dateValue) {
  if (!dateValue || !state.scheduleStartDate) return { label: "", kind: "" };
  const dayMs = 24 * 60 * 60 * 1000;
  const current = new Date(`${dateValue}T00:00:00`);
  const start = new Date(`${state.scheduleStartDate}T00:00:00`);
  const diff = Math.floor((current - start) / dayMs);
  const index = ((diff % 4) + 4) % 4;
  const labels = [
    { label: "Смена 1, дневная", kind: "day" },
    { label: "Смена 2, ночная", kind: "night" },
    { label: "Выходной 1", kind: "off" },
    { label: "Выходной 2", kind: "off" },
  ];
  return labels[index];
}

function updateCurrentShiftDisplay() {
  if (!$("currentShiftDisplay")) return;
  const shift = getShiftForDate($("dateInput")?.value);
  $("currentShiftDisplay").value = shift.label;
}

function workplaceItems() {
  return PLACES.map((place) => {
    const furnaceCode = /^Печь\s+(\d+)$/i.exec(place)?.[1] || "";
    const assigned = currentEmployees().filter((employee) => (
      employee.place === place || (furnaceCode && String(employee.code || "") === furnaceCode)
    )).length;
    return {
      key: place,
      title: place === "РМ" ? "Разливочные машины" : place,
      hint: `${assigned} штатных`,
    };
  });
}

function workplaceItemsForSection(sectionId) {
  const names = new Set(settingsWorkplaceRows()
    .filter((item) => (!selectedWorkplaceDepartmentId || item.departmentId === selectedWorkplaceDepartmentId) && item.sectionId === sectionId)
    .map((item) => item.name));
  return workplaceItems().filter((item) => names.has(item.key));
}

function selectWorkplaceDepartment(departmentId) {
  selectedWorkplaceDepartmentId = String(departmentId || "");
  selectedWorkplaceSectionId = "";
  const hasSections = configuredSections(selectedWorkplaceDepartmentId).length > 0;
  workplaceHierarchyLevel = hasSections ? "sections" : "workplaces";
  if (!hasSections) selectedWorkplace = "Все";
  workplaceEditorOpened = false;
  workplaceCreateOpened = false;
  workplaceListSignature = "";
  renderWorkplaces();
}

function selectWorkplaceSection(sectionId) {
  selectedWorkplaceSectionId = String(sectionId || "");
  workplaceHierarchyLevel = "workplaces";
  workplaceEditorOpened = false;
  workplaceCreateOpened = false;
  const firstWorkplace = workplaceItemsForSection(selectedWorkplaceSectionId)[0];
  selectedWorkplace = firstWorkplace?.key || "";
  selectedWorkplaceCarouselCopy = 0;
  workplaceTapReadyToOpen = "";
  workplaceListSignature = "";
  renderWorkplaces();
}

function selectWorkplaceFromPicker(place) {
  const value = String(place || "");
  if (!value) return;
  selectedWorkplace = value;
  workplaceTapReadyToOpen = "";
  workplaceEditorOpened = false;
  workplaceListSignature = "";
  renderWorkplaces();
}

function workplaceHierarchyBack() {
  if (workplaceHierarchyLevel === "workplaces") workplaceHierarchyLevel = "sections";
  selectedWorkplaceSectionId = workplaceHierarchyLevel === "workplaces" ? selectedWorkplaceSectionId : "";
  selectedWorkplaceDepartmentId = DEFAULT_DEPARTMENT_ID;
  workplaceEditorOpened = false;
  workplaceCreateOpened = false;
  workplaceListSignature = "";
  renderWorkplaces();
}

function toggleMainWorkplaceCreate(forceOpen) {
  workplaceCreateOpened = typeof forceOpen === "boolean" ? forceOpen : !workplaceCreateOpened;
  workplaceListSignature = "";
  renderWorkplaces();
  if (workplaceCreateOpened) {
    requestAnimationFrame(() => $("mainWorkplaceNameInput")?.focus({ preventScroll: true }));
  }
}

function inferMainWorkplaceSection(name) {
  const sections = configuredSections(DEFAULT_DEPARTMENT_ID);
  const normalized = normalizeName(name);
  const isCasting = /разлив|машин|(^|\s)рм(\s|$)/i.test(normalized);
  const preferredId = isCasting ? "section-casting-bay" : "section-furnace-bay";
  return sections.find((section) => section.id === preferredId) || sections[0] || null;
}

function addConfiguredWorkplaceFromMain(event) {
  event.preventDefault();
  const name = canonicalWorkplaceKey($("mainWorkplaceNameInput")?.value);
  const section = inferMainWorkplaceSection(name);
  if (!name) {
    showAppMessage("Новое рабочее место", "Введите название рабочего места.");
    return;
  }
  if (!section) {
    showAppMessage("Новое рабочее место", "Не удалось определить раздел для нового рабочего места.");
    return;
  }
  const nameKey = normalizeName(canonicalWorkplaceKey(name));
  const storedWorkplaces = (appSettings().workplaces || []).map((item) => typeof item === "string" ? { name: item } : item);
  if (storedWorkplaces.some((item) => normalizeName(canonicalWorkplaceKey(item?.name)) === nameKey)
    || BASE_WORKPLACE_DEFINITIONS.some((item) => normalizeName(canonicalWorkplaceKey(item.name)) === nameKey)) {
    showAppMessage("Новое рабочее место", "Рабочее место с таким названием уже существует.");
    return;
  }
  if (!requireStaffAdmin("создать новое рабочее место")) return;

  const settings = appSettings();
  const workplaceKey = canonicalWorkplaceKey(name);
  const hidden = new Set(settings.hiddenWorkplaces || []);
  [...hidden].forEach((hiddenName) => {
    if (normalizeName(canonicalWorkplaceKey(hiddenName)) === nameKey) hidden.delete(hiddenName);
  });
  state.appSettings = {
    ...settings,
    workplaces: [
      ...(settings.workplaces || []),
      {
        name,
        type: /^печь(?:\s|$)/i.test(name) ? "furnace" : "production",
        departmentId: DEFAULT_DEPARTMENT_ID,
        sectionId: section.id,
      },
    ],
    hiddenWorkplaces: [...hidden],
  };
  saveState();
  refreshConfiguredWorkplaces();
  clearWorkplaceCache();
  fillStaticControls();
  selectedWorkplaceDepartmentId = DEFAULT_DEPARTMENT_ID;
  selectedWorkplaceSectionId = section.id;
  workplaceHierarchyLevel = "workplaces";
  selectedWorkplace = name;
  selectedWorkplaceCarouselCopy = 0;
  workplaceTapReadyToOpen = "";
  workplaceEditorOpened = false;
  workplaceCreateOpened = false;
  workplaceListSignature = "";
  renderWorkplaces();
  showAppMessage("Рабочее место создано", `«${name}» добавлено в список рабочих мест.`);
}

function selectWorkplace(place, copy = 1) {
  const sameCard = selectedWorkplace === place && workplaceTapReadyToOpen === place;
  const readonlyCard = place === "Отсутствующие" || place === "Все";
  if (readonlyCard) workplaceHierarchyLevel = "workplaces";
  selectedWorkplace = place;
  selectedWorkplaceCarouselCopy = Number(copy || 1);
  workplaceEditorOpened = Boolean(sameCard && !readonlyCard && !workplaceEditorOpened);
  workplaceTapReadyToOpen = workplaceEditorOpened || readonlyCard ? "" : place;
  if (workplaceEditorOpened) {
    clearWorkplaceForm();
    refreshEmployeeList();
  }
  renderWorkplaces();
}

function filteredWorkplaceItems() {
  return workplaceItems();
}

function updateSelectedWorkplaceView() {
  const item = selectedWorkplace === "Отсутствующие"
    ? { key: "Отсутствующие", title: "Отсутствующие", hint: "полный список" }
    : selectedWorkplace === "Все"
      ? { key: "Все", title: "В смене", hint: "загрузка смены" }
    : workplaceItems().find((workplace) => workplace.key === selectedWorkplace) || workplaceItems()[0];
  document.querySelector(".workplace-editor")?.classList.toggle("is-open", workplaceEditorOpened);
  $("selectedWorkplaceTitle").textContent = item.title;
  updateSelectedWorkplaceDate();
  refreshSpecialWorkLabels();

  const isProletchik = selectedWorkplace === "Пролётчик";
  const isCapitalRepair = selectedWorkplace === "Капитальный ремонт";
  const isCustomPlace = selectedWorkplace === "Другое место";
  const isAbsence = selectedWorkplace === "Отсутствующие";
  const isAllWorkplaces = selectedWorkplace === "Все";
  const showWorkplaceForm = workplaceEditorOpened && !isAbsence && !isAllWorkplaces;
  const date = $("workplaceDateInput")?.value || selectedShiftDate();
  const selectedRows = selectedWorkplace === "Все"
    ? selectedHierarchyShiftRows(date)
    : selectedWorkplace === "Отсутствующие"
      ? selectedHierarchyMissingEmployees(date)
      : workplaceRowsByKey(selectedWorkplace, date);
  const selectedHours = Number(selectedRows.reduce((sum, row) => sum + Number(row.hours || 0), 0).toFixed(1));
  const absencePanel = document.getElementById("absenceBlock")?.closest(".app-view");
  const workplaceEditor = document.querySelector(".workplace-editor");
  if (absencePanel && workplaceEditor && absencePanel.parentElement !== workplaceEditor) {
    workplaceEditor.appendChild(absencePanel);
  }
  $("workplaceShiftKindInput").disabled = false;
  if ($("workplaceShiftCountInput")) $("workplaceShiftCountInput").disabled = false;
  $("workplaceHoursInput").disabled = false;
  $("workplaceGradeInput").disabled = false;
  $("targetWorkplaceField").style.display = isProletchik || isCapitalRepair ? "grid" : "none";
  $("customWorkplaceField").style.display = isCustomPlace && !isAbsence ? "grid" : "none";
  document.querySelector(".workplace-current").style.display = showWorkplaceForm ? "flex" : "none";
  if ($("workplaceActionBar")) $("workplaceActionBar").style.display = showWorkplaceForm || isAbsence || isAllWorkplaces ? "none" : "flex";
  if ($("workplaceActionTitle")) $("workplaceActionTitle").textContent = item.title;
  if ($("workplaceActionMeta")) $("workplaceActionMeta").textContent = isAbsence
    ? `${selectedRows.length} отсутствуют`
    : `${selectedRows.length} чел. · ${selectedHours} ч`;
  if ($("openWorkplaceFormBtn")) $("openWorkplaceFormBtn").style.display = (isAbsence || isAllWorkplaces) ? "none" : "inline-flex";
  $("workplaceForm").style.display = showWorkplaceForm ? "grid" : "none";
  $("workplaceAddedList").style.display = showWorkplaceForm ? "none" : "block";
  $("workplaceHelp").style.display = showWorkplaceForm ? "block" : "none";
  if ($("shiftOverview")) $("shiftOverview").style.display = "none";
  if (absencePanel) absencePanel.style.display = "none";

  if (isAbsence || isAllWorkplaces) return;

  if (isProletchik) {
    fillTargetWorkplaceOptions("proletchik");
    refreshSpecialWorkLabels();
    $("workplaceRoleInput").value = "proletchik";
    $("workplaceHelp").textContent = "Выбери пролётчика, укажи разряд и выбери, куда закрыть: печь или РМ.";
    return;
  }

  if (isCapitalRepair) {
    fillTargetWorkplaceOptions("capitalRepair");
    refreshSpecialWorkLabels();
    $("workplaceRoleInput").value = "capitalRepair";
    $("workplaceHelp").textContent = "Выбери работника капремонта, укажи разряд и выбери, на какую печь закрыть.";
    return;
  }

  if (selectedWorkplace === "РМ") {
    $("workplaceGradeInput").value = "3";
    $("workplaceHelp").textContent = "Для разливочных машин учитывается разряд 3 или 4, номер машины не нужен. Пролётчика можно закрыть вручную через поле «Кто это».";
    return;
  }

  if (isCustomPlace) {
    $("workplaceHelp").textContent = "Введи название места вручную. Такая смена попадёт в переводной бланк как работа в другом месте.";
    return;
  }

  $("workplaceHelp").textContent = "Выбери работника, разряд и роль. Пролётчик и капитальный ремонт теперь закрываются вручную прямо на выбранное рабочее место.";
}

function fillTargetWorkplaceOptions(mode) {
  if (!$("targetWorkplaceInput")) return;
  const places = mode === "capitalRepair"
    ? FURNACES.map((code) => `Печь ${code}`)
    : [...FURNACES.map((code) => `Печь ${code}`), "РМ"];
  const current = $("targetWorkplaceInput").value;
  $("targetWorkplaceInput").innerHTML = places.map((place) => `<option value="${place}">${place === "РМ" ? "Разливочные машины" : place}</option>`).join("");
  if (places.includes(current)) $("targetWorkplaceInput").value = current;
}

function updateSelectedWorkplaceDate() {
  const date = $("workplaceDateInput")?.value || "";
  const label = date ? `Дата смены: ${formatDate(date)}` : "Дата смены не выбрана";
  if ($("selectedWorkplaceDate")) $("selectedWorkplaceDate").textContent = label;
}

function renderWorkplaces() {
  if (!$("workplaceList")) return;
  const departments = configuredDepartments();
  if (workplaceHierarchyLevel === "departments") {
    workplaceHierarchyLevel = "sections";
    selectedWorkplaceDepartmentId = DEFAULT_DEPARTMENT_ID;
  }
  const isShiftSummaryView = ["Отсутствующие", "Все"].includes(selectedWorkplace);
  if (workplaceHierarchyLevel !== "departments" && !isShiftSummaryView && !departments.some((item) => item.id === selectedWorkplaceDepartmentId)) {
    workplaceHierarchyLevel = "sections";
    selectedWorkplaceDepartmentId = DEFAULT_DEPARTMENT_ID;
  }
  const sections = configuredSections(selectedWorkplaceDepartmentId);
  if (workplaceHierarchyLevel === "workplaces" && !isShiftSummaryView && !sections.some((item) => item.id === selectedWorkplaceSectionId)) {
    workplaceHierarchyLevel = "sections";
    selectedWorkplaceSectionId = "";
  }
  const baseItems = workplaceHierarchyLevel === "workplaces" ? workplaceItemsForSection(selectedWorkplaceSectionId) : [];
  if (workplaceHierarchyLevel === "workplaces" && selectedWorkplace && !["Отсутствующие", "Все"].includes(selectedWorkplace) && !baseItems.some((item) => item.key === selectedWorkplace)) {
    selectedWorkplace = "";
    workplaceEditorOpened = false;
  }
  const renderItems = baseItems.map((item) => ({ ...item, copy: 0 }));
  const date = $("workplaceDateInput")?.value || selectedShiftDate();
  const entriesCount = (state.entries || []).filter((entry) => belongsToCurrentBrigade(entry) && entry.date === date).length;
  const absencesCount = (state.absences || []).filter((absence) => belongsToCurrentBrigade(absence) && absence.date === date).length;
  const signature = [
    currentBrigade(),
    date,
    selectedWorkplace,
    workplaceEditorOpened ? "open" : "closed",
    workplaceCreateOpened ? "create" : "browse",
    entriesCount,
    absencesCount,
    workplaceHierarchyLevel,
    selectedWorkplaceDepartmentId,
    selectedWorkplaceSectionId,
    renderItems.map((item) => item.key).join("|"),
  ].join("::");
  if (workplaceListSignature !== signature) {
    workplaceListSignature = signature;
    $("workplaceList").dataset.carousel = "false";
    const hierarchyBack = workplaceHierarchyLevel === "workplaces" ? `<button class="workplace-hierarchy-back" type="button" onclick="workplaceHierarchyBack()">← Назад</button>` : "";
    const hierarchyCards = workplaceHierarchyLevel === "sections"
        ? `<label class="workplace-section-picker">
            <span>Рабочее место</span>
            <select class="workplace-section-select" aria-label="Выбор рабочего места" onchange="if (this.value) selectWorkplaceSection(this.value)">
              <option value="">Выбрать рабочее место</option>
              ${sections.map((section) => {
                const workplaceCount = settingsWorkplaceRows().filter((item) => item.sectionId === section.id).length;
                const countLabel = `${workplaceCount} ${pluralRu(workplaceCount, "рабочее место", "рабочих места", "рабочих мест")}`;
                return `<option value="${escapeHtml(section.id)}">${escapeHtml(configuredSectionLabel(section))} · ${countLabel}</option>`;
              }).join("")}
            </select>
          </label>
          `
        : renderItems.map((item) => `
        <button class="workplace-card ${item.key === selectedWorkplace ? "active" : ""}" type="button" data-workplace-key="${escapeHtml(item.key)}" data-carousel-copy="${item.copy}" title="${escapeHtml(workplaceCardDetail(item.key))}" onclick="selectWorkplace('${escapeJs(item.key)}', '${item.copy}')">
          <strong>${escapeHtml(item.title)}</strong>
          <span>${escapeHtml(item.hint)}</span>
          ${workplaceCardWorkers(item.key)}
        </button>
      `).join("");
    const emptyHierarchy = isShiftSummaryView ? "" : `<div class="settings-empty-workplaces">Здесь пока нет рабочих мест.</div>`;
    $("workplaceList").innerHTML = hierarchyBack + (hierarchyCards || emptyHierarchy);
  }
  document.querySelector(".workplaces-layout")?.classList.toggle("hierarchy-browsing", workplaceHierarchyLevel !== "workplaces" || !selectedWorkplace);
  renderWorkplaceShiftSummary();
  if (workplaceHierarchyLevel !== "workplaces") {
    const absencePanel = document.getElementById("absenceBlock")?.closest(".app-view");
    if (absencePanel) absencePanel.style.display = "none";
    if ($("shiftOverview")) $("shiftOverview").style.display = "none";
  }
  if (workplaceHierarchyLevel === "workplaces" && selectedWorkplace) {
    updateSelectedWorkplaceView();
    renderWorkplaceAddedList();
  }
}

function workplaceCardWorkers(key) {
  const date = $("workplaceDateInput")?.value || selectedShiftDate();
  if (!date || key === "Отсутствующие") return "";
  if (key === "Все") return workplaceAllCardWorkers(date);
  return "";
}

function workplaceAllCardWorkers(date) {
  const rows = selectedHierarchyShiftRows(date);
  const places = new Set(rows.map((row) => row.place).filter(Boolean)).size;
  const hours = Number(rows.reduce((sum, row) => sum + Number(row.hours || 0), 0).toFixed(1));
  return `<small class="workplace-card-workers">${rows.length} человек · ${places} мест · ${hours} ч</small>`;
}

function renderWorkplaceShiftSummary() {
  if (!$("workplaceShiftSummary")) return;
  const showSummary = workplaceHierarchyLevel === "workplaces" && Boolean(selectedWorkplaceSectionId);
  if (!showSummary) {
    $("workplaceShiftSummary").innerHTML = "";
    $("workplaceShiftSummary").style.display = "none";
    return;
  }
  const date = $("workplaceDateInput")?.value || selectedShiftDate();
  const rows = selectedHierarchyShiftRows(date);
  const missing = date ? selectedHierarchyMissingEmployees(date) : [];
  const totalHours = Number(rows.reduce((sum, row) => sum + Number(row.hours || 0), 0).toFixed(1));
  const brigade = currentBrigade();
  $("workplaceShiftSummary").style.display = "grid";
  $("workplaceShiftSummary").innerHTML = `
    <div class="workplace-summary-card yellow combined">
      <span>Бригада ${escapeHtml(brigade)}</span>
      <strong>${formatDate(date) || "дата не выбрана"} · ${formatHoursText(totalHours)}</strong>
    </div>
    <button class="workplace-summary-card blue ${selectedWorkplace === "Все" ? "active" : ""}" type="button" onclick="selectWorkplace('Все')">
      <span>Вся смена</span>
      <strong>${rows.length} ${pluralRu(rows.length, "человек", "человека", "человек")}</strong>
    </button>
    <button class="workplace-summary-card blue warning ${selectedWorkplace === "Отсутствующие" ? "active" : ""}" type="button" onclick="selectWorkplace('Отсутствующие')">
      <span>Отсутствующие</span>
      <strong>${missing.length} ${pluralRu(missing.length, "человек", "человека", "человек")}</strong>
    </button>
  `;
}

function workplaceCardDetail(key) {
  const date = $("workplaceDateInput")?.value || selectedShiftDate();
  if (key !== "Все" || !date) return "";
  const rows = selectedHierarchyShiftRows(date);
  const byPlace = new Map();
  const byGrade = new Map();
  for (const row of rows) {
    const place = row.place || "Не указано";
    const grade = row.grade || "без разряда";
    const placeStat = byPlace.get(place) || { people: 0, hours: 0 };
    placeStat.people += 1;
    placeStat.hours = Number((placeStat.hours + Number(row.hours || 0)).toFixed(1));
    byPlace.set(place, placeStat);
    const gradeStat = byGrade.get(grade) || { people: 0, hours: 0 };
    gradeStat.people += 1;
    gradeStat.hours = Number((gradeStat.hours + Number(row.hours || 0)).toFixed(1));
    byGrade.set(grade, gradeStat);
  }
  const placeLines = [...byPlace.entries()].map(([place, stat]) => `${place}: ${stat.people} чел., ${stat.hours} ч`);
  const gradeLines = [...byGrade.entries()].sort((a, b) => String(b[0]).localeCompare(String(a[0]), "ru", { numeric: true })).map(([grade, stat]) => `${grade} разряд: ${stat.people} чел., ${stat.hours} ч`);
  const totalHours = Number(rows.reduce((sum, row) => sum + Number(row.hours || 0), 0).toFixed(1));
  return [`Всего: ${rows.length} чел., ${totalHours} ч`, "По местам:", ...placeLines, "По разрядам:", ...gradeLines].join("\n");
}
function shortName(name) {
  const parts = String(name || "").trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "";
  return parts[0];
}

function workplaceRowsByKey(key, date) {
  const cache = ensureWorkplaceCache(date);
  if (cache.rowsByKey.has(key)) return cache.rowsByKey.get(key);
  const rows = currentEntries()
    .filter((entry) => {
      if (entry.date !== date) return false;
      if (key === "Пролётчик") return entry.role === "proletchik";
      if (key === "Капитальный ремонт") return entry.role === "capitalRepair";
      if (key === "Другое место") return !PLACES.includes(entry.actualPlace);
      return sameWorkplaceKey(entry.actualPlace, key);
    })
    .sort(compareWorkplaceShiftRows);
  cache.rowsByKey.set(key, rows);
  return rows;
}

function compareWorkplaceShiftRows(a, b) {
  const gradeDiff = Number(b.actualGrade || b.grade || 0) - Number(a.actualGrade || a.grade || 0);
  if (gradeDiff) return gradeDiff;
  return String(a.name || "").localeCompare(String(b.name || ""), "ru");
}

function workplaceDisplayTitle() {
  return workplaceItems().find((workplace) => workplace.key === selectedWorkplace)?.title || selectedWorkplace;
}

function workplaceEntriesForDate(date) {
  if (!date) return [];
  return currentEntries()
    .filter((entry) => {
      if (entry.date !== date) return false;
      if (selectedWorkplace === "Пролётчик") return entry.role === "proletchik";
      if (selectedWorkplace === "Капитальный ремонт") return entry.role === "capitalRepair";
      if (selectedWorkplace === "Другое место") {
        return !PLACES.includes(entry.actualPlace);
      }
      return sameWorkplaceKey(entry.actualPlace, selectedWorkplace);
    })
    .sort(compareWorkplaceShiftRows)
    .map((entry) => ({
      id: entry.id,
      type: "entry",
      date: entry.date,
      name: entry.name,
      tab: entry.tab,
      place: entry.actualPlace,
      grade: entry.actualGrade,
      role: entry.role,
      isSubworker: entryIsSubworker(entry),
      kind: entryKindLabel(entry),
      hours: entry.hours,
      comment: entry.comment || "",
    }));
}

function renderWorkplaceAddedList() {
  if (!$("workplaceAddedList")) return;
  document.body.classList.toggle("workplace-absence-mode", selectedWorkplace === "\u041e\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u044e\u0449\u0438\u0435");
  document.body.classList.toggle("workplace-all-mode", selectedWorkplace === "\u0412\u0441\u0435");
  document.body.classList.toggle("workplace-single-mode", selectedWorkplace !== "\u0412\u0441\u0435" && selectedWorkplace !== "\u041e\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u044e\u0449\u0438\u0435");
  const date = $("workplaceDateInput").value;
  updateSelectedWorkplaceDate();
  renderShiftOverview();
  if (selectedWorkplace === "Отсутствующие") {
    renderWorkplaceAbsenceList(date);
    return;
  }
  if (selectedWorkplace === "Все") {
    renderWorkplaceAllList(date);
    return;
  }
  const rows = workplaceEntriesForDate(date);
  const title = workplaceDisplayTitle();
  document.querySelector(".workplace-editor")?.classList.toggle("has-added", rows.length > 0);

  $("workplaceAddedList").innerHTML = `
    <div class="workplace-added-title">
      <strong>Добавлены на ${escapeHtml(title)} за ${formatDate(date) || "выбранный день"}</strong>
      <span>${rows.length} чел.</span>
    </div>
    <div class="table-wrap workplace-added-table-wrap">
      <table>
        <thead>
          <tr>
            <th>Таб. №</th>
            <th>ФИО</th>
            <th>Место</th>
            <th>Разряд</th>
            <th>Вид</th>
            <th>Часы</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          ${rows.map((row) => `
            <tr class="${workplaceRowClass(row)}"${specialRoleStyleAttribute(row.role)}>
              <td>${escapeHtml(row.tab)}</td>
              <td>${escapeHtml(row.name)}</td>
              <td>${escapeHtml(row.place)}</td>
              <td>${escapeHtml(row.grade)}</td>
              <td>${escapeHtml(row.kind)}</td>
              <td>${escapeHtml(row.hours)}</td>
              <td><button class="danger" type="button" onclick="deleteWorkplaceRow('${escapeJs(row.type)}', '${escapeJs(row.id)}', '${escapeJs(row.date || date)}', '${escapeJs(row.tab)}', '${escapeJs(row.name)}', '${escapeJs(row.place)}')">Удалить</button></td>
            </tr>
          `).join("") || `<tr><td colspan="7">Пока никого не добавлено.</td></tr>`}
        </tbody>
      </table>
    </div>
  `;
}

function renderWorkplaceAllList(date) {
  const rows = selectedHierarchyShiftRows(date);
  const totalHours = Number(rows.reduce((sum, row) => sum + Number(row.hours || 0), 0).toFixed(1));
  document.querySelector(".workplace-editor")?.classList.toggle("has-added", rows.length > 0);
  $("workplaceAddedList").innerHTML = `
    <div class="workplace-added-title">
      <strong>Вся загрузка смены за ${formatDate(date) || "выбранный день"}</strong>
      <span>${rows.length} чел., ${totalHours} ч</span>
    </div>
    <div class="table-wrap workplace-added-table-wrap">
      <table>
        <thead>
          <tr>
            <th>Таб. №</th>
            <th>ФИО</th>
            <th>Место</th>
            <th>Разряд</th>
            <th>Вид</th>
            <th>Часы</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          ${rows.map((row) => `
            <tr class="${workplaceRowClass(row)}"${specialRoleStyleAttribute(row.role)}>
              <td>${escapeHtml(row.tab)}</td>
              <td>${escapeHtml(row.name)}</td>
              <td>${escapeHtml(row.place)}</td>
              <td>${escapeHtml(row.grade)}</td>
              <td>${escapeHtml(row.kind)}</td>
              <td>${escapeHtml(row.hours)}</td>
              <td><button class="danger compact-delete" type="button" onclick="deleteWorkplaceRow('${escapeJs(row.type)}', '${escapeJs(row.id)}', '${escapeJs(row.date || date)}', '${escapeJs(row.tab)}', '${escapeJs(row.name)}', '${escapeJs(row.actualPlace || row.place)}')">Удалить</button></td>
            </tr>
          `).join("") || `<tr><td colspan="7">За эту смену записи ещё не внесены.</td></tr>`}
        </tbody>
      </table>
    </div>
  `;
}
function renderWorkplaceAbsenceList(date) {
  const rows = date ? selectedHierarchyMissingEmployees(date) : [];
  document.querySelector(".workplace-editor")?.classList.toggle("has-added", rows.length > 0);
  $("workplaceAddedList").innerHTML = `
    <div class="workplace-added-title">
      <strong>Отсутствующие за ${formatDate(date) || "выбранный день"}</strong>
      <span>${rows.length} чел.</span>
    </div>
    <div class="absence-list workplace-absence-list">
      ${rows.length ? rows.map((row) => `
        <article class="absence-item">
          <div class="absence-person">
            <strong>${escapeHtml(row.name)}</strong>
            <span>Таб. № ${escapeHtml(row.tab)} · ${escapeHtml(row.place)} · ${escapeHtml(row.grade)}р.</span>
          </div>
          <label class="absence-reason-field">
            Причина
            <select class="absence-reason-select" data-absence-date="${escapeHtml(date)}" data-absence-tab="${escapeHtml(row.tab)}" data-absence-name="${escapeHtml(row.name)}">
              <option value="" ${row.reason ? "" : "selected"}>Выбрать причину</option>
              ${ABSENCE_REASONS.map((reason) => `<option value="${escapeHtml(reason)}" ${row.reason === reason ? "selected" : ""}>${escapeHtml(reason)}</option>`).join("")}
            </select>
          </label>
        </article>
      `).join("") : `<div class="absent-empty">Все сотрудники поставлены на рабочие места.</div>`}
    </div>
  `;
  $("workplaceAddedList").querySelectorAll("[data-absence-date]").forEach((select) => {
    select.addEventListener("change", () => {
      setAbsenceReason(select.dataset.absenceDate, select.dataset.absenceTab, select.dataset.absenceName, select.value);
    });
  });
}

function shiftOverviewRows(date) {
  const cache = ensureWorkplaceCache(date);
  if (cache.overviewRows) return cache.overviewRows;
  const rows = currentEntries()
    .filter((entry) => entry.date === date)
    .map((entry) => ({
      id: entry.id,
      type: "entry",
      date: entry.date,
      place: overviewEntryPlace(entry),
      actualPlace: entry.actualPlace,
      name: entry.name,
      tab: entry.tab,
      grade: entry.actualGrade,
      role: entry.role,
      isSubworker: entryIsSubworker(entry),
      kind: entryKindLabel(entry),
      hours: entry.hours,
      comment: entry.comment || "",
      order: placeSortOrder(entry.actualPlace),
    }));

  const assignedProletchikIds = new Set(currentEntries()
    .filter((entry) => entry.date === date && entry.sourceProletchikId)
    .map((entry) => entry.sourceProletchikId));

  currentProletchikShifts()
    .filter((shift) => shift.date === date && !assignedProletchikIds.has(shift.id))
    .forEach((shift) => {
      rows.push({
        id: shift.id,
        type: "proletchik",
        place: "Пролётчик",
        name: shift.name,
        tab: shift.tab,
        grade: "",
        kind: "Пролётчик не распределён",
        hours: "",
        comment: shift.comment || "",
        order: 98,
      });
    });

  const assignedCapitalRepairIds = new Set(currentEntries()
    .filter((entry) => entry.date === date && entry.sourceCapitalRepairId)
    .map((entry) => entry.sourceCapitalRepairId));

  currentCapitalRepairShifts()
    .filter((shift) => shift.date === date && !assignedCapitalRepairIds.has(shift.id))
    .forEach((shift) => {
      rows.push({
        id: shift.id,
        type: "capitalRepair",
        place: "Капитальный ремонт",
        name: shift.name,
        tab: shift.tab,
        grade: "5",
        kind: "Капитальный ремонт не распределён",
        hours: "",
        comment: shift.comment || "",
        order: 97,
      });
    });

  cache.overviewRows = rows.sort((a, b) =>
    a.order - b.order
    || Number(b.grade || 0) - Number(a.grade || 0)
    || a.place.localeCompare(b.place, "ru")
    || a.name.localeCompare(b.name, "ru")
  );
  return cache.overviewRows;
}

function overviewEntryPlace(entry) {
  const place = entry.actualPlace || "Не указано";
  if (entry.role === "proletchik") return `${specialWorkLabel("proletchik", "Пролётчик")} → ${place}`;
  if (entry.role === "capitalRepair") return `${specialWorkLabel("capitalRepair", "Капремонт")} → ${place}`;
  if (normalizeCustomSpecialRoleId(entry.role)) return `${specialWorkLabel(entry.role, "Спецработа")} → ${place}`;
  return place;
}

function placeSortOrder(place) {
  const code = placeCode(place);
  const furnaceIndex = FURNACES.indexOf(code);
  if (furnaceIndex !== -1) return furnaceIndex;
  if (code === "РМ") return 80;
  if (place === "Пролётчик") return 98;
  return 99;
}

function renderShiftOverview() {
  const target = $("shiftOverviewMount") || $("shiftOverview");
  if (!target) return;
  const date = $("workplaceDateInput").value;
  const rows = shiftOverviewRows(date);
  const totalHours = Number(rows.reduce((sum, row) => sum + Number(row.hours || 0), 0).toFixed(1));

  target.innerHTML = `
    <div class="workplace-added-title">
      <strong>Вся смена за ${formatDate(date) || "выбранный день"}</strong>
      <span>${rows.length} записей, ${totalHours} ч</span>
    </div>
    <div class="table-wrap workplace-added-table-wrap">
      <table>
        <thead>
          <tr>
            <th></th>
            <th>Рабочее место</th>
            <th>ФИО</th>
            <th>Таб. №</th>
            <th>Разряд</th>
            <th>Вид</th>
            <th>Часы</th>
            <th>Комментарий</th>
          </tr>
        </thead>
        <tbody>
          ${rows.map((row) => `
            <tr class="${workplaceRowClass(row)}"${specialRoleStyleAttribute(row.role)}>
              <td><button class="danger compact-delete" type="button" onclick="deleteWorkplaceRow('${row.type}', '${row.id}')">Удалить</button></td>
              <td>${escapeHtml(row.place)}</td>
              <td>${escapeHtml(row.name)}</td>
              <td>${escapeHtml(row.tab)}</td>
              <td>${escapeHtml(row.grade)}</td>
              <td>${escapeHtml(row.kind)}</td>
              <td>${escapeHtml(row.hours)}</td>
              <td>${escapeHtml(row.comment)}</td>
            </tr>
          `).join("") || `<tr><td colspan="8">За эту смену записи ещё не внесены.</td></tr>`}
        </tbody>
      </table>
    </div>
  `;
}

function deleteWorkplaceRow(type, id, date = "", tab = "", name = "", place = "") {
  if (!confirm("Удалить эту запись с рабочего места?")) return;
  if (type === "proletchik") {
    deleteProletchikShift(id, { skipAdmin: true });
    return;
  }
  if (type === "capitalRepair") {
    deleteCapitalRepairShift(id, { skipAdmin: true });
    return;
  }
  deleteEntry(id, { date, tab, name, place }, { skipAdmin: true });
}

function prefillWorkplaceEmployee() {
  const normalized = normalizeName($("workplaceEmployeeInput").value);
  const employee = employeeChoicesForWorkplace().find((item) => normalizeName(item.name) === normalized)
    || unifiedEmployeeByName($("workplaceEmployeeInput").value);
  if (!employee) return;
  fillWorkplaceEmployee(employee);
}

function selectWorkplaceEmployee() {
  const select = $("workplaceEmployeeSelect");
  if (!select?.value) return;
  const employee = employeeChoicesForWorkplace().find((item) => employeeSelectValue(item) === select.value)
    || unifiedEmployeeByTab(select.value);
  if (!employee) return;
  $("workplaceEmployeeInput").value = employee.name;
  fillWorkplaceEmployee(employee);
}

function employeeSelectValue(employee) {
  return `${itemBrigade(employee)}::${employee.tab || normalizeName(employee.name)}`;
}

function workplaceEmployeeOptionLabel(employee) {
  const brigade = itemBrigade(employee);
  const brigadePart = brigade && brigade !== currentBrigade() ? `Бр.${brigade}` : "";
  return [employee.name, brigadePart, employee.place, `${employee.grade}р.`]
    .filter(Boolean)
    .join(" · ");
}

function applyCompactWorkplaceLabels() {
  const roleSelect = $("workplaceRoleInput");
  const employeeInput = $("workplaceEmployeeInput");
  employeeInput?.setAttribute("placeholder", "ФИО работника");
  employeeInput?.closest("label")?.classList.add("mobile-wide-field");
  roleSelect?.closest("label")?.classList.add("mobile-wide-field");
  if (!roleSelect) return;
  const labels = {
    auto: "Штатный",
  };
  [...roleSelect.options].forEach((option) => {
    if (labels[option.value]) option.textContent = labels[option.value];
  });
}

function fillWorkplaceEmployee(employee) {
  $("workplaceTabInput").value = employee.tab;
  $("workplaceGradeInput").value = String(employee.grade);
  const currentRole = $("workplaceRoleInput").value;
  const fixedRole = selectedWorkplace === "Пролётчик"
    ? "proletchik"
    : selectedWorkplace === "Капитальный ремонт"
      ? "capitalRepair"
      : currentRole;
  const settings = appSettings();
  const availableRole = specialRoleDefinitionsForWorkplace(selectedWorkplace, settings, selectedWorkplaceDepartmentId)
    .some((role) => role.id === fixedRole);
  $("workplaceRoleInput").value = availableRole ? fixedRole : "auto";
}

function updateWorkplaceHours() {
  $("workplaceHoursInput").value = hoursForKind($("workplaceShiftKindInput").value, $("workplaceShiftCountInput")?.value || 1);
}

function absenceKey(item) {
  return item.tab ? `tab:${item.tab}` : `name:${normalizeName(item.name)}`;
}

function workedKeysForDate(date) {
  const keys = new Set();
  currentEntries()
    .filter((entry) => entry.date === date)
    .forEach((entry) => keys.add(absenceKey(entry)));
  currentProletchikShifts()
    .filter((shift) => shift.date === date)
    .forEach((shift) => keys.add(absenceKey(shift)));
  currentCapitalRepairShifts()
    .filter((shift) => shift.date === date)
    .forEach((shift) => keys.add(absenceKey(shift)));
  return keys;
}

function syncAutoAbsencesForDate(date) {
  if (!date) return;
  const worked = workedKeysForDate(date);
  const withoutWorked = (state.absences || []).filter((absence) =>
    !(belongsToCurrentBrigade(absence) && absence.date === date && worked.has(absenceKey(absence)))
  );
  const withoutOldAuto = withoutWorked.filter((absence) => !(belongsToCurrentBrigade(absence) && absence.date === date && absence.auto));

  if (!worked.size) {
    state.absences = withoutOldAuto;
    return;
  }

  const existingManual = new Set(
    withoutOldAuto
      .filter((absence) => belongsToCurrentBrigade(absence) && absence.date === date)
      .map((absence) => absenceKey(absence))
  );

  const autoAbsences = currentEmployees()
    .filter((employee) => !worked.has(absenceKey(employee)))
    .filter((employee) => !existingManual.has(absenceKey(employee)))
    .map((employee) => ({
      id: crypto.randomUUID(),
      brigade: currentBrigade(),
      date,
      name: employee.name,
      tab: employee.tab,
      reason: AUTO_ABSENCE_REASON,
      comment: "Добавлено автоматически после заполнения рабочих мест",
      auto: true,
    }));

  state.absences = [...withoutOldAuto, ...autoAbsences]
    .sort((a, b) => a.date.localeCompare(b.date) || a.name.localeCompare(b.name, "ru"));
}

function clearWorkplaceForm(options = {}) {
  $("workplaceEmployeeInput").value = "";
  if ($("workplaceEmployeeSelect")) $("workplaceEmployeeSelect").value = "";
  $("workplaceTabInput").value = "";
  refreshSpecialWorkLabels();
  $("workplaceRoleInput").value = "auto";
  if ($("workplaceCommentInput")) $("workplaceCommentInput").value = "";
  $("customWorkplaceInput").value = "";
  $("workplaceShiftKindInput").value = "regular";
  if ($("workplaceShiftCountInput")) $("workplaceShiftCountInput").value = "1";
  updateWorkplaceHours();
  if (options.updateView !== false) updateSelectedWorkplaceView();
}

function updateHours() {
  $("hoursInput").value = hoursForKind($("shiftKindInput").value, $("shiftCountInput")?.value || 1);
}

function refreshEmployeeList() {
  const employees = employeeChoicesForWorkplace();
  $("employeeList").innerHTML = employees
    .sort((a, b) =>
      a.listOrder - b.listOrder
      || itemBrigade(a).localeCompare(itemBrigade(b), "ru")
      || compareEmployeeWorkplaceGrade(a, b)
    )
    .map((employee) => `<option value="${employee.name}">${employee.listGroup} · ${employee.tab} · Бригада ${itemBrigade(employee)} · ${employee.place} · ${employee.grade} разряд</option>`)
    .join("");
  if ($("workplaceEmployeeSelect")) {
    $("workplaceEmployeeSelect").innerHTML = `<option value="">Выбери сотрудника</option>${employees
      .sort((a, b) =>
        a.listOrder - b.listOrder
        || itemBrigade(a).localeCompare(itemBrigade(b), "ru")
        || compareEmployeeWorkplaceGrade(a, b)
      )
      .map((employee) => `<option value="${escapeHtml(employeeSelectValue(employee))}">${escapeHtml(workplaceEmployeeOptionLabel(employee))}</option>`)
      .join("")}`;
  }
}

function employeeChoicesForWorkplace() {
  const date = selectedShiftDate();
  const kind = selectedShiftKindForDate(date);
  const reliefBrigade = eligibleSubworkBrigade(date, kind);
  const blocked = blockedSubworkBrigades(date, kind);
  const current = currentEmployees()
    .map((employee) => ({ ...employee, listGroup: "Текущая смена", listOrder: 0 }));
  const currentKeys = new Set(current.map(absenceKey));
  const relief = reliefBrigade
    ? activeEmployeesForBrigade(reliefBrigade)
      .filter((employee) => !blocked.has(itemBrigade(employee)))
      .filter((employee) => !currentKeys.has(absenceKey(employee)))
      .map((employee) => ({ ...employee, listGroup: `Подработка из бригады ${reliefBrigade}`, listOrder: 1 }))
    : [];
  const choices = [...current, ...relief];
  if (selectedWorkplace === "РМ") {
    return choices.map((employee) => {
      const isCurrent = itemBrigade(employee) === currentBrigade();
      const isCaster = employee.place === "РМ" || employee.role === "caster";
      const listOrder = isCurrent
        ? (isCaster ? 0 : 1)
        : (isCaster ? 2 : 3);
      const listGroup = isCurrent
        ? (isCaster ? "Разливщики текущей смены" : "Плавильщики текущей смены")
        : (isCaster ? `Разливщики подработки из бригады ${itemBrigade(employee)}` : `Плавильщики подработки из бригады ${itemBrigade(employee)}`);
      return { ...employee, listGroup, listOrder };
    });
  }
  return choices;
}

function allowedEmployeeForWorkplace(employee, date = selectedShiftDate()) {
  if (!employee) return true;
  const brigade = itemBrigade(employee);
  if (brigade === currentBrigade()) return true;
  const kind = selectedShiftKindForDate(date);
  return brigade === eligibleSubworkBrigade(date, kind);
}

function allowedEmployeeListText(date = selectedShiftDate()) {
  const kind = selectedShiftKindForDate(date);
  const relief = eligibleSubworkBrigade(date, kind);
  return relief
    ? `Разрешена только текущая бригада ${currentBrigade()} и подработка из бригады ${relief}.`
    : `Разрешена только текущая бригада ${currentBrigade()}.`;
}

function sameWorkerKey(tab, name) {
  const cleanTab = String(tab || "").trim();
  if (cleanTab) return `tab:${cleanTab}`;
  return `name:${normalizeName(name)}`;
}

function customEmployeeUniqueKey(employee) {
  const cleanTab = String(employee?.tab || "").trim();
  if (cleanTab) return `tab:${cleanTab}`;
  return `name:${itemBrigade(employee)}:${normalizeName(employee?.name)}`;
}

function removeDuplicateCustomEmployees() {
  const seen = new Set();
  state.customEmployees = [...(state.customEmployees || [])]
    .reverse()
    .filter((employee) => {
      const key = customEmployeeUniqueKey(employee);
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .reverse();
}

function removeCustomEmployeesByIdentity(tab, name) {
  const cleanTab = String(tab || "").trim();
  const normalizedName = normalizeName(name);
  const removed = [];
  state.customEmployees = (state.customEmployees || []).filter((employee) => {
    if (cleanTab && employee.tab === cleanTab) {
      removed.push(employee);
      return false;
    }
    if (normalizedName && normalizeName(employee.name) === normalizedName) {
      removed.push(employee);
      return false;
    }
    return true;
  });
  removed.forEach(rememberDeletedCustomEmployee);
}

function removeCustomEmployeesForDismissal(employee, tab) {
  const cleanTab = String(tab || employee?.tab || "").trim();
  const cleanName = String(employee?.name || "").trim();
  removeCustomEmployeesByIdentity(cleanTab, cleanName);
  removeDuplicateCustomEmployees();
}

function removeEmployeeNonShiftData(employee, brigade) {
  if (!employee) return;
  const brigadeKey = String(brigade || itemBrigade(employee) || BASE_STAFF_BRIGADE);
  const cleanTab = String(employee.tab || "").trim();
  const cleanName = String(employee.name || "").trim();
  const workerKey = sameWorkerKey(cleanTab, cleanName);
  const sameWorker = (item) => itemBrigade(item) === brigadeKey && sameWorkerKey(item.tab, item.name) === workerKey;

  const removedAbsences = (state.absences || []).filter(sameWorker);
  removedAbsences.forEach((absence) => rememberDeletedId("deletedAbsenceIds", absence.id));
  state.absences = (state.absences || []).filter((absence) => !sameWorker(absence));

  const removedVacations = (state.vacations || []).filter(sameWorker);
  removedVacations.forEach((vacation) => rememberDeletedId("deletedVacationIds", vacation.id));
  state.vacations = (state.vacations || []).filter((vacation) => !sameWorker(vacation));

  const phoneKeys = [
    cleanTab ? `${brigadeKey}:${cleanTab}` : "",
    cleanName ? `${brigadeKey}:${normalizeName(cleanName)}` : "",
  ].filter(Boolean);
  if (phoneKeys.length) {
    state.employeePhones = { ...(state.employeePhones || {}) };
    phoneKeys.forEach((key) => {
      state.employeePhones[key] = null;
    });
  }

  const priorityKey = cleanTab ? `${brigadeKey}:${cleanTab}` : "";
  if (priorityKey && state.vacationPriorities?.[priorityKey]) {
    state.vacationPriorities = { ...(state.vacationPriorities || {}) };
    state.vacationPriorities[priorityKey] = null;
  }
  if (priorityKey && state.vacationAllowances?.[priorityKey]) {
    state.vacationAllowances = { ...(state.vacationAllowances || {}) };
    state.vacationAllowances[priorityKey] = null;
  }
  if (cleanTab && state.employeeEdits) {
    state.employeeEdits = { ...(state.employeeEdits || {}) };
    state.employeeEdits[employeeEditSourceKey(brigadeKey, cleanTab)] = null;
    state.employeeEdits[`${brigadeKey}:${cleanTab}`] = null;
  }
}

function dismissBuiltInEmployeeDuplicates(employee, brigade) {
  if (!employee) return;
  const brigadeKey = String(brigade || itemBrigade(employee) || BASE_STAFF_BRIGADE);
  const cleanTab = String(employee.tab || "").trim();
  const normalizedName = normalizeName(employee.name);
  const matches = unifiedEmployees().filter((item) =>
    !item.custom
    && itemBrigade(item) === brigadeKey
    && ((cleanTab && item.tab === cleanTab) || (normalizedName && normalizeName(item.name) === normalizedName))
  );
  matches.forEach((item) => {
    const dismissed = dismissedTabsForBrigade(brigadeKey);
    if (!dismissed.includes(item.tab)) setDismissedTabsForBrigade(brigadeKey, [...dismissed, item.tab]);
    removeEmployeeNonShiftData(item, brigadeKey);
  });
}

function duplicateWorkplaceAssignment(date, tab, name) {
  const key = sameWorkerKey(tab, name);
  const sameKey = (item) => sameWorkerKey(item.tab, item.name) === key;
  const entry = currentEntries().find((item) => item.date === date && sameKey(item));
  if (entry) return `${entry.actualPlace}, ${KIND_LABELS[entry.shiftKind] || entry.shiftKind}`;
  return "";
}

function openGlobalEmployeeAddDialog() {
  if (!requireStaffAdmin("принять сотрудника")) return;
  showEmployeeAddDialog(({ brigade, name, tab, place, grade, position, close }) => {
    if (addGlobalEmployeeRecord({ brigade, name, tab, place, grade, position })) close();
  });
}

function addGlobalEmployeeRecord({ brigade, name, tab, place, grade, position }) {
  state = normalizeAppStateData(state);
  if (!name || !tab) {
    alert("Укажи ФИО и табельный номер.");
    return false;
  }

  const cleanBrigade = String(brigade || currentRealShiftBrigade() || BASE_STAFF_BRIGADE);
  const cleanName = String(name || "").trim();
  const cleanTab = String(tab || "").trim();
  const cleanPlace = String(place || "").trim();
  const allowedPlaces = employeeWorkplaceOptions();
  if (!allowedPlaces.includes(cleanPlace)) {
    alert("Выберите штатное рабочее место сотрудника из списка Цеха 7.");
    return false;
  }
  const cleanPosition = normalizeEmployeePosition(position, cleanPlace);
  if (!cleanPosition) {
    alert("Выберите должность сотрудника.");
    return false;
  }
  const normalizedName = normalizeName(cleanName);
  const activeTabOwner = activeUnifiedEmployees().find((employee) => employee.tab === cleanTab && normalizeName(employee.name) !== normalizedName);
  if (activeTabOwner) {
    alert(`Табельный № ${cleanTab} уже принадлежит сотруднику: ${activeTabOwner.name}. У каждого сотрудника должен быть свой табельный номер.`);
    return false;
  }
  const activeExisting = activeUnifiedEmployees().find((employee) =>
    employee.custom && (employee.tab === cleanTab || normalizeName(employee.name) === normalizedName)
  );
  if (activeExisting) {
    const oldBrigade = itemBrigade(activeExisting);
    setDismissedTabsForBrigade(cleanBrigade, dismissedTabsForBrigade(cleanBrigade).filter((item) => String(item) !== cleanTab));
    const updatedEmployee = touchEmployeeRecord(activeExisting, {
      section: employeeSectionForPlace(cleanPlace),
      place: cleanPlace,
      code: placeCode(cleanPlace),
      tab: cleanTab,
      name: cleanName,
      grade,
      position: cleanPosition,
      role: employeeRoleForPlace(cleanPlace),
      custom: true,
      brigade: cleanBrigade,
    });
    removeCustomEmployeesByIdentity(activeExisting.tab, activeExisting.name);
    removeCustomEmployeesByIdentity(cleanTab, cleanName);
    forgetDeletedCustomEmployee(updatedEmployee);
    state.customEmployees.push(updatedEmployee);
    removeDuplicateCustomEmployees();
    moveEmployeePhoneKey(oldBrigade, activeExisting.tab, activeExisting.name, cleanBrigade, cleanTab, cleanName);
    dismissBuiltInEmployeeDuplicates(updatedEmployee, cleanBrigade);
    saveState();
    refreshEmployeeList();
    render();
    return true;
  }

  activeUnifiedEmployees()
    .filter((employee) => !employee.custom && (employee.tab === cleanTab || normalizeName(employee.name) === normalizedName))
    .forEach((employee) => {
      const employeeBrigade = itemBrigade(employee);
      const dismissed = dismissedTabsForBrigade(employeeBrigade);
      if (!dismissed.includes(employee.tab)) setDismissedTabsForBrigade(employeeBrigade, [...dismissed, employee.tab]);
      removeEmployeeNonShiftData(employee, employeeBrigade);
    });

  removeCustomEmployeesByIdentity(cleanTab, cleanName);
  setDismissedTabsForBrigade(cleanBrigade, dismissedTabsForBrigade(cleanBrigade).filter((item) => String(item) !== cleanTab));
  const newEmployee = touchEmployeeRecord({}, {
    section: employeeSectionForPlace(cleanPlace),
    place: cleanPlace,
    code: placeCode(cleanPlace),
    tab: cleanTab,
    name: cleanName,
    grade,
    position: cleanPosition,
    role: employeeRoleForPlace(cleanPlace),
    custom: true,
    brigade: cleanBrigade,
  });
  forgetDeletedCustomEmployee(newEmployee);
  state.customEmployees.push(newEmployee);
  removeDuplicateCustomEmployees();

  saveState();
  refreshEmployeeList();
  render();
  return true;
}

function addGlobalEmployee(event) {
  event.preventDefault();
  if (!requireStaffAdmin("принять сотрудника")) return;
  const brigade = $("globalEmployeeBrigadeInput")?.value || currentRealShiftBrigade();
  const name = $("globalEmployeeNameInput")?.value.trim() || "";
  const tab = $("globalEmployeeTabInput")?.value.trim() || "";
  const place = $("globalEmployeePlaceInput")?.value || "Печь 41";
  const grade = Number($("globalEmployeeGradeInput")?.value || 5);
  const position = normalizeEmployeePosition($("globalEmployeePositionInput")?.value, place);

  if (!addGlobalEmployeeRecord({ brigade, name, tab, place, grade, position })) return;
  if ($("globalEmployeeNameInput")) $("globalEmployeeNameInput").value = "";
  if ($("globalEmployeeTabInput")) $("globalEmployeeTabInput").value = "";
  if ($("globalEmployeeGradeInput")) $("globalEmployeeGradeInput").value = "5";
  if ($("globalEmployeePositionInput")) $("globalEmployeePositionInput").value = normalizeEmployeePosition("", place);
}

function addEmployee(event) {
  event.preventDefault();
  if (!requireStaffAdmin("принять сотрудника")) return;
  const name = $("newEmployeeNameInput").value.trim();
  const tab = $("newEmployeeTabInput").value.trim();
  const place = $("newEmployeePlaceInput").value;
  const grade = Number($("newEmployeeGradeInput").value);
  const position = normalizeEmployeePosition($("newEmployeePositionInput")?.value, place);

  if (!name || !tab || !position) {
    alert("Укажи ФИО, табельный номер и должность.");
    return;
  }

  const activeTabOwner = currentEmployees().find((employee) => employee.tab === tab && normalizeName(employee.name) !== normalizeName(name));
  if (activeTabOwner) {
    alert(`Табельный № ${tab} уже принадлежит сотруднику: ${activeTabOwner.name}. У каждого сотрудника должен быть свой табельный номер.`);
    return;
  }

  const existing = currentEmployees().find((employee) =>
    employee.custom && (employee.tab === tab || normalizeName(employee.name) === normalizeName(name))
  );
  if (existing) {
    const updatedEmployee = touchEmployeeRecord(existing, {
      section: employeeSectionForPlace(place),
      place,
      code: placeCode(place),
      tab,
      name,
      grade,
      position,
      role: employeeRoleForPlace(place),
      custom: true,
      brigade: currentBrigade(),
    });
    removeCustomEmployeesByIdentity(existing.tab, existing.name);
    removeCustomEmployeesByIdentity(tab, name);
    forgetDeletedCustomEmployee(updatedEmployee);
    state.customEmployees.push(updatedEmployee);
    removeDuplicateCustomEmployees();
    moveEmployeePhoneKey(currentBrigade(), existing.tab, existing.name, currentBrigade(), tab, name);
    dismissBuiltInEmployeeDuplicates(updatedEmployee, currentBrigade());
    saveState();
    refreshEmployeeList();
    render();
    return;
  }

  currentEmployees()
    .filter((employee) => !employee.custom && (employee.tab === tab || normalizeName(employee.name) === normalizeName(name)))
    .forEach((employee) => {
      const dismissed = currentDismissedTabs();
      if (!dismissed.includes(employee.tab)) setCurrentDismissedTabs([...dismissed, employee.tab]);
      removeEmployeeNonShiftData(employee, currentBrigade());
    });

  removeCustomEmployeesByIdentity(tab, name);
  const newEmployee = touchEmployeeRecord({}, {
    section: employeeSectionForPlace(place),
    place,
    code: placeCode(place),
    tab,
    name,
    grade,
    position,
    role: employeeRoleForPlace(place),
    custom: true,
    brigade: currentBrigade(),
  });
  forgetDeletedCustomEmployee(newEmployee);
  state.customEmployees.push(newEmployee);
  removeDuplicateCustomEmployees();

  $("newEmployeeNameInput").value = "";
  $("newEmployeeTabInput").value = "";
  $("newEmployeePlaceInput").value = "Печь 41";
  $("newEmployeeGradeInput").value = "5";
  if ($("newEmployeePositionInput")) $("newEmployeePositionInput").value = normalizeEmployeePosition("", "Печь 41");
  saveState();
  refreshEmployeeList();
  render();
}

function dismissEmployee(tab) {
  if (!requireStaffAdmin("уволить сотрудника")) return;
  const text = "Убрать сотрудника из активного штата? Уже введённые смены не удалятся.";
  if (!confirm(text)) return;
  const cleanTab = String(tab || "").trim();
  const employee = currentEmployees().find((item) => item.tab === cleanTab) || allEmployees().find((item) => item.tab === cleanTab);
  const targetEmployee = employee || { tab: cleanTab, brigade: currentBrigade() };
  removeEmployeeNonShiftData(targetEmployee, currentBrigade());
  dismissBuiltInEmployeeDuplicates(targetEmployee, currentBrigade());
  removeCustomEmployeesForDismissal(targetEmployee, cleanTab);
  if (!employee?.custom) {
    const dismissed = currentDismissedTabs();
    if (!dismissed.includes(cleanTab)) setCurrentDismissedTabs([...dismissed, cleanTab]);
  }
  saveState();
  refreshEmployeeList();
  render();
}

function restoreEmployee(tab) {
  if (!requireStaffAdmin("восстановить сотрудника")) return;
  const cleanTab = String(tab || "").trim();
  setCurrentDismissedTabs(currentDismissedTabs().filter((item) => item !== cleanTab));
  saveState();
  refreshEmployeeList();
  render();
}

function removeCustomEmployee(tab) {
  if (!requireStaffAdmin("полностью удалить сотрудника")) return;
  const cleanTab = String(tab || "").trim();
  if (!confirm("Полностью удалить вновь добавленного сотрудника из базы?")) return;
  const employee = currentEmployees().find((item) => item.tab === cleanTab) || allEmployees().find((item) => item.tab === cleanTab);
  removeEmployeeNonShiftData(employee || { tab: cleanTab, brigade: currentBrigade() }, currentBrigade());
  removeCustomEmployeesForDismissal(employee, cleanTab);
  setCurrentDismissedTabs(currentDismissedTabs().filter((item) => item !== cleanTab));
  saveState();
  refreshEmployeeList();
  render();
}

function editEmployee(tab) {
  if (!requireStaffAdmin("редактировать штатные данные сотрудника")) return;
  const cleanTab = String(tab || "").trim();
  const employee = allEmployees().find((item) => item.tab === cleanTab);
  if (!employee) {
    alert("Сотрудник не найден в текущей бригаде.");
    return;
  }

  const place = prompt("Рабочее место сотрудника:", employee.place);
  if (place === null) return;
  const cleanPlace = place.trim();
  if (!cleanPlace) {
    alert("Рабочее место не может быть пустым.");
    return;
  }

  const gradeText = prompt("Разряд сотрудника:", String(employee.grade));
  if (gradeText === null) return;
  const grade = Number(String(gradeText).replace(",", "."));
  if (!Number.isFinite(grade) || grade < 1 || grade > 9) {
    alert("Укажи разряд числом.");
    return;
  }

  const positionText = prompt("Должность сотрудника:", employeePositionValue(employee));
  if (positionText === null) return;
  const position = normalizeEmployeePosition(positionText, cleanPlace);
  if (!position) {
    alert("Должность не может быть пустой.");
    return;
  }

  const customIndex = (state.customEmployees || []).findIndex((item) => item.tab === cleanTab && itemBrigade(item) === currentBrigade());
  if (customIndex >= 0) {
    const updated = touchEmployeeRecord(state.customEmployees[customIndex], {
      place: cleanPlace,
      grade,
      position,
      code: placeCode(cleanPlace),
      section: employeeSectionForPlace(cleanPlace),
      role: employeeRoleForPlace(cleanPlace),
    });
    state.customEmployees.splice(customIndex, 1, updated);
  } else {
    state.employeeEdits = {
      ...(state.employeeEdits || {}),
      [employeeEditKey(employee)]: {
        place: cleanPlace,
        grade,
        position,
      },
    };
  }

  saveState();
  refreshEmployeeList();
  render();
}

function dismissGlobalEmployee(tab, brigade) {
  if (!requireStaffAdmin("уволить сотрудника")) return;
  const cleanTab = String(tab || "").trim();
  const brigadeKey = String(brigade || BASE_STAFF_BRIGADE);
  if (!confirm("Убрать сотрудника из активного состава выбранной бригады? Уже введённые смены не удалятся.")) return;
  const employee = activeUnifiedEmployees().find((item) => item.tab === cleanTab && itemBrigade(item) === brigadeKey)
    || unifiedEmployees().find((item) => item.tab === cleanTab && itemBrigade(item) === brigadeKey);
  const targetEmployee = employee || { tab: cleanTab, brigade: brigadeKey };
  removeEmployeeNonShiftData(targetEmployee, brigadeKey);
  dismissBuiltInEmployeeDuplicates(targetEmployee, brigadeKey);
  removeCustomEmployeesForDismissal(targetEmployee, cleanTab);
  if (!employee?.custom) {
    const dismissed = dismissedTabsForBrigade(brigadeKey);
    if (!dismissed.includes(cleanTab)) setDismissedTabsForBrigade(brigadeKey, [...dismissed, cleanTab]);
  }
  saveState();
  refreshEmployeeList();
  render();
}

function restoreGlobalEmployee(tab, brigade) {
  if (!requireStaffAdmin("восстановить сотрудника")) return;
  const cleanTab = String(tab || "").trim();
  const brigadeKey = String(brigade || BASE_STAFF_BRIGADE);
  setDismissedTabsForBrigade(brigadeKey, dismissedTabsForBrigade(brigadeKey).filter((item) => item !== cleanTab));
  saveState();
  refreshEmployeeList();
  render();
}

function editGlobalEmployeeGrade(tab, brigade) {
  if (!requireStaffAdmin("редактировать сотрудника")) return;
  const cleanTab = String(tab || "").trim();
  const brigadeKey = String(brigade || BASE_STAFF_BRIGADE);
  const employee = allEmployeesForBrigade(brigadeKey).find((item) => item.tab === cleanTab);
  if (!employee) {
    alert("Сотрудник не найден в выбранной бригаде.");
    return;
  }

  showEmployeeEditDialog(employee, brigadeKey, ({ name, tab: newTab, targetBrigade, place, grade, position }) => {
    const cleanTargetBrigade = String(targetBrigade).trim();
  if (!["1", "2", "3", "4"].includes(cleanTargetBrigade)) {
    alert("Укажи номер бригады: 1, 2, 3 или 4.");
    return;
  }

  const cleanName = String(name || "").trim();
  const cleanNewTab = String(newTab || "").trim();
  if (!cleanName) {
    alert("ФИО не может быть пустым.");
    return;
  }
  if (!cleanNewTab) {
    alert("Табельный номер не может быть пустым.");
    return;
  }

  const cleanPlace = String(place).trim();
  const allowedPlaces = employeeExistingWorkplaceOptions(employee.place);
  if (!allowedPlaces.includes(cleanPlace)) {
    alert(`Укажи рабочее место из списка: ${allowedPlaces.join(", ")}.`);
    return;
  }

  if (!Number.isFinite(grade) || grade < 1 || grade > 9) {
    alert("Укажи разряд числом.");
    return;
  }
  const cleanPosition = normalizeEmployeePosition(position, cleanPlace);
  if (!cleanPosition) {
    alert("Выберите должность сотрудника.");
    return;
  }

  const activeDuplicate = allEmployeesForBrigade(cleanTargetBrigade)
    .some((item) => item.tab === cleanNewTab && !(item.tab === cleanTab && itemBrigade(item) === brigadeKey) && !isDismissedInBrigade(item.tab, cleanTargetBrigade));
  if (activeDuplicate) {
    alert("В выбранной бригаде уже есть активный сотрудник с таким табельным номером.");
    return;
  }

  const sourceEditKey = employeeEditSourceKey(brigadeKey, cleanTab);
  const customIndex = (state.customEmployees || []).findIndex((item) => item.tab === cleanTab && itemBrigade(item) === brigadeKey);
  if (customIndex >= 0) {
    state.customEmployees.splice(customIndex, 1, touchEmployeeRecord(state.customEmployees[customIndex], {
      brigade: cleanTargetBrigade,
      name: cleanName,
      tab: cleanNewTab,
      place: cleanPlace,
      code: placeCode(cleanPlace),
      grade,
      position: cleanPosition,
      section: employeeSectionForPlace(cleanPlace),
      role: employeeRoleForPlace(cleanPlace),
    }));
    moveEmployeePhoneKey(brigadeKey, cleanTab, employee.name, cleanTargetBrigade, cleanNewTab, cleanName);
  } else if (cleanTargetBrigade === brigadeKey) {
    state.employeeEdits = {
      ...(state.employeeEdits || {}),
      [sourceEditKey]: {
        name: cleanName,
        tab: cleanNewTab,
        place: cleanPlace,
        grade,
        position: cleanPosition,
        updatedAt: new Date().toISOString(),
      },
    };
    moveEmployeePhoneKey(brigadeKey, cleanTab, employee.name, cleanTargetBrigade, cleanNewTab, cleanName);
  } else {
    state.customEmployees.push(touchEmployeeRecord({}, {
      section: employeeSectionForPlace(cleanPlace),
      place: cleanPlace,
      code: placeCode(cleanPlace),
      tab: cleanNewTab,
      name: cleanName,
      grade,
      position: cleanPosition,
      role: employeeRoleForPlace(cleanPlace),
      custom: true,
      brigade: cleanTargetBrigade,
    }));
    const sourceDismissed = dismissedTabsForBrigade(brigadeKey);
    if (!sourceDismissed.includes(cleanTab)) setDismissedTabsForBrigade(brigadeKey, [...sourceDismissed, cleanTab]);
    setDismissedTabsForBrigade(cleanTargetBrigade, dismissedTabsForBrigade(cleanTargetBrigade).filter((item) => item !== cleanNewTab));
    moveEmployeePhoneKey(brigadeKey, cleanTab, employee.name, cleanTargetBrigade, cleanNewTab, cleanName);
  }

  if (cleanTargetBrigade !== brigadeKey && $("globalEmployeeBrigadeInput")) $("globalEmployeeBrigadeInput").value = cleanTargetBrigade;
    updateEmployeeReferences(employee, brigadeKey, { name: cleanName, tab: cleanNewTab });
    saveState();
    refreshEmployeeList();
    render();
  });
}
function transferGlobalEmployee(tab, fromBrigade) {
  if (!requireStaffAdmin("перевести сотрудника в другую бригаду")) return;
  const cleanTab = String(tab || "").trim();
  const sourceBrigade = String(fromBrigade || BASE_STAFF_BRIGADE);
  const employee = allEmployeesForBrigade(sourceBrigade).find((item) => item.tab === cleanTab);
  if (!employee) {
    alert("Сотрудник не найден в выбранной бригаде.");
    return;
  }

  const targetBrigade = prompt("В какую бригаду перевести? Укажи 1, 2, 3 или 4:", sourceBrigade);
  if (targetBrigade === null) return;
  const cleanTarget = String(targetBrigade).trim();
  if (!["1", "2", "3", "4"].includes(cleanTarget)) {
    alert("Укажи номер бригады: 1, 2, 3 или 4.");
    return;
  }
  if (cleanTarget === sourceBrigade) {
    alert("Сотрудник уже в этой бригаде.");
    return;
  }
  if (allEmployeesForBrigade(cleanTarget).some((item) => item.tab === cleanTab)) {
    alert("В выбранной бригаде сотрудник с таким табельным номером уже есть.");
    return;
  }

  const customIndex = (state.customEmployees || []).findIndex((item) => item.tab === cleanTab && itemBrigade(item) === sourceBrigade);
  if (customIndex >= 0) {
    state.customEmployees.splice(customIndex, 1, touchEmployeeRecord(state.customEmployees[customIndex], {
      brigade: cleanTarget,
    }));
  } else {
    state.customEmployees.push(touchEmployeeRecord({}, {
      section: employee.section,
      place: employee.place,
      code: placeCode(employee.place),
      tab: employee.tab,
      name: employee.name,
      grade: employee.grade,
      position: employeePositionValue(employee),
      role: employee.role,
      custom: true,
      brigade: cleanTarget,
    }));
  }

  const sourceDismissed = dismissedTabsForBrigade(sourceBrigade);
  if (!sourceDismissed.includes(cleanTab)) setDismissedTabsForBrigade(sourceBrigade, [...sourceDismissed, cleanTab]);
  setDismissedTabsForBrigade(cleanTarget, dismissedTabsForBrigade(cleanTarget).filter((item) => item !== cleanTab));
  if ($("globalEmployeeBrigadeInput")) $("globalEmployeeBrigadeInput").value = cleanTarget;
  saveState();
  refreshEmployeeList();
  render();
}

function addEntry(event) {
  event.preventDefault();
  const employee = employeeByName($("employeeInput").value);
  const sourceEmployee = unifiedEmployeeByName($("employeeInput").value);
  const actualPlace = $("actualPlaceInput").value;
  const role = $("roleInput").value === "auto"
    ? automaticAssignmentRole(employee || sourceEmployee, actualPlace)
    : $("roleInput").value;
  const ordinaryExternal = $("roleInput").value === "auto"
    && !employee
    && !specialRoleEnabledForWorkplace("subworker", actualPlace, appSettings());
  const shiftKind = $("shiftKindInput").value;
  const date = $("dateInput").value;
  const name = $("employeeInput").value.trim();
  const tab = $("tabInput").value.trim() || sourceEmployee?.tab || "";
  if (isCastingPlaceValue(actualPlace) && (shiftKind === "repair" || shiftKind === "warmup")) {
    alert("У разливщиков нет смен ремонта или разогрева. Для РМ можно поставить только обычную смену.");
    return;
  }
  const actualGrade = Number($("actualGradeInput").value);
  if (!validateWorkplaceGradeLimit(date, actualPlace, actualGrade)) return;
  if (!validateWorkplaceSpecialLimit(date, actualPlace, role)) return;
  const duplicate = duplicateWorkplaceAssignment(date, tab, name);
  if (duplicate) {
    alert(`Этот сотрудник уже добавлен на эту смену: ${duplicate}. Сначала удали старую запись, потом добавь новую.`);
    return;
  }
  const entry = {
    id: crypto.randomUUID(),
    brigade: currentBrigade(),
    date,
    name,
    tab,
    actualPlace,
    departmentId: configuredDepartmentIdForWorkplace(actualPlace, appSettings()),
    actualGrade,
    shiftKind,
    shiftCount: Number($("shiftCountInput")?.value || 1),
    hours: Number($("hoursInput").value || 0),
    role,
    ...(ordinaryExternal ? { ordinaryExternal: true } : {}),
    comment: $("commentInput")?.value.trim() || "",
    scheduleShift: getShiftForDate($("dateInput").value).label,
    updatedAt: new Date().toISOString(),
  };

  forgetDeletedEntry(entry);
  state.entries.push(entry);
  state.entries.sort((a, b) => a.date.localeCompare(b.date) || a.name.localeCompare(b.name));
  syncAutoAbsencesForDate(entry.date);
  saveState({ sync: false });
  scheduleSupabasePushOnly();
  clearShiftForm(false);
  render();
}

async function addWorkplaceEntry(event) {
  event.preventDefault();
  const selectedPlaceBeforeAdd = selectedWorkplace;
  const brigadeBeforeAdd = currentBrigade();
  const employee = employeeByName($("workplaceEmployeeInput").value);
  const sourceEmployee = unifiedEmployeeByName($("workplaceEmployeeInput").value);
  const name = $("workplaceEmployeeInput").value.trim();
  const tab = $("workplaceTabInput").value.trim() || sourceEmployee?.tab || employee?.tab || "";
  const selectedRole = $("workplaceRoleInput").value;
  const workDate = $("workplaceDateInput").value;

  if (!workDate) {
    alert("Дата смены не выбрана. Вернись назад к графику смен и выбери дату.");
    return;
  }

  if (!name) {
    alert("Укажи ФИО работника.");
    return;
  }

  if (sourceEmployee && !allowedEmployeeForWorkplace(sourceEmployee, workDate)) {
    alert(`Этого сотрудника нельзя поставить в эту смену: он из бригады ${itemBrigade(sourceEmployee)}.\n${allowedEmployeeListText(workDate)}`);
    return;
  }

  const duplicate = duplicateWorkplaceAssignment(workDate, tab, name);
  if (duplicate) {
    alert(`Этот сотрудник уже добавлен на эту смену: ${duplicate}. Сначала удали старую запись, потом добавь новую.`);
    return;
  }

  const actualPlaceRaw = selectedPlaceBeforeAdd === "Другое место"
    ? $("customWorkplaceInput").value.trim()
    : (selectedPlaceBeforeAdd === "Пролётчик" || selectedPlaceBeforeAdd === "Капитальный ремонт")
      ? $("targetWorkplaceInput").value
      : selectedPlaceBeforeAdd;
  const actualPlace = canonicalWorkplaceKey(actualPlaceRaw) || actualPlaceRaw;
  const shiftKind = $("workplaceShiftKindInput").value;
  if (!actualPlace) {
    alert("Укажи название рабочего места.");
    return;
  }
  const role = selectedRole === "auto"
    ? automaticAssignmentRole(employee || sourceEmployee, actualPlace, selectedWorkplaceDepartmentId)
    : selectedRole;
  const ordinaryExternal = selectedRole === "auto"
    && !employee
    && !specialRoleEnabledForWorkplace("subworker", actualPlace, appSettings(), selectedWorkplaceDepartmentId);
  if (isCastingPlaceValue(actualPlace) && (shiftKind === "repair" || shiftKind === "warmup")) {
    alert("У разливщиков нет смен ремонта или разогрева. Для РМ можно поставить только обычную смену.");
    return;
  }
  const actualGrade = Number($("workplaceGradeInput").value);
  if (!validateWorkplaceGradeLimit(workDate, actualPlace, actualGrade)) return;
  if (!validateWorkplaceSpecialLimit(workDate, actualPlace, role)) return;
  const entry = {
    id: crypto.randomUUID(),
    brigade: brigadeBeforeAdd,
    date: workDate,
    name,
    tab,
    actualPlace,
    departmentId: configuredDepartmentIdForWorkplace(actualPlace, appSettings(), selectedWorkplaceDepartmentId),
    actualGrade,
    shiftKind,
    shiftCount: Number($("workplaceShiftCountInput")?.value || 1),
    hours: Number($("workplaceHoursInput").value || 0),
    role,
    ...(ordinaryExternal ? { ordinaryExternal: true } : {}),
    comment: $("workplaceCommentInput")?.value.trim() || "",
    scheduleShift: getShiftForDate(workDate).label,
    updatedAt: new Date().toISOString(),
  };
  forgetDeletedEntry(entry);
  state.entries.push(entry);
  state.entries.sort((a, b) => a.date.localeCompare(b.date) || a.name.localeCompare(b.name));

  syncAutoAbsencesForDate(workDate);
  clearWorkplaceCache();
  saveState({ sync: false });
  scheduleSupabasePushOnly();
  if (selectedPlaceBeforeAdd === "Другое место") {
    selectedWorkplace = "Другое место";
  } else if (selectedPlaceBeforeAdd === "Пролётчик" || selectedPlaceBeforeAdd === "Капитальный ремонт") {
    selectedWorkplace = actualPlace;
  } else {
    selectedWorkplace = canonicalWorkplaceKey(selectedPlaceBeforeAdd) || selectedPlaceBeforeAdd;
  }
  state.selectedShiftDate = workDate;
  workplaceEditorOpened = false;
  workplaceTapReadyToOpen = "";
  clearWorkplaceForm({ updateView: false });
  renderWorkplaces();
}

function deleteAbsence(id) {
  if (!requireStaffAdmin("удалить отсутствие")) return;
  rememberDeletedId("deletedAbsenceIds", id);
  state.absences = (state.absences || []).filter((absence) => absence.id !== id);
  saveState();
  render();
}

function deleteProletchikShift(id, options = {}) {
  if (!options.skipAdmin && !requireStaffAdmin("удалить пролётчика")) return;
  const shift = currentProletchikShifts().find((item) => item.id === id);
  rememberDeletedId("deletedProletchikShiftIds", id);
  state.proletchikShifts = (state.proletchikShifts || []).filter((shift) => shift.id !== id);
  state.entries
    .filter((entry) => entry.sourceProletchikId === id)
    .forEach((entry) => rememberDeletedEntry(entry));
  state.entries = state.entries.filter((entry) => entry.sourceProletchikId !== id);
  if (shift?.date) syncAutoAbsencesForDate(shift.date);
  saveState();
  render();
}

function deleteCapitalRepairShift(id, options = {}) {
  if (!options.skipAdmin && !requireStaffAdmin("удалить капитальный ремонт")) return;
  const shift = currentCapitalRepairShifts().find((item) => item.id === id);
  rememberDeletedId("deletedCapitalRepairShiftIds", id);
  state.capitalRepairShifts = (state.capitalRepairShifts || []).filter((shift) => shift.id !== id);
  state.entries
    .filter((entry) => entry.sourceCapitalRepairId === id)
    .forEach((entry) => rememberDeletedEntry(entry));
  state.entries = state.entries.filter((entry) => entry.sourceCapitalRepairId !== id);
  if (shift?.date) syncAutoAbsencesForDate(shift.date);
  saveState();
  render();
}

function smartDistributeCapitalRepair(options = {}) {
  const { saveAfter = true, renderAfter = true } = options;
  if (!specialRoleEnabledForDepartment("capitalRepair", DEFAULT_DEPARTMENT_ID, appSettings())) return [];
  const shifts = currentCapitalRepairShifts();
  state.entries = state.entries.filter((entry) => !belongsToCurrentBrigade(entry) || !entry.generatedCapitalRepair);

  if (!shifts.length) return [];

  const assignments = [];
  const assignedByPlace = new Map();

  for (const shift of [...shifts].sort((a, b) => a.date.localeCompare(b.date) || a.name.localeCompare(b.name, "ru"))) {
    const best = chooseBestCapitalRepairPlace(shift, assignedByPlace);
    if (!best) continue;
    assignedByPlace.set(best.place, (assignedByPlace.get(best.place) || 0) + 1);
    const entry = {
      id: crypto.randomUUID(),
      brigade: currentBrigade(),
      date: shift.date,
      name: shift.name,
      tab: shift.tab,
      actualPlace: best.place,
      actualGrade: 5,
      shiftKind: "regular",
      shiftCount: 1,
      hours: 12,
      role: "capitalRepair",
      comment: `Автораспределение капитального ремонта. ${best.explanation}${shift.comment ? `. ${shift.comment}` : ""}`,
      generatedCapitalRepair: true,
      sourceCapitalRepairId: shift.id,
    };
    state.entries.push(entry);
    assignments.push({ entry, explanation: best.explanation });
  }

  state.entries.sort((a, b) => a.date.localeCompare(b.date) || a.name.localeCompare(b.name, "ru"));
  if (saveAfter) saveState();
  if (renderAfter) render();
  return assignments;
}

function chooseBestCapitalRepairPlace(shift, assignedByPlace) {
  const candidates = FURNACES.map((code) => scoreCapitalRepairPlace(shift, `Печь ${code}`, assignedByPlace));
  const available = candidates.filter((candidate) => !candidate.blocked);
  available.sort((a, b) => a.score - b.score || a.place.localeCompare(b.place, "ru"));
  return available[0] || null;
}

function payKindCounts(entries) {
  return entries.reduce((counts, entry) => {
    const specialRole = normalizedSpecialRole(entry);
    if (entryOrdinaryShiftKind(entry, "repair")) counts.repair += Number(entry.shiftCount || 1);
    if (entryOrdinaryShiftKind(entry, "warmup")) counts.warmup += Number(entry.shiftCount || 1);
    if (specialRole === "capitalRepair") counts.capitalRepair += Number(entry.shiftCount || 1);
    if (specialRole === "proletchik") counts.proletchik += Number(entry.shiftCount || 1);
    return counts;
  }, { repair: 0, warmup: 0, capitalRepair: 0, proletchik: 0 });
}

function scoreCapitalRepairPlace(shift, place, assignedByPlace) {
  const code = placeCode(place);
  const sameDateEntries = currentEntries().filter((entry) => !entry.generatedCapitalRepair && entry.date === shift.date && placeCode(entry.actualPlace) === code);
  const people = sameDateEntries.length;
  const isEmptyFurnace = FURNACES.includes(String(code)) && people === 0;
  const payCounts = payKindCounts(sameDateEntries);
  const hasAverageShift = sameDateEntries.some(isAverageShift);
  const hasSubworker = sameDateEntries.some((entry) => classifyEntry(entry).reasons.some((reason) => reason.includes("\u043f\u043e\u0434\u0440\u0430\u0431\u043e\u0442\u0447\u0438\u043a")));
  const balance = assignedByPlace.get(place) || 0;
  const absentSameDay = currentAbsences().some((absence) => absence.date === shift.date && (absence.tab === shift.tab || normalizeName(absence.name) === normalizeName(shift.name)));
  const payBalance = placePayBalance(place, { excludeGeneratedCapitalRepair: true });
  const projectedBalanceHours = Number((payBalance.forecastProductive + balance * 12 + 12).toFixed(1));

  let score = 0;
  score += projectedBalanceHours * 10;
  score += people * 18;
  score += balance * 36;
  score += payCounts.repair * 70;
  score += payCounts.warmup * 50;
  if (hasSubworker) score += 120;
  if (absentSameDay) score += 1000;
  if (isEmptyFurnace) score += 50000;
  if (hasAverageShift) score += 50000;

  const explanation = [
    people + " \u0447\u0435\u043b. \u043d\u0430 \u043f\u0435\u0447\u0438",
    isEmptyFurnace ? "\u043f\u0435\u0447\u044c \u043d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d\u0430: \u0432 \u044d\u0442\u0443 \u0441\u043c\u0435\u043d\u0443 \u043d\u0430 \u043d\u0435\u0439 \u043d\u0438\u043a\u0442\u043e \u043d\u0435 \u0440\u0430\u0431\u043e\u0442\u0430\u043b" : "",
    hasAverageShift ? "\u043d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d\u043e: \u0432 \u044d\u0442\u0443 \u0441\u043c\u0435\u043d\u0443 \u0435\u0441\u0442\u044c \u00ab\u043f\u043e \u0441\u0440\u0435\u0434\u043d\u0435\u043c\u0443\u00bb, \u043a\u0430\u043f\u0440\u0435\u043c\u043e\u043d\u0442 \u0437\u0430\u043f\u0440\u0435\u0449\u0451\u043d" : "",
    "\u0431\u0430\u043b\u0430\u043d\u0441 \u0437\u0430\u0447\u0451\u0442\u043d\u044b\u0445 \u0447\u0430\u0441\u043e\u0432 \u043f\u0435\u0447\u0438 \u0437\u0430 \u043c\u0435\u0441\u044f\u0446: " + payBalance.forecastProductive + " \u0447",
    payBalance.lowPayLoss || payBalance.plannedLoss ? "\u043f\u043e\u0442\u0435\u0440\u0438 \u043e\u0442 \u0440\u0435\u043c\u043e\u043d\u0442\u0430/\u0440\u0430\u0437\u043e\u0433\u0440\u0435\u0432\u0430: " + Math.max(payBalance.lowPayLoss, payBalance.plannedLoss) + " \u0447" : "\u0431\u0435\u0437 \u043f\u043e\u0442\u0435\u0440\u044c \u043e\u0442 \u0440\u0435\u043c\u043e\u043d\u0442\u0430/\u0440\u0430\u0437\u043e\u0433\u0440\u0435\u0432\u0430",
    "\u043f\u043e\u0441\u043b\u0435 \u043d\u0430\u0437\u043d\u0430\u0447\u0435\u043d\u0438\u044f \u0431\u0443\u0434\u0435\u0442 \u043f\u0440\u0438\u043c\u0435\u0440\u043d\u043e " + projectedBalanceHours + " \u0437\u0430\u0447\u0451\u0442\u043d\u044b\u0445 \u0447",
    payCounts.repair ? "\u0432 \u0434\u0430\u0442\u0443 \u0443\u0436\u0435 \u0440\u0435\u043c\u043e\u043d\u0442: " + payCounts.repair : "\u0431\u0435\u0437 \u0440\u0435\u043c\u043e\u043d\u0442\u0430 \u0432 \u0434\u0430\u0442\u0443",
    payCounts.warmup ? "\u0432 \u0434\u0430\u0442\u0443 \u0443\u0436\u0435 \u0440\u0430\u0437\u043e\u0433\u0440\u0435\u0432: " + payCounts.warmup : "\u0431\u0435\u0437 \u0440\u0430\u0437\u043e\u0433\u0440\u0435\u0432\u0430 \u0432 \u0434\u0430\u0442\u0443",
    hasSubworker ? "\u0435\u0441\u0442\u044c \u043f\u043e\u0434\u0440\u0430\u0431\u043e\u0442\u0447\u0438\u043a" : "\u0431\u0435\u0437 \u043f\u043e\u0434\u0440\u0430\u0431\u043e\u0442\u0447\u0438\u043a\u043e\u0432",
    "\u043d\u0430\u0437\u043d\u0430\u0447\u0435\u043d\u0438\u0439 \u0441\u044e\u0434\u0430: " + balance,
    "\u043a\u0430\u043f\u0440\u0435\u043c\u043e\u043d\u0442 \u0440\u0430\u0441\u043f\u0440\u0435\u0434\u0435\u043b\u044f\u0435\u0442\u0441\u044f \u0442\u043e\u043b\u044c\u043a\u043e \u043f\u043e \u043f\u0435\u0447\u0430\u043c \u0438 \u043f\u043e 5 \u0440\u0430\u0437\u0440\u044f\u0434\u0443",
    "\u0446\u0435\u043b\u044c: \u0432\u044b\u0440\u0430\u0432\u043d\u044f\u0442\u044c \u043e\u0431\u0449\u0435\u0435 \u043a\u043e\u043b\u0438\u0447\u0435\u0441\u0442\u0432\u043e \u0447\u0430\u0441\u043e\u0432 \u043f\u043e \u0432\u0441\u0435\u043c \u043f\u0435\u0447\u0430\u043c",
  ].join(", ");

  return { place, score, explanation, blocked: isEmptyFurnace || hasAverageShift || absentSameDay };
}

function smartDistributeProletchik(options = {}) {
  const { silent = false, saveAfter = true, renderAfter = true, showPreview = true } = options;
  if (!specialRoleEnabledForDepartment("proletchik", DEFAULT_DEPARTMENT_ID, appSettings())) {
    if (!silent) alert(`Роль «${specialWorkLabel("proletchik", "Пролётчик")}» удалена из подразделения «Цех 7». Верните её в настройках, чтобы создавать новые назначения.`);
    return [];
  }
  const shifts = currentProletchikShifts();
  if (!shifts.length) {
    if (!silent) alert("Сначала добавь смены пролётчика.");
    return [];
  }

  state.entries = state.entries.filter((entry) => !belongsToCurrentBrigade(entry) || !entry.generatedProletchik);
  const assignments = [];
  const assignedByPlace = new Map();

  for (const shift of [...shifts].sort((a, b) => a.date.localeCompare(b.date))) {
    const best = chooseBestProletchikPlace(shift, assignedByPlace);
    if (!best) continue;
    assignedByPlace.set(best.place, (assignedByPlace.get(best.place) || 0) + 1);
    const entry = {
      id: crypto.randomUUID(),
      brigade: currentBrigade(),
      date: shift.date,
      name: shift.name,
      tab: shift.tab,
      actualPlace: best.place,
      actualGrade: best.place === "РМ" ? 3 : 5,
      shiftKind: "regular",
      shiftCount: 1,
      hours: 12,
      role: "proletchik",
      comment: `Автораспределение пролётчика. ${best.explanation}${shift.comment ? `. ${shift.comment}` : ""}`,
      generatedProletchik: true,
      sourceProletchikId: shift.id,
    };
    state.entries.push(entry);
    assignments.push({ entry, explanation: best.explanation });
  }

  state.entries.sort((a, b) => a.date.localeCompare(b.date) || a.name.localeCompare(b.name, "ru"));
  if (saveAfter) saveState();
  if (renderAfter) render();
  renderProletchikDistribution(assignments);
  if (showPreview) document.querySelector('[data-target="transferPreview"]')?.click();
  return assignments;
}

function chooseBestProletchikPlace(shift, assignedByPlace) {
  const candidates = ["Печь 41", "Печь 42", "Печь 43", "Печь 44", "Печь 45", "Печь 46", "Печь 47", "РМ"]
    .map((place) => scoreProletchikPlace(shift, place, assignedByPlace));
  const available = candidates.filter((candidate) => !candidate.blocked);
  available.sort((a, b) => a.score - b.score || a.place.localeCompare(b.place, "ru"));
  return available[0] || null;
}

function scoreProletchikPlace(shift, place, assignedByPlace) {
  const code = placeCode(place);
  const isCasting = isCastingPlaceValue(code);
  const sameDateEntries = currentEntries().filter((entry) => !entry.generatedProletchik && entry.date === shift.date && placeCode(entry.actualPlace) === code);
  const people = sameDateEntries.length;
  const payCounts = payKindCounts(sameDateEntries);
  const isEmptyFurnace = FURNACES.includes(String(code)) && people === 0;
  const isCastingOverstaffed = isCasting && people >= 8;
  const isEmptyCasting = isCasting && people === 0;
  const isCastingLimitReached = isCasting && (assignedByPlace.get(place) || 0) >= 3;
  const hasSubworker = sameDateEntries.some((entry) => classifyEntry(entry).reasons.some((reason) => reason.includes("\u043f\u043e\u0434\u0440\u0430\u0431\u043e\u0442\u0447\u0438\u043a")));
  const hasRepairOrWarmup = sameDateEntries.some((entry) => entryOrdinaryShiftKind(entry, "repair") || entryOrdinaryShiftKind(entry, "warmup"));
  const hasAverageShift = sameDateEntries.some(isAverageShift);
  const balance = assignedByPlace.get(place) || 0;
  const absentSameDay = currentAbsences().some((absence) => absence.date === shift.date && (absence.tab === shift.tab || normalizeName(absence.name) === normalizeName(shift.name)));
  const payBalance = placePayBalance(place, { excludeGeneratedProletchik: true });
  const carryoverCredit = proletchikCarryoverCredit(place);
  const projectedBalanceHours = Number((payBalance.forecastProductive + balance * 12 + 12).toFixed(1));

  let score = 0;
  score += projectedBalanceHours * 10;
  score += people * 18;
  score += balance * 36;
  score += payCounts.repair * 90;
  score += payCounts.warmup * 70;
  score += payCounts.capitalRepair * 35;
  score += carryoverCredit * 25;
  if (hasSubworker) score += 120;
  if (hasRepairOrWarmup) score += 120;
  if (absentSameDay) score += 1000;
  if (isEmptyFurnace) score += 50000;
  if (isEmptyCasting) score += 50000;
  if (isCastingOverstaffed) score += 10000;
  if (isCastingLimitReached) score += 50000;
  if (hasAverageShift) score += 50000;

  const explanation = [
    people + " \u0447\u0435\u043b. \u043d\u0430 \u043c\u0435\u0441\u0442\u0435",
    isEmptyFurnace ? "\u043f\u0435\u0447\u044c \u043d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d\u0430: \u0432 \u044d\u0442\u0443 \u0441\u043c\u0435\u043d\u0443 \u043d\u0430 \u043d\u0435\u0439 \u043d\u0438\u043a\u0442\u043e \u043d\u0435 \u0440\u0430\u0431\u043e\u0442\u0430\u043b" : "",
    isEmptyCasting ? "\u0420\u041c \u043d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d\u0430: \u043d\u0435\u0442 \u0432\u043d\u0435\u0441\u0451\u043d\u043d\u044b\u0445 \u0440\u0430\u0437\u043b\u0438\u0432\u0449\u0438\u043a\u043e\u0432" : "",
    isCastingOverstaffed ? "\u0420\u041c \u043d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d\u0430: \u0443\u0436\u0435 8 \u0440\u0430\u0437\u043b\u0438\u0432\u0449\u0438\u043a\u043e\u0432, \u0431\u0443\u0434\u0435\u0442 \u043f\u0435\u0440\u0435\u0448\u0442\u0430\u0442" : "",
    isCastingLimitReached ? "\u0420\u041c \u043d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d\u0430: \u043f\u0440\u043e\u043b\u0451\u0442\u0447\u0438\u043a \u043f\u043e \u0440\u0430\u0437\u043b\u0438\u0432\u043a\u0435 \u0443\u0436\u0435 \u0437\u0430\u043a\u0440\u044b\u0442 3 \u0441\u043c\u0435\u043d\u044b" : "",
    hasAverageShift ? "\u043d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d\u043e: \u0432 \u044d\u0442\u0443 \u0441\u043c\u0435\u043d\u0443 \u0435\u0441\u0442\u044c \u00ab\u043f\u043e \u0441\u0440\u0435\u0434\u043d\u0435\u043c\u0443\u00bb, \u043f\u0440\u043e\u043b\u0451\u0442\u0447\u0438\u043a \u0437\u0430\u043f\u0440\u0435\u0449\u0451\u043d" : "",
    "\u0431\u0430\u043b\u0430\u043d\u0441 \u0437\u0430\u0447\u0451\u0442\u043d\u044b\u0445 \u0447\u0430\u0441\u043e\u0432 \u0437\u0430 \u043c\u0435\u0441\u044f\u0446: " + payBalance.forecastProductive + " \u0447",
    payBalance.lowPayLoss || payBalance.plannedLoss ? "\u043f\u043e\u0442\u0435\u0440\u0438 \u043e\u0442 \u0440\u0435\u043c\u043e\u043d\u0442\u0430/\u0440\u0430\u0437\u043e\u0433\u0440\u0435\u0432\u0430: " + Math.max(payBalance.lowPayLoss, payBalance.plannedLoss) + " \u0447" : "\u0431\u0435\u0437 \u043f\u043e\u0442\u0435\u0440\u044c \u043e\u0442 \u0440\u0435\u043c\u043e\u043d\u0442\u0430/\u0440\u0430\u0437\u043e\u0433\u0440\u0435\u0432\u0430",
    carryoverCredit ? "\u043b\u044c\u0433\u043e\u0442\u0430 \u0441 \u043f\u0440\u043e\u0448\u043b\u043e\u0433\u043e \u043c\u0435\u0441\u044f\u0446\u0430: \u043d\u0435 \u0434\u043e\u0437\u0430\u043a\u0440\u044b\u0432\u0430\u0442\u044c \u043f\u0440\u043e\u043b\u0451\u0442\u0447\u0438\u043a\u0430 \u043d\u0430 " + carryoverCredit + " \u0447" : "",
    "\u043f\u043e\u0441\u043b\u0435 \u043d\u0430\u0437\u043d\u0430\u0447\u0435\u043d\u0438\u044f \u0431\u0443\u0434\u0435\u0442 \u043f\u0440\u0438\u043c\u0435\u0440\u043d\u043e " + projectedBalanceHours + " \u0437\u0430\u0447\u0451\u0442\u043d\u044b\u0445 \u0447",
    payCounts.repair ? "\u0432 \u0434\u0430\u0442\u0443 \u0443\u0436\u0435 \u0440\u0435\u043c\u043e\u043d\u0442: " + payCounts.repair : "\u0431\u0435\u0437 \u0440\u0435\u043c\u043e\u043d\u0442\u0430 \u0432 \u0434\u0430\u0442\u0443",
    payCounts.warmup ? "\u0432 \u0434\u0430\u0442\u0443 \u0443\u0436\u0435 \u0440\u0430\u0437\u043e\u0433\u0440\u0435\u0432: " + payCounts.warmup : "\u0431\u0435\u0437 \u0440\u0430\u0437\u043e\u0433\u0440\u0435\u0432\u0430 \u0432 \u0434\u0430\u0442\u0443",
    hasSubworker ? "\u0435\u0441\u0442\u044c \u043f\u043e\u0434\u0440\u0430\u0431\u043e\u0442\u0447\u0438\u043a" : "\u0431\u0435\u0437 \u043f\u043e\u0434\u0440\u0430\u0431\u043e\u0442\u0447\u0438\u043a\u043e\u0432",
    hasRepairOrWarmup ? "\u0432 \u0434\u0430\u0442\u0443 \u0443\u0436\u0435 \u0435\u0441\u0442\u044c \u0440\u0435\u043c\u043e\u043d\u0442/\u0440\u0430\u0437\u043e\u0433\u0440\u0435\u0432" : "\u043e\u0431\u044b\u0447\u043d\u0430\u044f \u0434\u0430\u0442\u0430",
    "\u043d\u0430\u0437\u043d\u0430\u0447\u0435\u043d\u0438\u0439 \u0441\u044e\u0434\u0430: " + balance,
    isCasting ? "\u043f\u0440\u043e\u043b\u0451\u0442\u0447\u0438\u043a \u043d\u0430 \u0420\u041c \u0437\u0430\u043a\u0440\u044b\u0432\u0430\u0435\u0442\u0441\u044f \u0442\u043e\u043b\u044c\u043a\u043e \u043f\u043e 3 \u0440\u0430\u0437\u0440\u044f\u0434\u0443 \u0438 \u043d\u0435 \u0431\u043e\u043b\u0435\u0435 3 \u0441\u043c\u0435\u043d" : "",
    "\u0446\u0435\u043b\u044c: \u0432\u044b\u0440\u0430\u0432\u043d\u044f\u0442\u044c \u043e\u0431\u0449\u0435\u0435 \u043a\u043e\u043b\u0438\u0447\u0435\u0441\u0442\u0432\u043e \u0447\u0430\u0441\u043e\u0432 \u043f\u043e \u0432\u0441\u0435\u043c \u043f\u0435\u0447\u0430\u043c",
  ].filter(Boolean).join(", ");

  return { place, score, explanation, blocked: isEmptyFurnace || isEmptyCasting || isCastingOverstaffed || isCastingLimitReached || hasAverageShift || absentSameDay };
}

function clearShiftForm(clearDate = true) {
  $("employeeInput").value = "";
  $("tabInput").value = "";
  $("actualPlaceInput").value = "Печь 41";
  refreshSpecialWorkLabels();
  $("actualGradeInput").value = "5";
  $("shiftKindInput").value = "regular";
  if ($("shiftCountInput")) $("shiftCountInput").value = "1";
  $("hoursInput").value = "12";
  $("roleInput").value = "auto";
  if ($("commentInput")) $("commentInput").value = "";
  if (clearDate) $("dateInput").value = "";
}

function setRepairPlanCount(furnace, kind, value) {
  const plans = { ...currentRepairPlans() };
  const current = plans[furnace] || { repair: 0, warmup: 0 };
  const count = Number(String(value).replace(",", "."));
  if (!Number.isFinite(count) || count < 0) {
    alert("Укажи количество смен числом.");
    renderRepairPlanGrid();
    return;
  }

  plans[furnace] = {
    repair: Number(current.repair || 0),
    warmup: Number(current.warmup || 0),
    [kind]: count,
  };
  setCurrentRepairPlans(plans);
  saveState();
  render();
}

function repairPlanCountOptions(value) {
  const current = Number(value || 0);
  const values = [];
  for (let count = 0; count <= 10; count += 0.5) values.push(count);
  if (Number.isFinite(current) && !values.includes(current)) values.push(current);
  return values
    .sort((a, b) => a - b)
    .map((count) => {
      const text = Number.isInteger(count) ? String(count) : String(count).replace(".", ",");
      return `<option value="${count}" ${count === current ? "selected" : ""}>${text}</option>`;
    })
    .join("");
}

function renderRepairPlanGrid() {
  if (!$("repairPlanGrid")) return;
  const plans = { ...currentRepairPlans() };
  $("repairPlanGrid").innerHTML = FURNACES.map((furnace) => {
    const plan = plans[furnace] || { repair: 0, warmup: 0 };
    const repair = Number(plan.repair || 0);
    const warmup = Number(plan.warmup || 0);
    const manualRows = manualRepairEntriesForFurnace(furnace);
    const disabled = manualRows.length ? "disabled" : "";
    const title = manualRows.length ? `Ремонт/разогрев по печи ${furnace} уже внесён вручную` : `Умно распределить ремонт/разогрев по печи ${furnace}`;
    return `
      <div class="repair-plan-row">
        <strong>Печь ${furnace}</strong>
        <label class="repair-plan-control">
          <span>Ремонт</span>
          <select onchange="setRepairPlanCount('${furnace}', 'repair', this.value)">
            ${repairPlanCountOptions(repair)}
          </select>
        </label>
        <label class="repair-plan-control">
          <span>Разогрев</span>
          <select onchange="setRepairPlanCount('${furnace}', 'warmup', this.value)">
            ${repairPlanCountOptions(warmup)}
          </select>
        </label>
        <button class="secondary repair-plan-smart" type="button" ${disabled} title="${escapeHtml(title)}" onclick="applySmartRepairForFurnace('${furnace}')">${manualRows.length ? "Вручную внесено" : "Умное распределение"}</button>
      </div>
    `;
  }).join("");
}

function clearMonth() {
  if (!requireStaffAdmin("очистить месяц")) return;
  if (!confirm("Очистить все записи текущего месяца в программе?")) return;
  state.entries = state.entries.filter((entry) => !belongsToCurrentBrigade(entry));
  state.absences = (state.absences || []).filter((absence) => !belongsToCurrentBrigade(absence));
  state.proletchikShifts = (state.proletchikShifts || []).filter((shift) => !belongsToCurrentBrigade(shift));
  state.capitalRepairShifts = (state.capitalRepairShifts || []).filter((shift) => !belongsToCurrentBrigade(shift));
  setCurrentRepairPlans({});
  saveState();
  render();
}

function entryMatchesDeleteFallback(entry, fallback = {}) {
  if (!fallback.date) return false;
  if (!belongsToCurrentBrigade(entry)) return false;
  if (entry.date !== fallback.date) return false;
  if (sameWorkerKey(entry.tab, entry.name) !== sameWorkerKey(fallback.tab, fallback.name)) return false;
  if (fallback.place && entry.actualPlace !== fallback.place) return false;
  return true;
}

function deleteEntry(id, fallback = {}, options = {}) {
  if (!options.skipAdmin && !requireStaffAdmin("удалить запись смены")) return;
  const targetId = String(id || "");
  const entriesToDelete = (state.entries || []).filter((entry) =>
    String(entry.id) === targetId || entryMatchesDeleteFallback(entry, fallback)
  );
  if (!entriesToDelete.length) {
    showAppMessage("Удаление", "Запись уже удалена или не найдена.");
    clearWorkplaceCache();
    renderActiveView("places");
    return;
  }
  entriesToDelete.forEach((entry) => rememberDeletedEntry(entry));
  const deletedIds = new Set(entriesToDelete.map((entry) => String(entry.id)));
  state.entries = (state.entries || []).filter((entry) => !deletedIds.has(String(entry.id)));
  clearWorkplaceCache();
  Array.from(new Set(entriesToDelete.map((entry) => entry.date).filter(Boolean)))
    .forEach((entryDate) => syncAutoAbsencesForDate(entryDate));
  saveState();
  renderActiveView(activeView);
}

function exportData() {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `табель-${state.year}-${String(Number(state.month) + 1).padStart(2, "0")}.json`;
  link.click();
  URL.revokeObjectURL(url);
}

function importData(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      state = { ...state, ...JSON.parse(reader.result) };
      saveState();
      fillStaticControls();
      render();
    } catch {
      alert("Не удалось загрузить файл копии.");
    }
  };
  reader.readAsText(file);
}

async function applyData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  await syncNow("apply");
}

function collectManualSaveInputs() {
  const phoneInputs = [...document.querySelectorAll("[data-phone-key]")];
  if (phoneInputs.length) {
    state.employeePhones = { ...(state.employeePhones || {}) };
    phoneInputs.forEach((input) => {
      const key = input.dataset.phoneKey;
      const phone = String(input.value || "").trim();
      if (!key) return;
      if (phone) {
        state.employeePhones[key] = phone;
      } else {
        delete state.employeePhones[key];
      }
    });
  }

  return true;
}

async function saveAndSyncNow() {
  if (!collectManualSaveInputs()) return;
  saveState({ sync: false });
  if (syncInProgress) {
    pendingManualSync = true;
    showStartupSyncOverlay("Сохранение данных");
    const waitProgress = startProgressTicker("Жду завершения текущей синхронизации...", 45, 80);
    const ready = await waitForSyncSlot(25000);
    stopProgressTicker(waitProgress);
    pendingManualSync = false;
    if (!ready) {
      finishStartupSyncOverlay("Данные сохранены на устройстве. Supabase занят, попробуй сохранить ещё раз.", "warning");
      return;
    }
  }
  showStartupSyncOverlay("Сохранение данных");
  const progress = startProgressTicker("Сохраняю на устройстве и отправляю в Supabase...", 94, 35);
  const synced = await syncNow("save");
  stopProgressTicker(progress);
  finishStartupSyncOverlay(
    synced
      ? "Данные сохранены и синхронизированы."
      : "Данные сохранены на устройстве. Синхронизация временно не выполнена.",
    synced ? "success" : "warning"
  );
}

async function fetchRawGithubUpdate(repo) {
  const url = `https://raw.githubusercontent.com/${repo}/main/latest.json?ts=${Date.now()}`;
  const response = await fetch(url, { cache: "no-store" });
  if (!response.ok) throw new Error(`raw latest.json: ${response.status}`);
  const text = (await response.text()).trim();
  if (!text) throw new Error("raw latest.json пустой");
  return JSON.parse(text);
}

async function fetchReleaseGithubUpdate(repo, settings) {
  const response = await fetch(`https://api.github.com/repos/${repo}/releases/latest`, {
    headers: githubHeaders(settings),
  });
  if (response.status === 404) return null;
  if (!response.ok) throw new Error(`GitHub ответил: ${response.status}`);
  const release = await response.json();
  const assets = release.assets || [];
  const apkAsset = assets.find((asset) => /\.apk$/i.test(asset.name || ""));
  const zipAsset = assets.find((asset) => /\.zip$/i.test(asset.name || ""));
  const asset = apkAsset || zipAsset;
  return {
    version: String(release.tag_name || release.name || "").replace(/^v/i, ""),
    asset,
  };
}

async function checkGithubUpdate(options = {}) {
  const silentNoUpdate = Boolean(options.silentNoUpdate);
  const autoDownload = Boolean(options.autoDownload);
  const settings = githubSettings();
  const repo = normalizeGithubRepo(settings.updateRepo || settings.repo);
  if (!repo) {
    if (!silentNoUpdate) showAppMessage("Обновление", "GitHub репозиторий обновлений не настроен.");
    return false;
  }

  try {
    let update = null;
    try {
      const raw = await fetchRawGithubUpdate(repo);
      update = {
        version: String(raw.version || "").replace(/^v/i, ""),
        asset: raw.apkUrl ? { name: raw.name || "Табель рабочих мест.apk", browser_download_url: raw.apkUrl, sha256: raw.sha256 || "" } : null,
      };
    } catch (rawError) {
      update = await fetchReleaseGithubUpdate(repo, settings);
    }

    if (!update) {
      if (!silentNoUpdate) showAppMessage("Обновление", "Новых версий пока нет.");
      return false;
    }

    const latestVersion = update.version;
    const hasNewVersion = compareVersions(latestVersion, APP_VERSION) > 0;
    if (!hasNewVersion) {
      if (!silentNoUpdate) showAppMessage("Обновление", `Обновлений нет. Текущая версия: ${APP_VERSION}. Последняя версия: ${latestVersion || "не указана"}.`);
      return false;
    }

    const asset = update.asset;
    if (!asset) {
      if (!silentNoUpdate) showAppMessage("Обновление", "Версия найдена, но APK-файл обновления не прикреплён.");
      return false;
    }

    if (autoDownload) {
      showAppMessage("Доступно обновление", `Новая версия: ${latestVersion}. Скачиваю APK и открою установщик.`);
      setTimeout(() => downloadGithubAsset(asset, settings), 500);
      return true;
    }

    showAppMessage("Доступно обновление", `Новая версия: ${latestVersion}.`, [
      { label: "Позже" },
      { label: "Скачать", primary: true, action: () => downloadGithubAsset(asset, settings) },
    ]);
    return true;
  } catch (error) {
    if (!silentNoUpdate) showAppMessage("Обновление", `Не удалось проверить обновление: ${error.message}`);
    return false;
  }
}

async function downloadGithubAsset(asset, settings) {
  try {
    if (asset.browser_download_url) {
      if (window.AndroidEmail?.installApkFromUrl) {
        window.AndroidEmail.installApkFromUrl(asset.name || "Табель рабочих мест.apk", asset.browser_download_url, "", asset.sha256 || "");
        showAppMessage("Обновление", "Скачиваю APK. После загрузки откроется установка обновления.");
        return;
      }
      window.open(asset.browser_download_url, "_blank");
      showAppMessage("Обновление", "Открылось скачивание обновления. После загрузки открой APK и установи новую версию вручную.");
      return;
    }

    showAppMessage("Обновление", "Скачиваю файл обновления...");
    const response = await fetch(asset.url, {
      headers: {
        ...githubHeaders(settings),
        Accept: "application/octet-stream",
      },
    });
    if (!response.ok) throw new Error(`GitHub ответил: ${response.status}`);
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = asset.name || "tabel-workplaces-update.apk";
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
    showAppMessage("Обновление", "Файл обновления скачан. Открой скачанный APK и установи новую версию вручную.");
  } catch (error) {
    showAppMessage("Обновление", `Не удалось скачать обновление: ${error.message}`);
  }
}
function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  let binary = "";
  for (let index = 0; index < bytes.length; index += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(index, index + chunkSize));
  }
  return btoa(binary);
}

function configureGithubSync() {
  saveGithubSettings(githubSettings());
  showAppMessage(
    "Синхронизация",
    "GitHub-синхронизация данных отключена в безопасной версии. Обновления программы остаются через публичные релизы GitHub без токена."
  );
}

function createSyncRevision() {
  const randomPart = Math.random().toString(36).slice(2, 10);
  return `${Date.now()}-${randomPart}`;
}

function appDataPayload(options = {}) {
  const cleanState = normalizeAppStateData(state);
  [
    "__localChangedAt",
    "__lastKnownRemoteUpdatedAt",
    "__lastKnownRemoteRevision",
    "__lastSyncedAt",
    "__lastSyncedDeviceId",
    "__lastSyncedFieldFingerprints",
    "__dirtySyncFields",
    "__remoteUpdatedAt",
    "__remoteRevision",
    "__remoteDeviceId",
  ].forEach((key) => delete cleanState[key]);
  return {
    version: APP_VERSION,
    updatedAt: options.updatedAt || new Date().toISOString(),
    syncRevision: options.revision || createSyncRevision(),
    parentRevision: options.parentRevision || "",
    deviceId: options.deviceId || syncDeviceId(),
    state: cleanState,
  };
}

function createSyncConflict(remoteState, attemptedRevision = "") {
  const error = new Error("Данные на сервере изменились на другом устройстве. Выполняю повторное объединение.");
  error.code = SYNC_CONFLICT_CODE;
  error.remoteState = remoteState || null;
  error.attemptedRevision = attemptedRevision;
  return error;
}

function errorText(error) {
  if (!error) return "неизвестная ошибка";
  if (typeof error === "string") return error;
  if (error.message) return error.message;
  try {
    return JSON.stringify(error);
  } catch (jsonError) {
    return String(error);
  }
}

function hasUserSyncData(source = state) {
  if (!source || typeof source !== "object") return false;
  const arrayKeys = ["entries", "absences", "vacations", "customEmployees", "proletchikShifts", "capitalRepairShifts"];
  if (arrayKeys.some((key) => Array.isArray(source[key]) && source[key].length > 0)) return true;
  if (source.employeeEdits && Object.keys(source.employeeEdits).length > 0) return true;
  if (source.employeePhones && Object.keys(source.employeePhones).length > 0) return true;
  if (source.vacationPriorities && Object.keys(source.vacationPriorities).length > 0) return true;
  if (source.vacationAllowances && Object.keys(source.vacationAllowances).length > 0) return true;
  if (source.vacationMonthLimits && Object.keys(source.vacationMonthLimits).length > 0) return true;
  if (source.vacationPolicySettings && Object.keys(source.vacationPolicySettings).length > 0) return true;
  if (source.appSettings && Object.keys(source.appSettings).length > 0) return true;
  if (source.repairPlansByBrigade && Object.keys(source.repairPlansByBrigade).length > 0) return true;
  if (source.dismissedTabsByBrigade && Object.values(source.dismissedTabsByBrigade).some((tabs) => Array.isArray(tabs) && tabs.length > 0)) return true;
  return false;
}

function normalizeSupabaseUrl(value) {
  return String(value || "").trim().replace(/\/+$/, "");
}

function supabaseSettings() {
  let stored = {};
  try {
    stored = JSON.parse(localStorage.getItem(SUPABASE_SETTINGS_KEY) || "{}");
  } catch (error) {
    stored = {};
  }
  const config = window.TABEL_SUPABASE_CONFIG || {};
  const fallbackProjectUrls = [
    ...(Array.isArray(config.fallbackProjectUrls) ? config.fallbackProjectUrls : []),
    ...(Array.isArray(stored.fallbackProjectUrls) ? stored.fallbackProjectUrls : []),
  ]
    .map(normalizeSupabaseUrl)
    .filter(Boolean);
  return {
    projectUrl: normalizeSupabaseUrl(stored.projectUrl || config.projectUrl || config.url || ""),
    fallbackProjectUrls,
    anonKey: String(stored.anonKey || config.anonKey || config.key || "").trim(),
    requireAuth: stored.requireAuth ?? config.requireAuth ?? false,
    enabled: stored.enabled ?? config.enabled ?? true,
  };
}

let activeSupabaseProjectUrl = "";

function supabaseProjectUrls(settings = supabaseSettings()) {
  const urls = [settings.projectUrl, ...(settings.fallbackProjectUrls || [])]
    .map(normalizeSupabaseUrl)
    .filter((url) => /^https?:\/\//i.test(url));
  return Array.from(new Set(urls));
}

function supabaseConfigured(settings = supabaseSettings()) {
  const url = normalizeSupabaseUrl(settings.projectUrl);
  const key = String(settings.anonKey || "").trim();
  if (settings.enabled === false) return false;
  if (!/^https?:\/\//i.test(url)) return false;
  if (key.length < 20) return false;
  if (/your-|project-url|anon-key|paste|встав/i.test(url + " " + key)) return false;
  return true;
}

function supabaseAuthSession() {
  try {
    return JSON.parse(localStorage.getItem(SUPABASE_AUTH_KEY) || "{}");
  } catch (error) {
    return {};
  }
}

function saveSupabaseAuthSession(session) {
  localStorage.setItem(SUPABASE_AUTH_KEY, JSON.stringify(session || {}));
}

function clearSupabaseAuthSession() {
  localStorage.removeItem(SUPABASE_AUTH_KEY);
}

function supabaseAuthToken() {
  const session = supabaseAuthSession();
  return String(session.access_token || "").trim();
}

async function signInSupabaseUser() {
  const settings = supabaseSettings();
  const email = prompt("Введите email пользователя Supabase для синхронизации:");
  if (email === null) return false;
  const password = prompt("Введите пароль пользователя Supabase:");
  if (password === null) return false;
  const response = await fetch(normalizeSupabaseUrl(settings.projectUrl) + "/auth/v1/token?grant_type=password", {
    method: "POST",
    headers: {
      apikey: settings.anonKey,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email: String(email).trim(), password: String(password) }),
  });
  if (!response.ok) {
    const text = await response.text().catch(() => "");
    throw new Error("Supabase Auth: " + response.status + " " + text.slice(0, 160));
  }
  const data = await response.json();
  if (!data?.access_token) throw new Error("Supabase Auth не вернул access token");
  saveSupabaseAuthSession({
    access_token: data.access_token,
    refresh_token: data.refresh_token || "",
    expires_at: Date.now() + Math.max(60, Number(data.expires_in || 3600) - 60) * 1000,
  });
  return true;
}

async function ensureSupabaseAuth() {
  const settings = supabaseSettings();
  if (!settings.requireAuth) return true;
  const session = supabaseAuthSession();
  if (session.access_token && Number(session.expires_at || 0) > Date.now()) return true;
  clearSupabaseAuthSession();
  return signInSupabaseUser();
}

function supabaseHeaders(extra = {}) {
  const settings = supabaseSettings();
  const token = supabaseAuthToken() || settings.anonKey;
  return {
    apikey: settings.anonKey,
    Authorization: "Bearer " + token,
    "Content-Type": "application/json",
    ...extra,
  };
}

function supabaseEndpointForUrl(projectUrl, table, query = "") {
  const base = normalizeSupabaseUrl(projectUrl) + "/rest/v1/" + table;
  return query ? base + "?" + query : base;
}

function supabaseEndpoint(table, query = "") {
  return supabaseEndpointForUrl(activeSupabaseProjectUrl || supabaseSettings().projectUrl, table, query);
}

async function supabaseFetch(table, query = "", options = {}) {
  const { timeoutMs = 15000, headers = {}, ...fetchOptions } = options;
  const urls = supabaseProjectUrls();
  let lastError = null;
  for (const projectUrl of urls) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort("timeout"), timeoutMs);
    let response;
    try {
      response = await fetch(supabaseEndpointForUrl(projectUrl, table, query), {
        ...fetchOptions,
        signal: controller.signal,
        headers: {
          ...supabaseHeaders(),
          ...headers,
        },
      });
      activeSupabaseProjectUrl = normalizeSupabaseUrl(projectUrl);
    } catch (error) {
      lastError = error;
      clearTimeout(timeout);
      continue;
    } finally {
      clearTimeout(timeout);
    }
    if (!response.ok) {
      const text = await response.text().catch(() => "");
      lastError = new Error("Supabase " + table + ": " + response.status + " " + text.slice(0, 180));
      continue;
    }
    if (response.status === 204) return null;
    const text = (await response.text()).trim();
    if (!text) return null;
    try {
      return JSON.parse(text);
    } catch (error) {
      throw new Error("Supabase " + table + ": пустой или повреждённый JSON");
    }
  }
  if (lastError?.name === "AbortError" || String(lastError?.message || "").toLowerCase().includes("aborted")) {
    throw new Error("Supabase долго не отвечает. Без VPN сервер может быть недоступен. Открыты локальные данные.");
  }
  throw new Error("Supabase недоступен без VPN. Проверь интернет, DNS или включи VPN.");
}

const SUPABASE_ITEM_TABLES = [
  { stateKey: "entries", table: "tabel_entries", deletedField: "deletedEntryIds" },
  { stateKey: "absences", table: "tabel_absences", deletedField: "deletedAbsenceIds" },
  { stateKey: "vacations", table: "tabel_vacations", deletedField: "deletedVacationIds" },
  { stateKey: "customEmployees", table: "tabel_custom_employees", deletedField: "deletedCustomEmployeeIds" },
  { stateKey: "proletchikShifts", table: "tabel_proletchik_shifts", deletedField: "deletedProletchikShiftIds" },
  { stateKey: "capitalRepairShifts", table: "tabel_capital_repair_shifts", deletedField: "deletedCapitalRepairShiftIds" },
];

const SUPABASE_DELETED_FIELDS = [
  "deletedEntryIds",
  "deletedProletchikShiftIds",
  "deletedCapitalRepairShiftIds",
  "deletedAbsenceIds",
  "deletedVacationIds",
  "deletedCustomEmployeeIds",
];

function stableSyncId(stateKey, item, index) {
  return [
    stateKey,
    item.brigade || "",
    item.date || item.startDate || item.month || item.year || "",
    item.endDate || "",
    item.tab || "",
    item.name || "",
    item.actualPlace || item.place || item.homePlace || "",
    item.actualGrade || item.grade || "",
    item.kind || item.role || item.reason || "",
  ].map((part) => String(part || "").trim()).join("|");
}

function ensureSupabaseIds() {
  SUPABASE_ITEM_TABLES.forEach((def) => {
    state[def.stateKey] = (state[def.stateKey] || []).map((item, index) => {
      if (item.id) return item;
      return { ...item, id: stableSyncId(def.stateKey, item, index) };
    });
  });
}

function itemToSupabaseRow(stateKey, item, index) {
  const id = item.id || stableSyncId(stateKey, item, index);
  const updatedAt = new Date().toISOString();
  return {
    id,
    brigade: String(item.brigade || ""),
    item_date: item.date || item.startDate || null,
    tab: String(item.tab || ""),
    name: String(item.name || ""),
    payload: { ...item, id, __syncedAt: item.__syncedAt || updatedAt },
    updated_at: updatedAt,
  };
}

function payloadRows(rows) {
  return (rows || []).map((row) => ({ ...(row.payload || {}), id: row.id, __syncedAt: row.updated_at || row.payload?.__syncedAt || "" }));
}

function chunkArray(items, size) {
  const chunks = [];
  for (let i = 0; i < items.length; i += size) chunks.push(items.slice(i, i + size));
  return chunks;
}

async function supabaseUpsertRows(table, rows, options = {}) {
  if (!rows.length) return;
  const { timeoutMs } = options;
  for (const chunk of chunkArray(rows, 300)) {
    await supabaseFetch(table, "on_conflict=id", {
      timeoutMs,
      method: "POST",
      headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
      body: JSON.stringify(chunk),
    });
  }
}

async function supabaseDeleteRows(table, ids, options = {}) {
  const cleanIds = [...new Set((ids || []).filter(Boolean).map(String))];
  const { timeoutMs } = options;
  for (const id of cleanIds) {
    await supabaseFetch(table, "id=eq." + encodeURIComponent(id), { timeoutMs, method: "DELETE" }).catch(() => null);
  }
}

function employeeEditRows() {
  return Object.entries(state.employeeEdits || {}).map(([key, payload]) => {
    const [brigade = "", tab = ""] = key.split(":");
    return { id: key, brigade, tab, payload, updated_at: new Date().toISOString() };
  });
}

function dismissedRows() {
  const rows = [];
  Object.entries(state.dismissedTabsByBrigade || {}).forEach(([brigade, tabs]) => {
    (tabs || []).forEach((tab) => rows.push({ id: brigade + ":" + tab, brigade, tab: String(tab), updated_at: new Date().toISOString() }));
  });
  return rows;
}

function repairPlanRows() {
  const plans = { ...(state.repairPlansByBrigade || {}) };
  if (state.repairPlans && Object.keys(state.repairPlans).length) {
    plans[currentBrigade()] = state.repairPlans;
  }
  return Object.entries(plans).map(([brigade, payload]) => ({ id: String(brigade), brigade: String(brigade), payload, updated_at: new Date().toISOString() }));
}

function deletedIdRows() {
  const rows = [];
  SUPABASE_DELETED_FIELDS.forEach((field) => {
    (state[field] || []).forEach((itemId) => rows.push({ id: field + ":" + itemId, field, item_id: String(itemId), updated_at: new Date().toISOString() }));
  });
  return rows;
}

function appMetaRow() {
  return {
    id: "state",
    payload: {
      month: state.month,
      year: state.year,
      brigade: state.brigade,
      selectedShiftDate: state.selectedShiftDate,
      selectedShiftKind: state.selectedShiftKind,
      orderNumber: state.orderNumber,
      scheduleStartDate: state.scheduleStartDate,
      vacationBrigade: state.vacationBrigade,
      vacationYear: state.vacationYear,
      vacationPriorities: state.vacationPriorities || {},
      vacationAllowances: state.vacationAllowances || {},
      vacationMonthLimits: state.vacationMonthLimits || {},
      vacationPolicySettings: state.vacationPolicySettings || {},
      employeePhones: state.employeePhones || {},
    },
    updated_at: new Date().toISOString(),
  };
}

function appFullStateRow(payload = appDataPayload()) {
  return {
    id: "full_state",
    payload,
    updated_at: payload.updatedAt || new Date().toISOString(),
  };
}

async function readSupabaseSnapshot(options = {}) {
  const rows = await supabaseFetch("tabel_app_meta", "id=eq.full_state&select=payload,updated_at&limit=1", options);
  const row = Array.isArray(rows) ? rows[0] : null;
  const payload = row?.payload || {};
  if (!payload.state || typeof payload.state !== "object") return null;
  return {
    ...payload.state,
    __remoteUpdatedAt: row.updated_at || payload.updatedAt || "",
    __remoteRevision: payload.syncRevision || "",
    __remoteDeviceId: payload.deviceId || "",
  };
}

async function writeSupabaseSnapshot(options = {}) {
  const timeoutMs = options.timeoutMs || SUPABASE_SAVE_TIMEOUT_MS;
  const expectedRevision = String(options.expectedRevision || "").trim();
  const payload = appDataPayload({
    revision: options.revision,
    parentRevision: expectedRevision,
    deviceId: options.deviceId,
    updatedAt: options.updatedAt,
  });
  let writeRows;
  if (expectedRevision) {
    const query = [
      "id=eq.full_state",
      `payload->>syncRevision=eq.${encodeURIComponent(expectedRevision)}`,
      "select=id,payload,updated_at",
    ].join("&");
    writeRows = await supabaseFetch("tabel_app_meta", query, {
      timeoutMs,
      method: "PATCH",
      headers: { Prefer: "return=representation" },
      body: JSON.stringify({ payload, updated_at: payload.updatedAt }),
    });
    if (!Array.isArray(writeRows) || writeRows.length === 0) {
      const latest = await readSupabaseSnapshot({ timeoutMs });
      if (remoteStateRevision(latest) === payload.syncRevision) {
        return {
          revision: payload.syncRevision,
          parentRevision: payload.parentRevision,
          updatedAt: latest.__remoteUpdatedAt || payload.updatedAt,
          deviceId: payload.deviceId,
        };
      }
      throw createSyncConflict(latest, payload.syncRevision);
    }
  } else {
    writeRows = await supabaseFetch("tabel_app_meta", "on_conflict=id&select=id,payload,updated_at", {
      timeoutMs,
      method: "POST",
      headers: { Prefer: "resolution=merge-duplicates,return=representation" },
      body: JSON.stringify([appFullStateRow(payload)]),
    });
  }
  const checkRows = await supabaseFetch("tabel_app_meta", "id=eq.full_state&select=id,payload,updated_at&limit=1", { timeoutMs });
  const checkRow = Array.isArray(checkRows) ? checkRows[0] : null;
  if (!checkRow?.id) throw new Error("Supabase не подтвердил запись full_state");
  if (checkRow?.payload?.syncRevision !== payload.syncRevision) {
    const latest = checkRow?.payload?.state
      ? {
        ...checkRow.payload.state,
        __remoteUpdatedAt: checkRow.updated_at || checkRow.payload.updatedAt || "",
        __remoteRevision: checkRow.payload.syncRevision || "",
        __remoteDeviceId: checkRow.payload.deviceId || "",
      }
      : null;
    throw createSyncConflict(latest, payload.syncRevision);
  }
  return {
    revision: payload.syncRevision,
    parentRevision: payload.parentRevision,
    updatedAt: checkRow.updated_at || payload.updatedAt,
    deviceId: payload.deviceId,
  };
}

async function readSupabaseRows(table, query = "select=*", options = {}) {
  try {
    return await supabaseFetch(table, query, options);
  } catch (error) {
    console.warn("Supabase table read failed", table, error);
    if (options.optional) return [];
    throw error;
  }
}

async function readSupabaseState(options = {}) {
  const snapshot = await readSupabaseSnapshot(options);
  if (snapshot) return snapshot;
  if (options.useLegacyTables !== true) return { __serverEmpty: true };
  const timeoutMs = options.timeoutMs || 15000;
  const itemReadsPromise = Promise.all(SUPABASE_ITEM_TABLES.map((def) => readSupabaseRows(def.table, "select=*", { timeoutMs })));
  const extraReadsPromise = Promise.all([
    readSupabaseRows("tabel_employee_edits", "select=*", { timeoutMs }),
    readSupabaseRows("tabel_dismissed_tabs", "select=*", { timeoutMs }),
    readSupabaseRows("tabel_repair_plans", "select=*", { timeoutMs }),
    readSupabaseRows("tabel_deleted_ids", "select=*", { timeoutMs }),
    readSupabaseRows("tabel_app_meta", "select=*", { timeoutMs }),
  ]);
  const [itemReads, extraReads] = await Promise.all([itemReadsPromise, extraReadsPromise]);
  const [employeeEditsRows, dismissedTabsRows, repairPlansRows, deletedRows, metaRows] = extraReads;
  const remote = {};
  SUPABASE_ITEM_TABLES.forEach((def, index) => {
    remote[def.stateKey] = payloadRows(itemReads[index]);
  });
  remote.employeeEdits = {};
  (employeeEditsRows || []).forEach((row) => {
    remote.employeeEdits[row.id] = row.payload || {};
  });
  remote.dismissedTabsByBrigade = {};
  (dismissedTabsRows || []).forEach((row) => {
    const brigade = String(row.brigade || "");
    if (!remote.dismissedTabsByBrigade[brigade]) remote.dismissedTabsByBrigade[brigade] = [];
    remote.dismissedTabsByBrigade[brigade].push(String(row.tab || ""));
  });
  remote.repairPlansByBrigade = {};
  (repairPlansRows || []).forEach((row) => {
    remote.repairPlansByBrigade[String(row.brigade || row.id)] = row.payload || {};
  });
  SUPABASE_DELETED_FIELDS.forEach((field) => {
    remote[field] = [];
  });
  (deletedRows || []).forEach((row) => {
    const field = row.field;
    if (field && SUPABASE_DELETED_FIELDS.includes(field)) remote[field].push(String(row.item_id || ""));
  });
  const meta = (metaRows || []).find((row) => row.id === "state");
  if (meta && meta.payload) Object.assign(remote, meta.payload);
  return remote;
}

function timeoutAfter(ms, message) {
  return new Promise((_, reject) => {
    setTimeout(() => reject(new Error(message)), ms);
  });
}

function withTimeout(promise, ms, message) {
  return Promise.race([promise, timeoutAfter(ms, message)]);
}

async function retrySupabaseOperation(operation, {
  attempts = 3,
  delayMs = 1200,
  onRetry = null,
} = {}) {
  let lastError = null;
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    try {
      return await operation(attempt);
    } catch (error) {
      lastError = error;
      if (error?.code === SYNC_CONFLICT_CODE) throw error;
      if (attempt >= attempts) break;
      if (typeof onRetry === "function") onRetry(attempt, error);
      await sleep(delayMs * attempt);
    }
  }
  throw lastError;
}

function readSupabaseStateReliable(options = {}) {
  const timeoutMs = options.timeoutMs || 15000;
  return retrySupabaseOperation(
    () => withTimeout(
      readSupabaseState({ timeoutMs }),
      timeoutMs + 1000,
      "Supabase долго не отвечает. Данные сохранены только на этом устройстве."
    ),
    options
  );
}

function writeSupabaseStateReliable(options = {}) {
  const timeoutMs = options.timeoutMs || 15000;
  const revision = options.revision || createSyncRevision();
  return retrySupabaseOperation(
    () => withTimeout(
      writeSupabaseState({ ...options, timeoutMs, revision }),
      timeoutMs + 1200,
      "Supabase долго не подтверждает сохранение. Данные сохранены только на этом устройстве."
    ),
    options
  );
}

async function writeSupabaseState(options = {}) {
  const timeoutMs = options.timeoutMs || SUPABASE_SAVE_TIMEOUT_MS;
  state = normalizeAppStateData(state);
  ensureSupabaseIds();
  const confirmation = await writeSupabaseSnapshot({ ...options, timeoutMs });
  if (window.TABEL_SUPABASE_LEGACY_TABLE_SYNC !== true) return confirmation;
  await Promise.all(SUPABASE_ITEM_TABLES.map((def) => supabaseDeleteRows(def.table, state[def.deletedField] || [], { timeoutMs })));
  await Promise.all(SUPABASE_ITEM_TABLES.map((def) => {
    const rows = (state[def.stateKey] || []).map((item, index) => itemToSupabaseRow(def.stateKey, item, index));
    return supabaseUpsertRows(def.table, rows, { timeoutMs });
  }));
  await Promise.all([
    supabaseUpsertRows("tabel_employee_edits", employeeEditRows(), { timeoutMs }),
    supabaseUpsertRows("tabel_dismissed_tabs", dismissedRows(), { timeoutMs }),
    supabaseUpsertRows("tabel_repair_plans", repairPlanRows(), { timeoutMs }),
    supabaseUpsertRows("tabel_deleted_ids", deletedIdRows(), { timeoutMs }),
    supabaseUpsertRows("tabel_app_meta", [appMetaRow()], { timeoutMs }),
  ]);
  return confirmation;
}

function showSupabaseNotConfigured(mode) {
  if (mode === "auto") return;
  showAppMessage("Синхронизация", "Supabase не настроен. Данные сохранены только на этом устройстве.");
}

async function syncNow(mode = "manual") {
  saveState({ sync: false, fromSync: true });
  if (devicePreferences.serverStorageEnabled === false) {
    setSaveStatus(
      devicePreferences.localStorageEnabled === false ? "pending" : "local",
      devicePreferences.localStorageEnabled === false ? "Хранение отключено · данные только в текущем сеансе" : "Сохранено на этом устройстве · сервер отключён"
    );
    if (mode !== "auto") showAppMessage("Сохранено", "Данные сохранены на этом устройстве. Сохранение на сервер отключено в настройках.");
    return true;
  }
  const settings = supabaseSettings();
  if (!supabaseConfigured(settings)) {
    showSupabaseNotConfigured(mode);
    return false;
  }
  if (!navigator.onLine) {
    if (mode !== "auto") showAppMessage("Синхронизация", "Нет интернета. Данные сохранены на устройстве, сервер не обновлён.");
    return false;
  }
  if (syncInProgress) return false;
  syncInProgress = true;
  syncMuted = true;
  const selection = {
    selectedShiftDate: state.selectedShiftDate,
    selectedShiftKind: state.selectedShiftKind,
    brigade: state.brigade,
  };
  try {
    const authReady = await ensureSupabaseAuth();
    if (!authReady) {
      if (mode !== "auto" && mode !== "save") showAppMessage("Синхронизация", "Вход в Supabase отменён. Данные сохранены только на устройстве.");
      return false;
    }
    let remoteState = await readSupabaseStateReliable({ timeoutMs: SUPABASE_SAVE_TIMEOUT_MS, attempts: 2 });
    if (remoteState?.__serverEmpty) {
      if (!hasUserSyncData(state)) {
        if (mode !== "auto") showAppMessage("Синхронизация", "На сервере пока нет данных. Откройте приложение на устройстве, где заполнены рабочие места, чтобы выгрузить базу.");
        return false;
      }
      const confirmation = await writeSupabaseStateReliable({
        timeoutMs: SUPABASE_SAVE_TIMEOUT_MS,
        attempts: 2,
        expectedRevision: "",
      });
      applyConfirmedSyncMeta(confirmation);
      if (mode !== "auto") showAppMessage("Синхронизация", "Сервер был пустой. Данные этого устройства отправлены в Supabase.");
      return true;
    }

    for (let conflictAttempt = 1; conflictAttempt <= 3; conflictAttempt += 1) {
      acceptRemoteState(remoteState, mode);
      restoreShiftSelection(selection);
      saveState({ sync: false, fromSync: true });
      try {
        const confirmation = await writeSupabaseStateReliable({
          timeoutMs: SUPABASE_SAVE_TIMEOUT_MS,
          attempts: 2,
          expectedRevision: remoteStateRevision(remoteState),
        });
        applyConfirmedSyncMeta(confirmation);
        fillStaticControls();
        render();
        if (mode !== "auto" && mode !== "save") {
          showAppMessage(
            mode === "apply" ? "Сохранено" : "Синхронизация",
            `Данные сохранены и синхронизированы. Ревизия ${shortSyncRevision(confirmation.revision)}.`
          );
        }
        return true;
      } catch (error) {
        if (error?.code !== SYNC_CONFLICT_CODE || conflictAttempt >= 3) throw error;
        updateStartupSyncOverlay(
          72 + conflictAttempt * 6,
          `На другом устройстве появились изменения. Объединяю данные, попытка ${conflictAttempt + 1}...`
        );
        remoteState = error.remoteState
          || await readSupabaseStateReliable({ timeoutMs: SUPABASE_SAVE_TIMEOUT_MS, attempts: 2 });
      }
    }
    return false;
  } catch (error) {
    if (mode !== "auto" && mode !== "save") showAppMessage("Синхронизация", "Данные сохранены на устройстве, но Supabase не обновлён: " + errorText(error));
    return false;
  } finally {
    syncMuted = false;
    syncInProgress = false;
  }
}

function restoreShiftSelection(selection) {
  if (!selection) return;
  if (selection.selectedShiftDate) state.selectedShiftDate = selection.selectedShiftDate;
  if (selection.selectedShiftKind) state.selectedShiftKind = selection.selectedShiftKind;
  if (selection.brigade) state.brigade = selection.brigade;
}

async function syncWithSupabaseSilently() {
  return;
  const settings = supabaseSettings();
  if (!supabaseConfigured(settings) || !navigator.onLine || syncInProgress) return;
  syncInProgress = true;
  syncMuted = true;
  const selection = {
    selectedShiftDate: state.selectedShiftDate,
    selectedShiftKind: state.selectedShiftKind,
    brigade: state.brigade,
  };
  try {
    const remoteState = await readSupabaseStateReliable({ timeoutMs: SUPABASE_BACKGROUND_TIMEOUT_MS, attempts: 1 });
    if (remoteState?.__serverEmpty) {
      if (!hasUserSyncData(state)) return;
      await writeSupabaseStateReliable({ timeoutMs: SUPABASE_BACKGROUND_TIMEOUT_MS, attempts: 1 });
      return;
    }
    acceptRemoteState(remoteState, "auto");
    restoreShiftSelection(selection);
    saveState({ sync: false, fromSync: true });
    await writeSupabaseStateReliable({ timeoutMs: SUPABASE_BACKGROUND_TIMEOUT_MS, attempts: 1 });
    render();
  } catch (error) {
    console.warn("Supabase auto sync failed", error);
  } finally {
    syncMuted = false;
    syncInProgress = false;
  }
}

async function loadGithubDataOnStart() {
  if (devicePreferences.serverStorageEnabled === false || devicePreferences.startupSyncEnabled === false) {
    checkGithubUpdate({ silentNoUpdate: true, autoDownload: true }).catch(() => null);
    return;
  }
  const settings = supabaseSettings();
  if (!supabaseConfigured(settings)) {
    checkGithubUpdate({ silentNoUpdate: true, autoDownload: true }).catch(() => null);
    return;
  }
  if (!navigator.onLine) {
    checkGithubUpdate({ silentNoUpdate: true, autoDownload: true }).catch(() => null);
    return;
  }
  if (syncInProgress) return;
  syncInProgress = true;
  syncMuted = true;
  showStartupSyncOverlay("Синхронизация данных");
  const progress = startProgressTicker("Читаю данные Supabase...", 88, 45);
  const selection = {
    selectedShiftDate: state.selectedShiftDate,
    selectedShiftKind: state.selectedShiftKind,
    brigade: state.brigade,
  };
  checkGithubUpdate({ silentNoUpdate: true, autoDownload: true }).catch(() => null);
  try {
    const remoteState = await readSupabaseStateReliable({
      timeoutMs: SUPABASE_STARTUP_TIMEOUT_MS,
      attempts: 1,
      onRetry: (attempt) => updateStartupSyncOverlay(28 + attempt * 14, `Supabase отвечает медленно. Повтор ${attempt + 1}...`),
    });
    const serverWasEmpty = Boolean(remoteState?.__serverEmpty);
    if (serverWasEmpty) {
      if (!hasUserSyncData(state)) {
        stopProgressTicker(progress);
        finishStartupSyncOverlay("На сервере пока нет данных. Открыты локальные данные.", "warning");
        return;
      }
      updateStartupSyncOverlay(90, "Отправляю локальные данные на сервер...");
      const confirmation = await writeSupabaseStateReliable({
        timeoutMs: SUPABASE_SAVE_TIMEOUT_MS,
        attempts: 2,
        expectedRevision: "",
        onRetry: (attempt) => updateStartupSyncOverlay(88, `Повтор сохранения ${attempt + 1}...`),
      });
      applyConfirmedSyncMeta(confirmation);
      stopProgressTicker(progress);
      finishStartupSyncOverlay(`Данные отправлены в Supabase. Ревизия ${shortSyncRevision(confirmation.revision)}.`, "success");
      return;
    }
    updateStartupSyncOverlay(72, "Обновляю локальные данные...");
    acceptRemoteState(remoteState, "startup");
    restoreShiftSelection(selection);
    syncStateToCurrentMonth();
    saveState({ sync: false, fromSync: true });
    fillStaticControls();
    renderStartScheduleCalendar();
    if (document.body.classList.contains("app-locked")) {
      const dashboard = document.querySelector(".start-dashboard");
      if (dashboard?.classList.contains("show-staff")) renderGlobalStaff();
      if (dashboard?.classList.contains("show-vacation")) renderVacations();
      if (dashboard?.classList.contains("show-phones")) renderPhoneNumbers();
    } else {
      render();
    }
    stopProgressTicker(progress);
    finishStartupSyncOverlay(
      `Данные загружены. Ревизия ${shortSyncRevision(state.__lastKnownRemoteRevision) || "подтверждена"}.`,
      "success"
    );
    setTimeout(() => syncWithSupabaseSilently(), 2500);
  } catch (error) {
    stopProgressTicker(progress);
    saveState({ sync: false });
    console.warn("Startup Supabase sync failed", error);
    finishStartupSyncOverlay("Синхронизация временно не выполнена. Открыты локальные данные.", "warning");
    dismissStartupSyncOverlay(1200);
    setTimeout(() => syncWithSupabaseSilently(), 4500);
    setTimeout(() => syncWithSupabaseSilently(), 15000);
    setTimeout(() => syncWithSupabaseSilently(), 40000);
  } finally {
    syncMuted = false;
    syncInProgress = false;
  }
}

function scheduleSupabaseSync() {
  // Ручной режим: синхронизация запускается только кнопкой "Сохранить".
}

function requestBackgroundSupabaseRefresh(force = false) {
  return;
  if (!supabaseConfigured() || !navigator.onLine || syncInProgress) return;
  if (document.hidden && !force) return;
  const now = Date.now();
  if (!force && now - lastBackgroundSyncAt < 12000) return;
  lastBackgroundSyncAt = now;
  syncWithSupabaseSilently();
}

function startPeriodicSupabaseRefresh() {
  if (periodicSyncTimer) clearInterval(periodicSyncTimer);
  periodicSyncTimer = null;
}

function scheduleSupabasePushOnly() {
  // Ручной режим: после добавления/удаления данные сохраняются локально,
  // а в Supabase отправляются только кнопкой "Сохранить".
}

function render() {
  renderStaff();
  renderGlobalStaff();
  renderPhoneNumbers();
  renderVacations();
  renderWorkplaces();
  renderAbsences();
  renderProletchikShifts();
  renderAbsentToday();
  renderSummary();
  renderStats();
  renderEntries();
  renderTransferPreview();
  renderRepairPreview();
  renderMeetingPreview();
  renderVacationPrintPreview();
  renderCalendar();
  if (activeView === "settings") renderAppSettings();
}

function renderGlobalStaff() {
  if (!$("globalStaffTable")) return;
  renderGlobalStaffHierarchyFilters();
  renderGlobalStaffPositionFilter();
  const selectedBrigade = $("globalStaffFilterBrigade")?.value || "";
  const selectedWorkplaceGroup = $("globalStaffFilterPlace")?.value || "";
  const selectedGrade = $("globalStaffFilterGrade")?.value || "";
  const selectedPosition = $("globalStaffFilterPosition")?.value || "";
  const employees = activeUnifiedEmployees()
    .filter((employee) => globalStaffPlaceInPrimaryDepartment(employee.place))
    .filter((employee) => !selectedBrigade || itemBrigade(employee) === selectedBrigade)
    .filter((employee) => !selectedWorkplaceGroup || globalStaffWorkplaceGroup(employee.place) === selectedWorkplaceGroup)
    .filter((employee) => !selectedGrade || String(employee.grade) === selectedGrade)
    .filter((employee) => !selectedPosition || employeePositionValue(employee) === selectedPosition)
    .sort((a, b) => itemBrigade(a).localeCompare(itemBrigade(b), "ru") || compareEmployeeWorkplaceGrade(a, b));
  const rows = employees.map((employee, index) => {
    const rowBrigade = itemBrigade(employee);
    const status = shiftStatusForEmployee(employee);
    const position = employeePositionLabel(employee);
    const actions = `
        <button type="button" class="secondary" onclick="editGlobalEmployeeGrade('${employee.tab}', '${rowBrigade}')">Редактировать</button>
        <button type="button" class="danger" onclick="dismissGlobalEmployee('${employee.tab}', '${rowBrigade}')">Уволить</button>
      `;
    return `
      <tr>
        <td>${index + 1}</td>
        <td>Бригада ${escapeHtml(itemBrigade(employee))}</td>
        <td>${escapeHtml(employee.tab)}</td>
        <td class="global-staff-name-cell">
          ${escapeHtml(employee.name)}
        </td>
        <td class="global-staff-position">${escapeHtml(position)}</td>
        <td>${escapeHtml(employee.place)}</td>
        <td>${employee.grade}</td>
        <td><span class="badge ${status.className}">${escapeHtml(status.label)}</span></td>
        <td class="staff-actions">${actions}</td>
      </tr>
    `;
  });
  $("globalStaffTable").querySelector("tbody").innerHTML = rows.length
    ? rows.join("")
    : `<tr><td colspan="9" class="empty-cell">По выбранным фильтрам сотрудников пока нет.</td></tr>`;
}

function renderGlobalStaffPositionFilter() {
  const select = $("globalStaffFilterPosition");
  if (!select) return;
  const previous = String(select.value || "");
  const positions = configuredEmployeePositions();
  select.innerHTML = `<option value="">Все</option>${positions.map((position) => (
    `<option value="${escapeHtml(position)}">${escapeHtml(position)}</option>`
  )).join("")}`;
  select.value = positions.includes(previous) ? previous : "";
}

function handleGlobalStaffPositionFilterChange(event) {
  const select = event?.currentTarget || $("globalStaffFilterPosition");
  if (String(select?.value || "") !== GLOBAL_STAFF_ADD_POSITION_ACTION) {
    if (String(select?.value || "") === GLOBAL_STAFF_DELETE_POSITION_ACTION) {
      select.value = "";
      renderGlobalStaffPositionDeleteOptions();
      toggleGlobalStaffPositionDelete(true);
      toggleGlobalStaffWorkplaceDelete(false);
      renderGlobalStaff();
      requestAnimationFrame(() => $("globalStaffPositionDeleteSelect")?.focus({ preventScroll: true }));
      return;
    }
    renderGlobalStaff();
    return;
  }
  select.value = "";
  const panel = $("globalStaffPositionCreatePanel");
  if (panel) panel.hidden = false;
  toggleGlobalStaffPositionDelete(false);
  toggleGlobalStaffWorkplaceDelete(false);
  renderGlobalStaff();
  requestAnimationFrame(() => $("globalStaffPositionNameInput")?.focus({ preventScroll: true }));
}

function toggleGlobalStaffPositionCreate(forceOpen) {
  const panel = $("globalStaffPositionCreatePanel");
  if (!panel) return;
  panel.hidden = typeof forceOpen === "boolean" ? !forceOpen : !panel.hidden;
  if (!panel.hidden) requestAnimationFrame(() => $("globalStaffPositionNameInput")?.focus({ preventScroll: true }));
}

function addGlobalStaffPosition(event) {
  event.preventDefault();
  const name = String($("globalStaffPositionNameInput")?.value || "").replace(/\s+/g, " ").trim().slice(0, 120);
  if (!name) {
    showAppMessage("Новая должность", "Введите название должности.");
    return;
  }
  if (configuredEmployeePositions().some((position) => normalizeName(position) === normalizeName(name))) {
    showAppMessage("Новая должность", "Такая должность уже существует.");
    return;
  }
  if (!requireStaffAdmin("создать новую должность")) return;
  const settings = appSettings();
  const hiddenStaffPositions = (settings.hiddenStaffPositions || [])
    .filter((position) => normalizeName(position) !== normalizeName(name));
  state.appSettings = {
    ...settings,
    staffPositions: [...configuredEmployeePositions(settings), name],
    hiddenStaffPositions,
  };
  saveState();
  const panel = $("globalStaffPositionCreatePanel");
  if (panel) panel.hidden = true;
  toggleGlobalStaffPositionDelete(false);
  toggleGlobalStaffWorkplaceDelete(false);
  if ($("globalStaffPositionNameInput")) $("globalStaffPositionNameInput").value = "";
  renderGlobalStaff();
  showAppMessage("Должность создана", `«${name}» добавлена в список должностей.`);
}

function renderGlobalStaffWorkplaceDeleteOptions() {
  const select = $("globalStaffWorkplaceDeleteSelect");
  if (!select) return;
  const places = settingsWorkplaceRows()
    .map((item) => item?.name)
    .filter((name) => name && name !== "Другое место");
  select.innerHTML = `<option value="">Выберите рабочее место</option>${places.map((place) => (
    `<option value="${escapeHtml(place)}">${escapeHtml(place)}</option>`
  )).join("")}`;
  select.disabled = !places.length;
}

function toggleGlobalStaffWorkplaceDelete(forceOpen) {
  const panel = $("globalStaffWorkplaceDeletePanel");
  if (!panel) return;
  panel.hidden = typeof forceOpen === "boolean" ? !forceOpen : !panel.hidden;
  if (!panel.hidden) renderGlobalStaffWorkplaceDeleteOptions();
}

function renderGlobalStaffPositionDeleteOptions() {
  const select = $("globalStaffPositionDeleteSelect");
  if (!select) return;
  const settings = appSettings();
  const positions = configuredEmployeePositions(settings);
  const specialRoles = specialRoleDefinitions(settings, { includeArchived: true })
    .filter((role) => role.builtIn || specialRoleEnabledForDepartment(role.id, DEFAULT_DEPARTMENT_ID, settings));
  select.innerHTML = `<option value="">Выберите должность или специальную работу</option>${positions.map((position) => (
    `<option value="${escapeHtml(position)}">${escapeHtml(position)}</option>`
  )).join("")}${specialRoles.map((role) => (
    `<option value="${GLOBAL_STAFF_DELETE_SPECIAL_ROLE_PREFIX}${escapeHtml(role.id)}">${escapeHtml(role.name)}</option>`
  )).join("")}`;
  select.disabled = !(positions.length || specialRoles.length);
}

function toggleGlobalStaffPositionDelete(forceOpen) {
  const panel = $("globalStaffPositionDeletePanel");
  if (!panel) return;
  panel.hidden = typeof forceOpen === "boolean" ? !forceOpen : !panel.hidden;
  if (!panel.hidden) renderGlobalStaffPositionDeleteOptions();
}

function deleteGlobalStaffWorkplace(event) {
  event.preventDefault();
  const name = String($("globalStaffWorkplaceDeleteSelect")?.value || "").trim();
  if (!name) {
    showAppMessage("Удаление рабочего места", "Выберите рабочее место.");
    return;
  }
  if (deleteConfiguredWorkplace(name)) {
    if ($("globalStaffWorkplaceDeletePanel")) $("globalStaffWorkplaceDeletePanel").hidden = true;
    renderGlobalStaff();
  }
}

function deleteGlobalStaffPosition(event) {
  event.preventDefault();
  const name = String($("globalStaffPositionDeleteSelect")?.value || "").trim();
  if (!name) {
    showAppMessage("Удаление должности", "Выберите должность.");
    return;
  }
  const specialRoleId = name.startsWith(GLOBAL_STAFF_DELETE_SPECIAL_ROLE_PREFIX)
    ? name.slice(GLOBAL_STAFF_DELETE_SPECIAL_ROLE_PREFIX.length)
    : "";
  if (specialRoleId) {
    const settings = appSettings();
    const role = specialRoleDefinition(specialRoleId, settings, { includeArchived: true });
    if (!role) {
      showAppMessage("Удаление специальной работы", "Специальная работа не найдена.");
      return;
    }
    if (!requireStaffAdmin(`удалить специальную работу ${role.name}`)) return;
    if (!window.confirm(`Удалить «${role.name}» из Цеха 7? История смен и статистика сохранятся.`)) return;
    state.appSettings = settingsWithDepartmentSpecialRoleEnabled(settings, DEFAULT_DEPARTMENT_ID, role.id, false);
    saveState();
    if ($("globalStaffPositionDeletePanel")) $("globalStaffPositionDeletePanel").hidden = true;
    renderGlobalStaff();
    showAppMessage("Специальная работа удалена", `«${role.name}» больше не предлагается для новых назначений в Цехе 7.`);
    return;
  }
  if (!requireStaffAdmin(`удалить должность ${name}`)) return;
  if (!window.confirm(`Удалить должность «${name}»? Существующие сотрудники и история сохранятся.`)) return;
  const settings = appSettings();
  const isBuiltIn = EMPLOYEE_POSITION_OPTIONS.includes(name);
  const staffPositions = isBuiltIn
    ? settings.staffPositions
    : (settings.staffPositions || []).filter((position) => normalizeName(position) !== normalizeName(name));
  const hiddenStaffPositions = new Set(settings.hiddenStaffPositions || []);
  if (isBuiltIn) hiddenStaffPositions.add(name);
  state.appSettings = { ...settings, staffPositions, hiddenStaffPositions: [...hiddenStaffPositions] };
  saveState();
  if ($("globalStaffPositionDeletePanel")) $("globalStaffPositionDeletePanel").hidden = true;
  renderGlobalStaff();
  showAppMessage("Должность удалена", `«${name}» удалена из списка доступных должностей.`);
}

function globalStaffWorkplaceGroup(place) {
  const key = canonicalWorkplaceKey(place);
  if (/^Печь\s+\d+$/i.test(key)) return "furnaces";
  if (key === "РМ") return "casting";
  const configured = settingsWorkplaceRows().find((workplace) => (
    normalizeName(canonicalWorkplaceKey(workplace.name)) === normalizeName(key)
  ));
  if (configured?.sectionId === "section-furnace-bay") return "furnaces";
  if (configured?.sectionId === "section-casting-bay") return "casting";
  return "other";
}

function employeeWorkplaceOptions() {
  const excluded = new Set(["Другое место", "Цех 2", "Цех 5", "РСЦ"].map(normalizeName));
  return PLACES.filter((place) => !excluded.has(normalizeName(place)));
}

function employeeExistingWorkplaceOptions(currentPlace = "") {
  return Array.from(new Set([...PLACES, String(currentPlace || "").trim()].filter(Boolean)));
}

function normalizeEmployeePosition(value, place = "") {
  const explicit = String(value || "").replace(/\s+/g, " ").trim().slice(0, 120);
  if (explicit) return explicit;
  const group = globalStaffWorkplaceGroup(place);
  if (group === "furnaces") return EMPLOYEE_POSITION_OPTIONS[0];
  if (group === "casting") return EMPLOYEE_POSITION_OPTIONS[1];
  return "";
}

function employeePositionValue(employee = {}) {
  return normalizeEmployeePosition(employee.position, employee.place);
}

function employeePositionLabel(employee = {}) {
  return employeePositionValue(employee) || "Должность не указана";
}

function configuredEmployeePositions(settings = appSettings()) {
  return [...EMPLOYEE_POSITION_OPTIONS];
}

function employeePositionOptionsHtml(selectedValue = "") {
  const selected = String(selectedValue || "").trim();
  const values = configuredEmployeePositions();
  return `<option value="">Выбрать должность</option>${values.map((value) => (
    `<option value="${escapeHtml(value)}" ${value === selected ? "selected" : ""}>${escapeHtml(value)}</option>`
  )).join("")}`;
}

function bindEmployeePositionSuggestion(placeSelect, positionSelect) {
  if (!placeSelect || !positionSelect) return;
  let suggested = normalizeEmployeePosition("", placeSelect.value);
  if (!positionSelect.value && suggested) positionSelect.value = suggested;
  placeSelect.addEventListener("change", () => {
    const nextSuggested = normalizeEmployeePosition("", placeSelect.value);
    if (!positionSelect.value || positionSelect.value === suggested) positionSelect.value = nextSuggested;
    suggested = nextSuggested;
  });
}

function employeeRoleForPlace(place) {
  return globalStaffWorkplaceGroup(place) === "casting" ? "caster" : "melter";
}

function employeeSectionForPlace(place) {
  return employeeRoleForPlace(place) === "caster" ? "Машинисты разливочных машин" : "Плавильный участок";
}

function globalStaffPlaceInPrimaryDepartment(place) {
  const key = normalizeName(canonicalWorkplaceKey(place));
  const settings = appSettings();
  const workplace = settingsWorkplaceRows(settings).find((item) => (
    normalizeName(canonicalWorkplaceKey(item.name)) === key
  ));
  if (workplace) return workplace.departmentId === DEFAULT_DEPARTMENT_ID;
  const department = (settings.departments || []).find((item) => (
    normalizeName(canonicalWorkplaceKey(item.name)) === key
  ));
  return !department || department.id === DEFAULT_DEPARTMENT_ID;
}

function globalStaffPosition(place, position = "") {
  return normalizeEmployeePosition(position, place) || "Должность не указана";
}

function employeePhoneKey(employee) {
  return `${itemBrigade(employee)}:${employee.tab || normalizeName(employee.name)}`;
}

function renderPhoneNumbers() {
  if (!$("phoneTable")) return;
  const hierarchy = renderHierarchyWorkplaceFilters("phoneFilterDepartment", "phoneFilterSection", "phoneFilterPlace");
  const selectedPlace = $("phoneFilterPlace")?.value || "";
  const selectedBrigade = $("phoneFilterBrigade")?.value || "";
  const search = normalizeName($("phoneSearchInput")?.value || "");
  const employees = activeUnifiedEmployees()
    .filter((employee) => workplaceMatchesHierarchy(employee.place, hierarchy.departmentId, hierarchy.sectionId))
    .filter((employee) => !selectedPlace || employee.place === selectedPlace)
    .filter((employee) => !selectedBrigade || itemBrigade(employee) === selectedBrigade)
    .filter((employee) => !search || normalizeName(employee.name).includes(search) || String(employee.tab || "").includes(search))
    .sort((a, b) => itemBrigade(a).localeCompare(itemBrigade(b), "ru") || compareEmployeeWorkplaceGrade(a, b));
  const phones = state.employeePhones || {};
  const rows = employees.map((employee) => {
    const key = employeePhoneKey(employee);
    const phone = phones[key] || "";
    return `
      <tr>
        <td>Бр. ${escapeHtml(itemBrigade(employee))}</td>
        <td>${escapeHtml(employee.tab)}</td>
        <td>${escapeHtml(employee.name)}</td>
        <td><input type="tel" value="${escapeHtml(phone)}" data-phone-key="${escapeHtml(key)}" placeholder="+7..." /></td>
        <td class="phone-actions">
          <button type="button" class="phone-call-button" onclick="callEmployeePhone('${escapeJs(key)}')">Вызов</button>
          <button type="button" class="danger" onclick="deleteEmployeePhone('${escapeJs(key)}')">Удалить</button>
        </td>
      </tr>
    `;
  });
  $("phoneTable").querySelector("tbody").innerHTML = rows.length
    ? rows.join("")
    : `<tr><td colspan="5" class="empty-cell">Сотрудники не найдены.</td></tr>`;
}

function phoneInputForKey(key) {
  return [...document.querySelectorAll("[data-phone-key]")]
    .find((input) => input.dataset.phoneKey === key);
}

function saveEmployeePhone(key) {
  const input = phoneInputForKey(key);
  if (!input) return;
  const phone = input.value.trim();
  state.employeePhones = { ...(state.employeePhones || {}) };
  if (phone) {
    state.employeePhones[key] = phone;
  } else {
    state.employeePhones[key] = null;
  }
  saveState();
  renderPhoneNumbers();
}

function saveAllEmployeePhones() {
  const inputs = [...document.querySelectorAll("[data-phone-key]")];
  if (!inputs.length) return;
  state.employeePhones = { ...(state.employeePhones || {}) };
  inputs.forEach((input) => {
    const key = input.dataset.phoneKey;
    const phone = String(input.value || "").trim();
    if (!key) return;
    if (phone) {
      state.employeePhones[key] = phone;
    } else {
      state.employeePhones[key] = null;
    }
  });
  saveState();
  renderPhoneNumbers();
}

function deleteEmployeePhone(key) {
  if (!requireStaffAdmin("удалить номер телефона")) return;
  state.employeePhones = { ...(state.employeePhones || {}) };
  state.employeePhones[key] = null;
  saveState();
  renderPhoneNumbers();
}

function callEmployeePhone(key) {
  const input = phoneInputForKey(key);
  const phone = String(input?.value || (state.employeePhones || {})[key] || "").trim();
  if (!phone) return;
  const dial = phone.replace(/[^\d+]/g, "");
  if (!dial) return;
  if (window.AndroidEmail?.callPhone) {
    window.AndroidEmail.callPhone(dial);
    return;
  }
  window.location.href = `tel:${encodeURIComponent(dial)}`;
}

function vacationPlanSelection() {
  const departmentId = DEFAULT_DEPARTMENT_ID;
  const sectionId = String($("vacationSectionInput")?.value || "");
  const brigade = String($("vacationBrigadeInput")?.value || "");
  const employeeTab = String($("vacationEmployeeInput")?.value || "");
  const startDate = String($("vacationStartDateInput")?.value || "");
  const endDate = String($("vacationEndDateInput")?.value || "");
  const validStart = isValidVacationIsoDate(startDate);
  const validEnd = isValidVacationIsoDate(endDate);
  const sameYear = validStart && validEnd && startDate.slice(0, 4) === endDate.slice(0, 4);
  const validRange = sameYear && endDate >= startDate;
  const year = validStart ? Number(startDate.slice(0, 4)) : null;
  const month = validStart ? Number(startDate.slice(5, 7)) - 1 : null;
  return {
    year,
    departmentId,
    sectionId,
    brigade,
    employeeTab,
    month,
    departmentReady: Boolean(departmentId),
    sectionReady: Boolean(departmentId) && Boolean(sectionId),
    filterReady: Boolean(departmentId) && Boolean(sectionId) && Boolean(brigade),
    brigadeReady: Boolean(brigade),
    baseReady: Boolean(departmentId) && Boolean(sectionId) && Boolean(brigade) && Boolean(employeeTab),
    ready: Boolean(departmentId) && Boolean(sectionId) && Boolean(brigade) && Boolean(employeeTab) && validRange && Number.isInteger(year) && Number.isInteger(month),
  };
}

function resetVacationPeriodInputs() {
  if ($("vacationStartDateInput")) $("vacationStartDateInput").value = "";
  if ($("vacationEndDateInput")) $("vacationEndDateInput").value = "";
  vacationDatePickerDraftStart = "";
  vacationDatePickerDraftEnd = "";
  vacationDatePickerTarget = "start";
  updateVacationAddButtonState();
}

function resetVacationPlanDependentInputs() {
  vacationSelectedEmployeeTab = "";
  if ($("vacationEmployeeInput")) {
    $("vacationEmployeeInput").innerHTML = '<option value="">Выбрать</option>';
    $("vacationEmployeeInput").value = "";
    $("vacationEmployeeInput").disabled = true;
  }
  resetVacationPeriodInputs();
}

function renderVacationHierarchySelects() {
  const sectionSelect = $("vacationSectionInput");
  const brigadeSelect = $("vacationBrigadeInput");
  if (!sectionSelect || !brigadeSelect) return;

  const departments = configuredDepartments();
  const departmentId = departments.some((item) => item.id === DEFAULT_DEPARTMENT_ID)
    ? DEFAULT_DEPARTMENT_ID
    : (departments[0]?.id || DEFAULT_DEPARTMENT_ID);
  state.vacationDepartmentId = departmentId;

  const sections = departmentId ? configuredSections(departmentId) : [];
  const requestedSection = String(sectionSelect.value || state.vacationSectionId || "");
  const sectionId = sections.some((item) => item.id === requestedSection) ? requestedSection : "";
  sectionSelect.innerHTML = '<option value="">Выбрать</option>' + sections
    .map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(configuredSectionLabel(item))}</option>`).join("");
  sectionSelect.value = sectionId;
  sectionSelect.disabled = !departmentId;
  state.vacationSectionId = sectionId;

  if (!sectionId) {
    brigadeSelect.value = "";
    state.vacationBrigade = "";
  }
  brigadeSelect.disabled = !sectionId;
}

function updateVacationAddButtonState() {
  const button = $("vacationAddSelectedBtn");
  if (!button) return;
  const range = vacationInputRange({ silent: true });
  button.disabled = !vacationPlanSelection().ready || !range.valid || !$("vacationEmployeeInput")?.value;
}

function vacationPlanYear() {
  const startDate = String($("vacationStartDateInput")?.value || vacationDatePickerDraftStart || "");
  if (isValidVacationIsoDate(startDate)) return Number(startDate.slice(0, 4));
  const selected = Number(vacationDatePickerCursor?.year ?? state.vacationYear ?? state.year ?? new Date().getFullYear());
  return Number.isInteger(selected) && selected >= 2000 ? selected : new Date().getFullYear();
}

function vacationPlanMonth() {
  const startDate = String($("vacationStartDateInput")?.value || vacationDatePickerDraftStart || "");
  if (isValidVacationIsoDate(startDate)) return Number(startDate.slice(5, 7)) - 1;
  const selected = Number(vacationDatePickerCursor?.month ?? state.month ?? new Date().getMonth());
  return Number.isInteger(selected) && selected >= 0 && selected <= 11 ? selected : new Date().getMonth();
}

function vacationDatePickerYearBounds() {
  const currentYear = new Date().getFullYear();
  return { min: currentYear, max: currentYear + VACATION_PICKER_FUTURE_YEARS };
}

function vacationDatePickerYearOptions() {
  const { min, max } = vacationDatePickerYearBounds();
  return Array.from({ length: max - min + 1 }, (_, index) => min + index);
}

function vacationYearOptions() {
  return vacationDatePickerYearOptions();
}

function vacationDatePickerDefaultCursor() {
  const now = new Date();
  return { year: now.getFullYear(), month: now.getMonth() };
}

function clampVacationDatePickerCursor(cursor = vacationDatePickerDefaultCursor()) {
  const { min, max } = vacationDatePickerYearBounds();
  const year = Math.min(max, Math.max(min, Number(cursor.year) || min));
  const month = Math.min(11, Math.max(0, Number(cursor.month) || 0));
  return { year, month };
}

function renderVacationDatePickerPeriodOptions() {
  const monthSelect = $("vacationDatePickerMonthInput");
  const yearSelect = $("vacationDatePickerYearInput");
  vacationDatePickerCursor = clampVacationDatePickerCursor(vacationDatePickerCursor);
  if (monthSelect) {
    monthSelect.innerHTML = MONTHS.map((name, index) => `<option value="${index}">${name.charAt(0).toUpperCase()}${name.slice(1)}</option>`).join("");
    monthSelect.value = String(vacationDatePickerCursor.month);
  }
  if (yearSelect) {
    yearSelect.innerHTML = vacationDatePickerYearOptions().map((year) => `<option value="${year}">${year}</option>`).join("");
    yearSelect.value = String(vacationDatePickerCursor.year);
  }
}

function handleVacationDatePickerPeriodChange() {
  const month = Number($("vacationDatePickerMonthInput")?.value);
  const year = Number($("vacationDatePickerYearInput")?.value);
  const { min, max } = vacationDatePickerYearBounds();
  if (!Number.isInteger(month) || month < 0 || month > 11) return;
  if (!Number.isInteger(year) || year < min || year > max) return;
  vacationDatePickerCursor = { year, month };
  renderVacationDatePicker();
}

function setVacationViewMode(mode) {
  vacationViewMode = ["plan", "staff", "settings"].includes(mode) ? mode : "plan";
  renderVacationModeControls();
}

function renderVacationModeControls() {
  document.querySelectorAll("[data-vacation-mode]").forEach((button) => {
    const active = button.dataset.vacationMode === vacationViewMode;
    button.classList.toggle("active", active);
    button.setAttribute("aria-selected", active ? "true" : "false");
  });
  document.querySelectorAll("[data-vacation-view]").forEach((view) => {
    view.classList.toggle("hidden", view.dataset.vacationView !== vacationViewMode);
  });
}

function currentVacations() {
  return (state.vacations || []).filter(belongsToVacationBrigade);
}

function vacationEmployeeKey(item) {
  return `${itemBrigade(item)}:${item.tab ? `tab:${item.tab}` : `name:${normalizeName(item.name)}`}`;
}

function isValidVacationIsoDate(value) {
  const text = String(value || "");
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);
  if (!match) return false;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
}

function vacationIsoDate(year, month, day) {
  return `${String(year).padStart(4, "0")}-${String(Number(month) + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

function vacationDateObject(value) {
  return new Date(`${value}T00:00:00Z`);
}

function vacationDateToIso(date) {
  return date.toISOString().slice(0, 10);
}

function addVacationDays(value, days) {
  const date = vacationDateObject(value);
  date.setUTCDate(date.getUTCDate() + Number(days || 0));
  return vacationDateToIso(date);
}

function vacationDateRangeDays(startDate, endDate) {
  if (!isValidVacationIsoDate(startDate) || !isValidVacationIsoDate(endDate) || endDate < startDate) return 0;
  return Math.floor((vacationDateObject(endDate) - vacationDateObject(startDate)) / 86400000) + 1;
}

function vacationItemRange(item) {
  const fallbackYear = Number(item?.year || state.year || new Date().getFullYear());
  const fallbackMonth = Math.min(11, Math.max(0, Number(item?.month || 0)));
  const startDate = isValidVacationIsoDate(item?.startDate)
    ? String(item.startDate)
    : vacationIsoDate(fallbackYear, fallbackMonth, 1);
  const storedDays = Math.max(1, Math.round(Number(item?.days || 1)));
  const endDate = isValidVacationIsoDate(item?.endDate) && String(item.endDate) >= startDate
    ? String(item.endDate)
    : addVacationDays(startDate, storedDays - 1);
  return {
    startDate,
    endDate,
    days: vacationDateRangeDays(startDate, endDate),
  };
}

function vacationMonthBounds(year, month) {
  return {
    startDate: vacationIsoDate(year, month, 1),
    endDate: vacationIsoDate(year, month, new Date(Date.UTC(year, Number(month) + 1, 0)).getUTCDate()),
  };
}

function vacationYearBounds(year) {
  return { startDate: `${year}-01-01`, endDate: `${year}-12-31` };
}

function vacationRangesOverlap(firstStart, firstEnd, secondStart, secondEnd) {
  return firstStart <= secondEnd && secondStart <= firstEnd;
}

function vacationItemIntersectsMonth(item, year, month) {
  const range = vacationItemRange(item);
  const bounds = vacationMonthBounds(Number(year), Number(month));
  return vacationRangesOverlap(range.startDate, range.endDate, bounds.startDate, bounds.endDate);
}

function vacationItemIntersectsYear(item, year) {
  const range = vacationItemRange(item);
  const bounds = vacationYearBounds(Number(year));
  return vacationRangesOverlap(range.startDate, range.endDate, bounds.startDate, bounds.endDate);
}

function vacationRangeIntersectionDays(startDate, endDate, boundsStart, boundsEnd) {
  const overlapStart = startDate > boundsStart ? startDate : boundsStart;
  const overlapEnd = endDate < boundsEnd ? endDate : boundsEnd;
  return vacationDateRangeDays(overlapStart, overlapEnd);
}

function vacationItemDaysInMonth(item, year, month) {
  const range = vacationItemRange(item);
  const bounds = vacationMonthBounds(Number(year), Number(month));
  return vacationRangeIntersectionDays(range.startDate, range.endDate, bounds.startDate, bounds.endDate);
}

function vacationItemDaysInYear(item, year) {
  const range = vacationItemRange(item);
  const bounds = vacationYearBounds(Number(year));
  return vacationRangeIntersectionDays(range.startDate, range.endDate, bounds.startDate, bounds.endDate);
}

function vacationRangeMonthSegments(startDate, endDate) {
  const segments = new Map();
  if (!vacationDateRangeDays(startDate, endDate)) return [];
  let cursor = startDate;
  let guard = 0;
  while (cursor <= endDate && guard < 370) {
    const date = vacationDateObject(cursor);
    const year = date.getUTCFullYear();
    const month = date.getUTCMonth();
    const key = `${year}:${month}`;
    const segment = segments.get(key) || { year, month, days: 0 };
    segment.days += 1;
    segments.set(key, segment);
    cursor = addVacationDays(cursor, 1);
    guard += 1;
  }
  return [...segments.values()];
}

function vacationRangeLabel(item) {
  const range = vacationItemRange(item);
  const start = formatDate(range.startDate);
  const end = formatDate(range.endDate);
  return `${start}${range.startDate === range.endDate ? "" : `–${end}`} · ${vacationDaysText(range.days)}`;
}

function vacationDateShiftSummary(dateValue) {
  if (!isValidVacationIsoDate(dateValue)) return "";
  const dayBrigade = startShiftForDate(dateValue, "day");
  const nightBrigade = startShiftForDate(dateValue, "night");
  return `День: бр. ${dayBrigade} · Ночь: бр. ${nightBrigade}`;
}

function openVacationDatePicker() {
  const picker = $("vacationShiftDatePicker");
  if (!picker || !vacationPlanSelection().baseReady) return;
  vacationDatePickerTarget = "start";
  vacationDatePickerDraftStart = String($("vacationStartDateInput")?.value || "");
  vacationDatePickerDraftEnd = String($("vacationEndDateInput")?.value || "");
  const value = vacationDatePickerDraftStart;
  if (isValidVacationIsoDate(value)) {
    vacationDatePickerCursor = {
      year: Number(value.slice(0, 4)),
      month: Number(value.slice(5, 7)) - 1,
    };
  } else {
    vacationDatePickerCursor = clampVacationDatePickerCursor(vacationDatePickerCursor);
  }
  picker.classList.remove("hidden");
  picker.setAttribute("aria-hidden", "false");
  document.body.classList.add("vacation-date-picker-open");
  renderVacationDatePicker();
  window.setTimeout(() => {
    picker.querySelector(".vacation-shift-date-cell.selected-start, .vacation-shift-date-cell.selected-end, .vacation-shift-date-cell:not(:disabled)")?.focus();
  }, 0);
}

function closeVacationDatePicker() {
  const picker = $("vacationShiftDatePicker");
  document.body.classList.remove("vacation-date-picker-open");
  if (!picker || picker.classList.contains("hidden")) return;
  picker.classList.add("hidden");
  picker.setAttribute("aria-hidden", "true");
  vacationDatePickerDraftStart = String($("vacationStartDateInput")?.value || "");
  vacationDatePickerDraftEnd = String($("vacationEndDateInput")?.value || "");
  vacationDatePickerTarget = "start";
}

function moveVacationDatePicker(delta) {
  const date = new Date(Date.UTC(vacationDatePickerCursor.year, vacationDatePickerCursor.month + delta, 1));
  const { min, max } = vacationDatePickerYearBounds();
  const startYear = isValidVacationIsoDate(vacationDatePickerDraftStart)
    ? Number(vacationDatePickerDraftStart.slice(0, 4))
    : null;
  const minYear = vacationDatePickerTarget === "end" && startYear ? startYear : min;
  const maxYear = vacationDatePickerTarget === "end" && startYear ? startYear : max;
  const year = date.getUTCFullYear();
  if (year < minYear || year > maxYear) return;
  vacationDatePickerCursor = { year, month: date.getUTCMonth() };
  renderVacationDatePicker();
}

function selectVacationPickerDate(dateValue) {
  if (!isValidVacationIsoDate(dateValue)) return;
  const startInput = $("vacationStartDateInput");
  const endInput = $("vacationEndDateInput");
  if (isValidVacationIsoDate(vacationDatePickerDraftEnd) && dateValue === vacationDatePickerDraftEnd) {
    vacationDatePickerDraftEnd = "";
    vacationDatePickerTarget = "end";
    if (endInput) endInput.value = "";
    renderVacationDatePicker();
    updateVacationAddButtonState();
    return;
  }
  if (isValidVacationIsoDate(vacationDatePickerDraftStart) && dateValue === vacationDatePickerDraftStart) {
    vacationDatePickerDraftStart = "";
    vacationDatePickerDraftEnd = "";
    vacationDatePickerTarget = "start";
    if (startInput) startInput.value = "";
    if (endInput) endInput.value = "";
    renderVacationDatePicker();
    updateVacationAddButtonState();
    return;
  }
  if (vacationDatePickerTarget === "start") {
    vacationDatePickerDraftStart = dateValue;
    vacationDatePickerDraftEnd = "";
    vacationDatePickerTarget = "end";
    vacationDatePickerCursor = {
      year: Number(dateValue.slice(0, 4)),
      month: Number(dateValue.slice(5, 7)) - 1,
    };
    renderVacationDatePicker();
    return;
  }

  if (!isValidVacationIsoDate(vacationDatePickerDraftStart) || dateValue < vacationDatePickerDraftStart) return;
  if (dateValue.slice(0, 4) !== vacationDatePickerDraftStart.slice(0, 4)) return;
  vacationDatePickerDraftEnd = dateValue;
  if (!startInput || !endInput) return;
  startInput.value = vacationDatePickerDraftStart;
  endInput.value = vacationDatePickerDraftEnd;
  const start = vacationDateObject(vacationDatePickerDraftStart);
  state.vacationYear = start.getUTCFullYear();
  renderVacations();
  renderVacationDatePicker();
  updateVacationAddButtonState();
  $("vacationAddSelectedBtn")?.focus();
}

function renderVacationDatePicker() {
  const picker = $("vacationShiftDatePicker");
  const calendar = $("vacationDatePickerCalendar");
  if (!picker || !calendar || picker.classList.contains("hidden")) return;

  vacationDatePickerCursor = clampVacationDatePickerCursor(vacationDatePickerCursor);
  const startValue = vacationDatePickerDraftStart;
  const endValue = vacationDatePickerDraftEnd;
  if (vacationDatePickerTarget === "end" && isValidVacationIsoDate(startValue)) {
    const startYear = Number(startValue.slice(0, 4));
    if (vacationDatePickerCursor.year !== startYear) {
      vacationDatePickerCursor = {
        year: startYear,
        month: Number(startValue.slice(5, 7)) - 1,
      };
    }
  }
  const { year, month } = vacationDatePickerCursor;
  $("vacationDatePickerHeading").textContent = vacationDatePickerTarget === "end"
    ? "Выберите окончание отпуска"
    : "Выберите начало отпуска";
  renderVacationDatePickerPeriodOptions();
  const yearSelect = $("vacationDatePickerYearInput");
  if (yearSelect) yearSelect.disabled = vacationDatePickerTarget === "end";
  const { min, max } = vacationDatePickerYearBounds();
  const lockedYear = vacationDatePickerTarget === "end" && isValidVacationIsoDate(startValue)
    ? Number(startValue.slice(0, 4))
    : null;
  const minYear = lockedYear ?? min;
  const maxYear = lockedYear ?? max;
  $("vacationDatePickerPrevBtn").disabled = year === minYear && month === 0;
  $("vacationDatePickerNextBtn").disabled = year === maxYear && month === 11;

  const first = new Date(Date.UTC(year, month, 1));
  const daysInMonth = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
  const mondayBasedStart = (first.getUTCDay() + 6) % 7;
  const activeValue = vacationDatePickerTarget === "end" ? endValue : startValue;
  const rangeDays = vacationDateRangeDays(startValue, endValue);
  const rangeStatus = $("vacationDatePickerRangeStatus");
  if (rangeStatus) {
    if (vacationDatePickerTarget === "end" && isValidVacationIsoDate(startValue)) {
      rangeStatus.textContent = `Начало: ${formatDate(startValue)} · теперь выберите окончание`;
    } else if (rangeDays) {
      rangeStatus.textContent = `Текущий период: ${formatDate(startValue)}–${formatDate(endValue)}`;
    } else {
      rangeStatus.textContent = "Первое нажатие — начало, второе — окончание";
    }
  }
  const today = new Date();
  const todayValue = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  const cells = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]
    .map((day) => `<div class="vacation-date-calendar-head">${day}</div>`);

  for (let index = 0; index < mondayBasedStart; index += 1) {
    cells.push('<div class="vacation-shift-date-cell muted" aria-hidden="true"></div>');
  }

  for (let day = 1; day <= daysInMonth; day += 1) {
    const dateValue = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    const dayBrigade = startShiftForDate(dateValue, "day");
    const nightBrigade = startShiftForDate(dateValue, "night");
    const disabled = vacationDatePickerTarget === "end" && isValidVacationIsoDate(startValue) && dateValue < startValue;
    const classes = ["vacation-shift-date-cell"];
    if (dateValue === startValue) classes.push("selected-start");
    if (dateValue === endValue) classes.push("selected-end");
    if (isValidVacationIsoDate(startValue) && isValidVacationIsoDate(endValue) && dateValue > startValue && dateValue < endValue) classes.push("in-range");
    if (dateValue === todayValue) classes.push("today");
    if (dateValue === activeValue) classes.push("active-target");
    cells.push(`
      <button class="${classes.join(" ")}" type="button" data-vacation-picker-date="${dateValue}" aria-label="${formatDate(dateValue)}. Дневная смена: бригада ${dayBrigade}. Ночная смена: бригада ${nightBrigade}." aria-pressed="${dateValue === activeValue}" ${disabled ? "disabled" : ""}>
        <strong>${day}</strong>
        <span class="vacation-date-shift day${isCurrentStartShift(dateValue, "day") ? " current-shift" : ""}"><em>День</em><b>Бр. ${dayBrigade}</b></span>
        <span class="vacation-date-shift night${isCurrentStartShift(dateValue, "night") ? " current-shift" : ""}"><em>Ночь</em><b>Бр. ${nightBrigade}</b></span>
      </button>
    `);
  }

  const usedDateCells = mondayBasedStart + daysInMonth;
  for (let index = usedDateCells; index < 42; index += 1) {
    cells.push('<div class="vacation-shift-date-cell muted" aria-hidden="true"></div>');
  }

  calendar.innerHTML = cells.join("");
  calendar.querySelectorAll("[data-vacation-picker-date]").forEach((button) => {
    button.addEventListener("click", () => selectVacationPickerDate(button.dataset.vacationPickerDate));
  });
}

function syncVacationDateInputs(force = false) {
  const startInput = $("vacationStartDateInput");
  const endInput = $("vacationEndDateInput");
  if (!startInput || !endInput) return;
  const selection = vacationPlanSelection();
  if (!selection.ready || force) {
    startInput.value = "";
    endInput.value = "";
  }
  if (!selection.ready) {
    startInput.removeAttribute("min");
    startInput.removeAttribute("max");
    endInput.removeAttribute("min");
    endInput.removeAttribute("max");
    updateVacationAddButtonState();
    return;
  }
  const { year } = selection;
  startInput.min = `${year}-01-01`;
  startInput.max = `${year}-12-31`;
  endInput.min = `${year}-01-01`;
  endInput.max = `${year}-12-31`;
  if (isValidVacationIsoDate(startInput.value) && Number(startInput.value.slice(0, 4)) !== year) startInput.value = "";
  if (isValidVacationIsoDate(endInput.value) && Number(endInput.value.slice(0, 4)) !== year) endInput.value = "";
  if (!isValidVacationIsoDate(startInput.value)) startInput.value = "";
  if (!isValidVacationIsoDate(endInput.value)) endInput.value = "";
  updateVacationAddButtonState();
}

function handleVacationStartDateChange() {
  const startInput = $("vacationStartDateInput");
  const endInput = $("vacationEndDateInput");
  if (isValidVacationIsoDate(startInput?.value)) {
    const start = vacationDateObject(startInput.value);
    state.vacationYear = start.getUTCFullYear();
    vacationDatePickerCursor = { year: start.getUTCFullYear(), month: start.getUTCMonth() };
    if (!isValidVacationIsoDate(endInput?.value) || endInput.value < startInput.value) {
      endInput.value = startInput.value;
    }
  }
  renderVacations();
}

function vacationInputRange(options = {}) {
  const startDate = String($("vacationStartDateInput")?.value || "");
  const endDate = String($("vacationEndDateInput")?.value || "");
  let error = "";
  if (!isValidVacationIsoDate(startDate) || !isValidVacationIsoDate(endDate)) {
    error = "Укажи даты начала и окончания отпуска.";
  } else if (endDate < startDate) {
    error = "Окончание отпуска не может быть раньше начала.";
  } else if (Number(startDate.slice(0, 4)) !== vacationPlanYear() || Number(endDate.slice(0, 4)) !== vacationPlanYear()) {
    error = `Отпуск должен находиться в пределах ${vacationPlanYear()} года.`;
  }
  const days = error ? 0 : vacationDateRangeDays(startDate, endDate);
  if (!error && days > 366) error = "Период отпуска слишком большой.";
  if (error && !options.silent) alert(error);
  return { valid: !error, error, startDate, endDate, days: error ? 0 : days };
}

function vacationTodayIso() {
  const today = new Date();
  return vacationIsoDate(today.getFullYear(), today.getMonth(), today.getDate());
}

function vacationOverviewStatus(periods, year) {
  if (!periods.length) return { key: "unplanned", label: "Не распределён", description: "Период ещё не назначен" };
  const today = vacationTodayIso();
  const currentYear = new Date().getFullYear();
  if (Number(year) > currentYear) return { key: "planned", label: "Запланирован", description: "На следующий год" };
  const finished = periods.filter((item) => vacationItemRange(item).endDate < today).length;
  const active = periods.some((item) => {
    const range = vacationItemRange(item);
    return range.startDate <= today && today <= range.endDate;
  });
  const upcoming = periods.filter((item) => vacationItemRange(item).startDate > today).length;
  if (active) return { key: "active", label: "Идёт сейчас", description: "Сотрудник сейчас в отпуске" };
  if (Number(year) < currentYear || finished === periods.length) {
    return { key: "done", label: "Отгулял", description: "Все периоды завершены" };
  }
  if (finished > 0 && upcoming > 0) {
    return { key: "partial", label: "Часть отгуляна", description: "Остался ещё один период" };
  }
  return { key: "upcoming", label: "Предстоит", description: "Отпуск ещё впереди" };
}

function vacationOverviewEmployeeRows(year, options = {}) {
  const onlyPlanned = Boolean(options.onlyPlanned);
  const vacations = currentVacations().filter((item) => vacationItemIntersectsYear(item, year));
  const byEmployee = new Map();
  for (const item of vacations) {
    const key = vacationEmployeeKey(item);
    const periods = byEmployee.get(key) || [];
    periods.push(item);
    byEmployee.set(key, periods);
  }
  return vacationEmployees()
    .map((employee) => {
      const periods = (byEmployee.get(vacationEmployeeKey(employee)) || [])
        .sort((a, b) => vacationItemRange(a).startDate.localeCompare(vacationItemRange(b).startDate));
      return { employee, periods, status: vacationOverviewStatus(periods, year) };
    })
    .filter((item) => !onlyPlanned || item.periods.length)
    .sort((a, b) => {
      const order = { active: 0, upcoming: 1, partial: 2, planned: 3, unplanned: 4, done: 5 };
      return (order[a.status.key] ?? 9) - (order[b.status.key] ?? 9)
        || compareEmployeeWorkplaceGrade(a.employee, b.employee);
    });
}

function renderVacationOverviewPeriods(periods, emptyText) {
  return periods.length
    ? periods.map((item) => `<span class="vacation-overview-period">${escapeHtml(vacationRangeLabel(item))}</span>`).join("")
    : `<span class="vacation-overview-period is-empty">${escapeHtml(emptyText)}</span>`;
}

function renderVacationOverviewList(rows, emptyText) {
  if (!rows.length) return `<div class="vacation-overview-empty">${escapeHtml(emptyText)}</div>`;
  return `<div class="vacation-overview-list">${rows.map(({ employee, periods, status }) => `
    <article class="vacation-overview-card is-${escapeHtml(status.key)}">
      <div class="vacation-overview-card-main">
        <strong>${escapeHtml(employee.name || "Без ФИО")}</strong>
        <span>${escapeHtml(employee.place || "Место не указано")} · ${escapeHtml(employee.grade || "—")} разряд · Бр. ${escapeHtml(itemBrigade(employee) || "—")}</span>
        <label class="vacation-overview-allowance">Норма отпуска
          <select aria-label="Норма отпуска для ${escapeHtml(employee.name || "сотрудника")}" onchange="setVacationAllowance('${escapeJs(itemBrigade(employee))}', '${escapeJs(String(employee.tab || ""))}', this.value)">
            ${VACATION_ALLOWANCE_OPTIONS.map((days) => `<option value="${days}" ${vacationAllowance(employee) === days ? "selected" : ""}>${days} дней</option>`).join("")}
          </select>
        </label>
      </div>
      <div class="vacation-overview-card-status">
        <b>${escapeHtml(status.label)}</b>
        <small>${escapeHtml(status.description)}</small>
      </div>
      <div class="vacation-overview-periods">${renderVacationOverviewPeriods(periods, emptyText)}</div>
    </article>
  `).join("")}</div>`;
}

function renderVacationStaffOverview(year = vacationStaffOverviewYear) {
  const box = $("vacationStaffOverview");
  if (!box) return;
  const availableYears = vacationDatePickerYearOptions();
  const selectedYear = availableYears.includes(Number(year)) ? Number(year) : availableYears[0];
  vacationStaffOverviewYear = selectedYear;
  const yearRows = vacationOverviewEmployeeRows(selectedYear);
  const nextYearRows = vacationOverviewEmployeeRows(selectedYear + 1, { onlyPlanned: true });
  const activeRows = yearRows.filter((row) => row.status.key === "active");
  const upcomingRows = yearRows.filter((row) => ["upcoming", "partial", "planned"].includes(row.status.key));
  const doneRows = yearRows.filter((row) => row.status.key === "done");
  const unplannedRows = yearRows.filter((row) => row.status.key === "unplanned");
  const yearOptions = availableYears.map((option) => `<option value="${option}" ${option === selectedYear ? "selected" : ""}>${option}</option>`).join("");
  box.innerHTML = `
    <div class="vacation-overview-toolbar">
      <div>
        <h3>Кто и когда идёт в отпуск</h3>
        <span>Отдельно показано, кто сейчас в отпуске, кому предстоит и кто уже отгулял.</span>
      </div>
      <label>Год просмотра<select id="vacationStaffYearInput">${yearOptions}</select></label>
    </div>
    <div class="vacation-overview-summary" aria-label="Итоги по отпускам">
      <div class="is-active"><strong>${activeRows.length}</strong><span>В отпуске</span></div>
      <div class="is-upcoming"><strong>${upcomingRows.length}</strong><span>Предстоит</span></div>
      <div class="is-done"><strong>${doneRows.length}</strong><span>Отгуляли</span></div>
      <div class="is-unplanned"><strong>${unplannedRows.length}</strong><span>Не распределено</span></div>
    </div>
    <section class="vacation-overview-section">
      <h4>В отпуске <span>· сейчас</span></h4>
      ${renderVacationOverviewList(activeRows, "Сейчас никто не находится в отпуске")}
    </section>
    <section class="vacation-overview-section">
      <h4>Предстоит <span>· запланированные периоды</span></h4>
      ${renderVacationOverviewList(upcomingRows, "Предстоящих отпусков нет")}
    </section>
    <section class="vacation-overview-section">
      <h4>Уже отгуляли <span>· завершённые периоды</span></h4>
      ${renderVacationOverviewList(doneRows, "Завершённых отпусков нет")}
    </section>
    <section class="vacation-overview-section">
      <h4>Не распределено <span>· период ещё не назначен</span></h4>
      ${renderVacationOverviewList(unplannedRows, "Все отпуска распределены")}
    </section>
    <section class="vacation-overview-section is-next-year">
      <h4>${selectedYear + 1} год <span>· следующий год</span></h4>
      ${renderVacationOverviewList(nextYearRows, "Пока никто не запланирован")}
    </section>
  `;
  $("vacationStaffYearInput")?.addEventListener("change", (event) => {
    const nextYear = Number(event.target.value);
    if (Number.isInteger(nextYear)) renderVacationStaffOverview(nextYear);
  });
}

function renderVacations() {
  if (!$("vacationTable")) return;
  const yearOverview = document.querySelector(".vacation-year-overview");
  if (yearOverview) yearOverview.open = true;
  renderVacationModeControls();
  syncVacationDateInputs(false);
  renderVacationHierarchySelects();
  renderVacationEmployeeSelect();
  const selection = vacationPlanSelection();
  const year = selection.ready ? selection.year : vacationPlanYear();
  const month = selection.ready ? selection.month : vacationPlanMonth();
  renderVacationStaffOverview(vacationStaffOverviewYear);
  const balanceYears = vacationDatePickerYearOptions();
  if (!balanceYears.includes(Number(vacationBalanceYear))) vacationBalanceYear = year;
  const balanceYear = Number(vacationBalanceYear);
  if ($("vacationLoadYearLabel")) $("vacationLoadYearLabel").textContent = `${balanceYear} год`;
  if ($("vacationBalanceYearInput")) {
    $("vacationBalanceYearInput").innerHTML = balanceYears
      .map((option) => `<option value="${option}" ${option === balanceYear ? "selected" : ""}>${option} год</option>`)
      .join("");
    $("vacationBalanceYearInput").value = String(balanceYear);
  }
  renderVacationLimitEditor(year, month);
  const monthLoads = vacationMonthLoads(balanceYear);
  renderVacationBalance(monthLoads);
  // Вкладка «Сотрудники» — это общий штат отпусков: без выбранной бригады
  // она должна показывать всех, а не оставлять таблицу пустой.
  if (!selection.filterReady && vacationViewMode !== "staff") {
    if ($("vacationRulesStatus")) $("vacationRulesStatus").innerHTML = "";
    if ($("vacationMonthRoster")) $("vacationMonthRoster").innerHTML = "";
    const tbody = $("vacationTable")?.querySelector("tbody");
    if (tbody) tbody.innerHTML = "";
    updateVacationAddButtonState();
    renderStartVacationInlinePreview();
    return;
  }
  renderVacationRulesStatus(year);
  const vacations = currentVacations().filter((item) => vacationItemIntersectsMonth(item, year, month));
  renderVacationMonthRoster(vacations, month, year);
  const yearVacations = currentVacations().filter((item) => vacationItemIntersectsYear(item, year));
  const byEmployee = new Map();
  for (const item of yearVacations) {
    const key = vacationEmployeeKey(item);
    const list = byEmployee.get(key) || [];
    list.push(item);
    byEmployee.set(key, list);
  }

  $("vacationTable").querySelector("tbody").innerHTML = vacationEmployees()
    .sort(compareEmployeeWorkplaceGrade)
    .map((employee, index) => {
      const parts = (byEmployee.get(vacationEmployeeKey(employee)) || [])
        .sort((a, b) => vacationItemRange(a).startDate.localeCompare(vacationItemRange(b).startDate));
      const total = parts.reduce((sum, item) => sum + vacationItemDaysInYear(item, year), 0);
      const allowance = vacationAllowance(employee);
      const remaining = Math.max(0, allowance - total);
      const priority = vacationPriority(employee);
      const brigade = itemBrigade(employee);
      const tab = String(employee.tab || "");
      return `
        <tr>
          <td class="center">${index + 1}</td>
          <td>${escapeHtml(employee.tab)}</td>
          <td>${escapeHtml(employee.name)}</td>
          <td>${escapeHtml(employeePositionLabel(employee))}</td>
          <td>${escapeHtml(employee.place)}</td>
          <td class="center">${employee.grade}</td>
          <td>
            <select class="vacation-allowance-select" aria-label="Дни отпуска для ${escapeHtml(employee.name)}" onchange="setVacationAllowance('${escapeJs(brigade)}', '${escapeJs(tab)}', this.value)">
              ${VACATION_ALLOWANCE_OPTIONS.map((days) => `<option value="${days}" ${allowance === days ? "selected" : ""}>${days} дней</option>`).join("")}
            </select>
          </td>
          <td>
            <select class="vacation-priority-select" aria-label="Категория отпуска для ${escapeHtml(employee.name)}" onchange="setVacationPriority('${escapeJs(brigade)}', '${escapeJs(tab)}', this.value)">
              ${VACATION_PRIORITIES.map((option) => `<option value="${option.value}" ${priority === option.value ? "selected" : ""}>${option.label}</option>`).join("")}
            </select>
          </td>
          <td>
            ${parts.length ? `
              <div class="vacation-parts">
                ${parts.map((item) => `
                  <span class="vacation-chip">
                    ${escapeHtml(vacationRangeLabel(item))}
                    <button type="button" title="Удалить часть отпуска" onclick="deleteVacationPart('${item.id}')">×</button>
                  </span>
                `).join("")}
              </div>
              <div class="vacation-allocation-total">
                <span>Распределено ${total} из ${allowance} дн.</span>
                <span>Осталось ${remaining} дн.</span>
                ${remaining > 0 ? `<button type="button" class="secondary vacation-add-part-btn" onclick="prepareAdditionalVacationPart('${escapeJs(tab)}')">Добавить ещё часть</button>` : ""}
              </div>
            ` : `
              <div class="vacation-allocation-total is-empty">
                <span>Не распределено</span>
                <span>Осталось ${allowance} дн.</span>
              </div>
            `}
          </td>
        </tr>
      `;
    }).join("");
  renderStartVacationInlinePreview();
}

function renderVacationMonthRoster(vacations, month, year) {
  const box = $("vacationMonthRoster");
  if (!box) return;
  const allYearVacations = currentVacations()
    .filter((item) => vacationItemIntersectsYear(item, year))
    .sort((a, b) => vacationItemRange(a).startDate.localeCompare(vacationItemRange(b).startDate));
  const allPeriodsByEmployee = new Map();
  for (const item of allYearVacations) {
    const key = vacationEmployeeKey(item);
    const periods = allPeriodsByEmployee.get(key) || [];
    periods.push(vacationRangeLabel(item));
    allPeriodsByEmployee.set(key, periods);
  }
  const grouped = new Map();
  for (const item of vacations) {
    const key = vacationEmployeeKey(item);
    const existing = grouped.get(key);
    const monthDays = vacationItemDaysInMonth(item, year, month);
    if (existing) {
      existing.days = Number(existing.days || 0) + monthDays;
      existing.ids.push(item.id);
      existing.periods.push(vacationRangeLabel(item));
    } else {
      grouped.set(key, {
        ...item,
        days: monthDays,
        ids: [item.id],
        periods: allPeriodsByEmployee.get(key) || [vacationRangeLabel(item)],
      });
    }
  }
  const sorted = [...grouped.values()].sort((a, b) => {
    const employeeA = vacationEmployeeFromItem(a);
    const employeeB = vacationEmployeeFromItem(b);
    return itemBrigade(a).localeCompare(itemBrigade(b), "ru")
      || compareEmployeeWorkplaceGrade(
        { ...employeeA, place: a.place || employeeA.place, grade: a.grade || employeeA.grade, name: a.name || employeeA.name },
        { ...employeeB, place: b.place || employeeB.place, grade: b.grade || employeeB.grade, name: b.name || employeeB.name }
      );
  });
  const currentEmployeeKeys = new Set(vacations.map((item) => vacationEmployeeKey(item)));
  const visibleItems = allYearVacations
    .filter((item) => currentEmployeeKeys.has(vacationEmployeeKey(item)))
    .sort((a, b) => {
      const employeeA = vacationEmployeeFromItem(a);
      const employeeB = vacationEmployeeFromItem(b);
      return itemBrigade(a).localeCompare(itemBrigade(b), "ru")
        || compareEmployeeWorkplaceGrade(
          { ...employeeA, place: a.place || employeeA.place, grade: a.grade || employeeA.grade, name: a.name || employeeA.name },
          { ...employeeB, place: b.place || employeeB.place, grade: b.grade || employeeB.grade, name: b.name || employeeB.name }
        )
        || vacationItemRange(a).startDate.localeCompare(vacationItemRange(b).startDate);
    });
  const title = `${MONTHS[month]} ${year}`;
  const totalPeople = sorted.length;
  const totalDays = sorted.reduce((sum, item) => sum + Number(item.days || 0), 0);
  box.innerHTML = `
    <div class="vacation-roster-head">
      <div>
        <strong>Добавлены в ${escapeHtml(title)}</strong>
        <span>${totalPeople} чел. / ${totalDays} дн.</span>
      </div>
    </div>
    ${sorted.length ? `
      <div class="vacation-roster-list">
        ${visibleItems.map((item) => {
          const employee = vacationEmployeeFromItem(item);
          const place = item.place || employee.place || "";
          const grade = item.grade || employee.grade || "";
          const itemMonth = Number(vacationItemRange(item).startDate.slice(5, 7)) - 1;
          const itemDays = vacationItemDaysInMonth(item, year, itemMonth);
          return `
            <div class="vacation-roster-item">
              <div>
                <strong>${escapeHtml(item.name || employee.name || "")}</strong>
                <span>Бр. ${escapeHtml(itemBrigade(item))} · ${escapeHtml(place)}${grade ? ` · ${escapeHtml(grade)}р.` : ""}</span>
                <span>${escapeHtml(vacationRangeLabel(item))}</span>
                <span>В ${escapeHtml(MONTHS[itemMonth])}: ${escapeHtml(itemDays)} дн.</span>
              </div>
              <button type="button" class="danger" onclick="deleteVacationPart('${escapeJs(item.id)}')">Удалить</button>
            </div>
          `;
        }).join("")}
      </div>
    ` : `<div class="vacation-empty">В этот месяц отпуск ещё не добавлен.</div>`}
  `;
}

function renderVacationEmployeeSelect() {
  const select = $("vacationEmployeeInput");
  if (!select) return;
  const previous = String(select.value || vacationSelectedEmployeeTab || "");
  const selection = vacationPlanSelection();
  if (!selection.filterReady) {
    select.innerHTML = '<option value="">Выбрать</option>';
    select.value = "";
    select.disabled = true;
    updateVacationAddButtonState();
    return;
  }
  const employees = vacationEmployees().sort(compareEmployeeWorkplaceGrade);
  select.innerHTML = '<option value="">Выбрать</option>' + employees.map((employee) => {
    const remaining = vacationRemainingDays(employee, vacationPlanYear());
    const category = vacationPriority(employee) === "privileged" ? "льготник" : "обычный";
    const label = `${employee.name} · ${employee.place} · ${employee.grade}р. · осталось ${remaining} дн. · ${category}`;
    return `<option value="${escapeHtml(employee.tab)}">${escapeHtml(label)}</option>`;
  }).join("");
  select.disabled = false;
  if (employees.some((employee) => employee.tab === previous)) {
    select.value = previous;
    vacationSelectedEmployeeTab = previous;
  } else {
    select.value = "";
    vacationSelectedEmployeeTab = "";
  }
  updateVacationAddButtonState();
}

function prepareAdditionalVacationPart(tab) {
  const employeeTab = String(tab || vacationSelectedEmployeeTab || "");
  if (!employeeTab) return;
  const employee = vacationEmployees().find((item) => String(item.tab || "") === employeeTab);
  if (!employee) return;
  vacationSelectedEmployeeTab = employeeTab;
  const select = $("vacationEmployeeInput");
  if (select) select.value = employeeTab;
  resetVacationPeriodInputs();
  renderVacations();
  openVacationDatePicker();
}

function addSelectedVacationPart() {
  const tab = $("vacationEmployeeInput")?.value;
  if (!tab) {
    alert("Выбери сотрудника для отпуска.");
    return;
  }
  addVacationPart(tab);
}

function vacationSettingKey(employee) {
  return `${itemBrigade(employee)}:${String(employee?.tab || "").trim()}`;
}

function vacationEmployeeForSettings(brigade, tab) {
  return activeEmployeesForBrigade(String(brigade || ""))
    .find((employee) => String(employee.tab || "") === String(tab || ""));
}

function vacationAllowance(employee) {
  const configured = Number(state.vacationAllowances?.[vacationSettingKey(employee)] || 35);
  return VACATION_ALLOWANCE_OPTIONS.includes(configured) ? configured : 35;
}

function setVacationAllowance(brigade, tab, value) {
  const employee = vacationEmployeeForSettings(brigade, tab);
  const allowance = Number(value);
  if (!employee || !VACATION_ALLOWANCE_OPTIONS.includes(allowance)) {
    renderVacations();
    return;
  }
  if (!requireStaffAdmin(`изменить количество дней отпуска для ${employee.name}`)) {
    renderVacations();
    return;
  }
  const year = vacationPlanYear();
  const allocated = vacationAllocatedDays(employee, year);
  if (allocated > allowance) {
    alert(`Нельзя установить ${allowance} дней: у ${employee.name} уже распределено ${allocated} дней за ${year} год.`);
    renderVacations();
    return;
  }
  state.vacationAllowances = { ...(state.vacationAllowances || {}) };
  state.vacationAllowances[vacationSettingKey(employee)] = allowance;
  saveState();
  renderVacations();
}

function vacationPriority(employee) {
  const stored = String(state.vacationPriorities?.[vacationSettingKey(employee)] || "regular");
  return LEGACY_PRIVILEGED_VACATION_PRIORITIES.includes(stored) ? "privileged" : "regular";
}

function setVacationPriority(brigade, tab, priority) {
  const employee = vacationEmployeeForSettings(brigade, tab);
  const normalizedPriority = priority === "privileged" ? "privileged" : "regular";
  if (!employee) {
    renderVacations();
    return;
  }
  if (!requireStaffAdmin(`изменить категорию отпуска для ${employee.name}`)) {
    renderVacations();
    return;
  }
  state.vacationPriorities = { ...(state.vacationPriorities || {}) };
  state.vacationPriorities[vacationSettingKey(employee)] = normalizedPriority;
  saveState();
  renderVacations();
}

function vacationItemsForEmployee(employee, year = vacationPlanYear()) {
  const key = vacationEmployeeKey(employee);
  return (state.vacations || []).filter((item) =>
    vacationItemIntersectsYear(item, year)
    && vacationEmployeeKey(item) === key
  );
}

function vacationAllocatedDaysFromItems(employee, year, items) {
  const key = vacationEmployeeKey(employee);
  return (items || [])
    .filter((item) => vacationEmployeeKey(item) === key && vacationItemIntersectsYear(item, year))
    .reduce((sum, item) => sum + vacationItemDaysInYear(item, year), 0);
}

function vacationAllocatedDays(employee, year = vacationPlanYear()) {
  return vacationAllocatedDaysFromItems(employee, year, state.vacations || []);
}

function vacationRemainingDays(employee, year = vacationPlanYear()) {
  return Math.max(0, vacationAllowance(employee) - vacationAllocatedDays(employee, year));
}

function privilegedEmployeesWithRemaining(brigade, year = vacationPlanYear()) {
  return activeEmployeesForBrigade(String(brigade || ""))
    .filter((employee) => vacationPriority(employee) === "privileged")
    .map((employee) => ({ employee, remaining: vacationRemainingDays(employee, year) }))
    .filter((item) => item.remaining > 0);
}

function privilegedVacationPriorityEnabled() {
  return state.vacationPolicySettings?.privilegedPriorityEnabled !== false;
}

function renderVacationRulesStatus(year) {
  const box = $("vacationRulesStatus");
  if (!box) return;
  const employees = vacationEmployees();
  const privileged = employees.filter((employee) => vacationPriority(employee) === "privileged");
  const privilegedRemaining = privileged.reduce((sum, employee) => sum + vacationRemainingDays(employee, year), 0);
  const totalRemaining = employees.reduce((sum, employee) => sum + vacationRemainingDays(employee, year), 0);
  const month = vacationPlanMonth();
  const selectedBrigade = vacationBrigade();
  const limitText = selectedBrigade
    ? `${vacationMonthLimit(year, selectedBrigade, month)} дн. · бригада ${selectedBrigade}`
    : `${vacationSelectedLimit(year, month)} дн. суммарно по бригадам`;
  const priorityEnabled = privilegedVacationPriorityEnabled();
  box.classList.toggle("is-pending", priorityEnabled && privilegedRemaining > 0);
  box.innerHTML = `
    <div><span>Льготники · приоритет ${priorityEnabled ? "включён" : "отключён"}</span><strong>${privileged.length} чел. · осталось ${privilegedRemaining} дн.</strong></div>
    <div><span>Весь штат</span><strong>осталось ${totalRemaining} дн.</strong></div>
    <div><span>Лимит на ${escapeHtml(MONTHS[month])}</span><strong>${escapeHtml(limitText)}</strong></div>
  `;
}

function vacationMonthLimitKey(year, brigade, month) {
  const yearKey = String(year) === "*" ? "*" : String(Number(year));
  const brigadeKey = String(brigade) === "*" ? "*" : String(brigade);
  const monthKey = String(month) === "*" ? "*" : String(Number(month));
  return `${yearKey}:${brigadeKey}:${monthKey}`;
}

function vacationMonthLimit(year, brigade, month) {
  const limits = state.vacationMonthLimits || {};
  const yearKey = String(year) === "*" ? "*" : String(Number(year));
  const brigadeKey = String(brigade) === "*" ? "*" : String(brigade);
  const monthKey = String(month) === "*" ? "*" : String(Number(month));
  const keys = [
    `${yearKey}:${brigadeKey}:${monthKey}`,
    `${yearKey}:${brigadeKey}:*`, `${yearKey}:*:${monthKey}`, `*:${brigadeKey}:${monthKey}`,
    `${yearKey}:*:*`, `*:${brigadeKey}:*`, `*:*:${monthKey}`, `*:*:*`,
  ];
  for (const key of [...new Set(keys)]) {
    const value = limits[key];
    if (value === null || value === undefined || value === "") continue;
    const configured = Number(value);
    if (Number.isInteger(configured) && configured >= 0) return configured;
  }
  return VACATION_MONTH_LIMIT_DAYS;
}

function vacationLimitBrigades() {
  const selected = vacationBrigade();
  if (selected) return [selected];
  const known = new Set(["1", "2", "3", "4"]);
  activeUnifiedEmployees().forEach((employee) => {
    const brigade = itemBrigade(employee);
    if (brigade) known.add(brigade);
  });
  return [...known].sort((a, b) => a.localeCompare(b, "ru", { numeric: true }));
}

function vacationSettingsBrigades() {
  const known = new Set(["1", "2", "3", "4"]);
  activeUnifiedEmployees().forEach((employee) => {
    const brigade = itemBrigade(employee);
    if (brigade) known.add(brigade);
  });
  return [...known].sort((a, b) => a.localeCompare(b, "ru", { numeric: true }));
}

function vacationSelectedLimit(year, month) {
  return vacationLimitBrigades()
    .reduce((sum, brigade) => sum + vacationMonthLimit(year, brigade, month), 0);
}

function vacationMonthDaysForBrigade(year, brigade, month, items = state.vacations || []) {
  return (items || [])
    .filter((item) => vacationItemIntersectsMonth(item, year, month))
    .filter((item) => itemBrigade(item) === String(brigade))
    .reduce((sum, item) => sum + vacationItemDaysInMonth(item, year, month), 0);
}

function canAddVacationWithinLimit(employee, startDate, endDate, options = {}) {
  const brigade = itemBrigade(employee);
  const items = (options.items || state.vacations || [])
    .filter((item) => !(options.excludeIds || []).includes(item.id));
  for (const segment of vacationRangeMonthSegments(startDate, endDate)) {
    const limit = vacationMonthLimit(segment.year, brigade, segment.month);
    const currentDays = vacationMonthDaysForBrigade(segment.year, brigade, segment.month, items);
    const totalDays = currentDays + segment.days;
    if (totalDays <= limit) continue;
    if (!options.silent) {
      alert(`Превышен месячный лимит: бригада ${brigade}, ${MONTHS[segment.month]} ${segment.year}. Лимит ${limit} дн., получится ${totalDays} дн.`);
    }
    return false;
  }
  return true;
}

function vacationMonthLoads(year = vacationPlanYear()) {
  const staffCount = Math.max(1, vacationEmployees().length);
  return MONTHS.map((monthName, month) => {
    const items = currentVacations().filter((item) => vacationItemIntersectsMonth(item, year, month));
    const byEmployee = new Map();
    for (const item of items) {
      const key = vacationEmployeeKey(item);
      byEmployee.set(key, Number(byEmployee.get(key) || 0) + vacationItemDaysInMonth(item, year, month));
    }
    const people = byEmployee.size;
    const days = [...byEmployee.values()].reduce((sum, value) => sum + Number(value || 0), 0);
    const limit = vacationSelectedLimit(year, month);
    const remaining = Math.max(0, limit - days);
    return {
      month,
      monthName,
      people,
      days,
      limit,
      remaining,
      percent: Math.round((people / staffCount) * 100),
      overloaded: days > limit,
    };
  });
}

function renderVacationBalance(loads) {
  if (!$("vacationBalanceBox")) return;
  $("vacationBalanceBox").innerHTML = loads.map((load) => `
    <button class="vacation-month-card ${load.overloaded ? "warn" : ""}" type="button" onclick="selectVacationMonth(${load.month})">
      <strong>${escapeHtml(load.monthName)}</strong>
      <span>${load.people} чел.</span>
      <span class="vacation-limit-line">${load.days} из ${load.limit} дн.</span>
      <span class="vacation-remaining-line">${load.overloaded ? `Превышено на ${load.days - load.limit} дн.` : `Осталось ${load.remaining} дн.`}</span>
    </button>
  `).join("");
}

function renderVacationLimitEditor(year, month, brigade = "") {
  const box = $("vacationLimitEditor");
  if (!box) return;
  const selectedYear = String($("vacationLimitYearInput")?.value || "*");
  const selectedMonth = String($("vacationLimitMonthInput")?.value ?? "*");
  const selectedBrigade = String($("vacationLimitBrigadeInput")?.value || "*");
  const limit = vacationMonthLimit(selectedYear, selectedBrigade, selectedMonth);
  const exactScope = selectedYear !== "*" && selectedBrigade !== "*" && selectedMonth !== "*";
  const used = exactScope ? vacationMonthDaysForBrigade(Number(selectedYear), selectedBrigade, Number(selectedMonth)) : 0;
  const remaining = exactScope ? Math.max(0, limit - used) : 0;
  const scopeDescription = exactScope
    ? `${MONTHS[Number(selectedMonth)]} ${selectedYear} · распределено ${used} дн. · осталось ${remaining} дн.`
    : "Общее правило применяется, если для выбранного периода нет более точного лимита.";
  const priorityEnabled = privilegedVacationPriorityEnabled();
  box.innerHTML = `
    <div class="vacation-limit-card vacation-policy-card">
      <span>Приоритет льготников</span>
      <small>${priorityEnabled ? "Обычным сотрудникам отпуск доступен после распределения дней льготников." : "Льготники и обычные сотрудники планируются без очередности."}</small>
      <label class="vacation-policy-toggle">
        <input id="vacationPriorityRuleInput" type="checkbox" ${priorityEnabled ? "checked" : ""} onchange="setPrivilegedVacationPriorityEnabled(this.checked)" />
        <span>${priorityEnabled ? "Включён" : "Отключён"}</span>
      </label>
    </div>
    <div class="vacation-limit-card ${exactScope && used > limit ? "warn" : ""}">
      <span>Месячный лимит</span>
      <div class="vacation-limit-selectors">
        <label>Год
          <select id="vacationLimitYearInput" onchange="refreshVacationLimitEditor()">
            <option value="*" ${selectedYear === "*" ? "selected" : ""}>Все годы</option>
            ${vacationDatePickerYearOptions().map((value) => `<option value="${value}" ${String(value) === selectedYear ? "selected" : ""}>${value}</option>`).join("")}
          </select>
        </label>
        <label>Бригада
          <select id="vacationLimitBrigadeInput" onchange="refreshVacationLimitEditor()">
            <option value="*" ${selectedBrigade === "*" ? "selected" : ""}>Все бригады</option>
            ${vacationSettingsBrigades().map((value) => `<option value="${escapeHtml(value)}" ${value === selectedBrigade ? "selected" : ""}>Бригада ${escapeHtml(value)}</option>`).join("")}
          </select>
        </label>
        <label>Месяц
          <select id="vacationLimitMonthInput" onchange="refreshVacationLimitEditor()">
            <option value="*" ${selectedMonth === "*" ? "selected" : ""}>Все месяцы</option>
            ${MONTHS.map((value, index) => `<option value="${index}" ${String(index) === selectedMonth ? "selected" : ""}>${escapeHtml(value)}</option>`).join("")}
          </select>
        </label>
      </div>
      <small>${escapeHtml(scopeDescription)}</small>
      <label>Лимит, дней
        <input id="vacationMonthLimitValueInput" type="number" min="0" max="999" step="1" value="${limit}" />
      </label>
      <button type="button" onclick="saveVacationMonthLimit()">Сохранить лимит</button>
    </div>
  `;
}

function refreshVacationLimitEditor() {
  renderVacationLimitEditor(vacationPlanYear(), vacationPlanMonth());
}

function saveVacationMonthLimit() {
  const month = String($("vacationLimitMonthInput")?.value ?? "");
  const year = String($("vacationLimitYearInput")?.value || "");
  const brigade = String($("vacationLimitBrigadeInput")?.value || "");
  const input = $("vacationMonthLimitValueInput");
  const limit = Number(input?.value);
  if (!Number.isInteger(limit) || limit < 0 || limit > 999) {
    alert("Укажи целый лимит от 0 до 999 дней.");
    renderVacations();
    return;
  }
  const yearNumber = Number(year);
  const monthNumber = Number(month);
  const validYear = year === "*" || (Number.isInteger(yearNumber) && vacationDatePickerYearOptions().includes(yearNumber));
  const validMonth = month === "*" || (Number.isInteger(monthNumber) && monthNumber >= 0 && monthNumber < MONTHS.length);
  const validBrigade = brigade === "*" || vacationSettingsBrigades().includes(brigade);
  if (!validYear || !validMonth || !validBrigade) {
    alert("Выбери год, бригаду и месяц для лимита.");
    renderVacations();
    return;
  }
  const exactScope = year !== "*" && brigade !== "*" && month !== "*";
  if (exactScope) {
    const used = vacationMonthDaysForBrigade(yearNumber, brigade, monthNumber);
    if (limit < used) {
      alert(`Нельзя установить ${limit} дн.: у бригады ${brigade} в ${MONTHS[monthNumber]} уже распределено ${used} дн.`);
      renderVacations();
      return;
    }
  }
  const scopeLabel = [
    year === "*" ? "все годы" : year,
    brigade === "*" ? "все бригады" : `бригада ${brigade}`,
    month === "*" ? "все месяцы" : MONTHS[monthNumber],
  ].join(", ");
  if (!requireStaffAdmin(`изменить лимит отпусков: ${scopeLabel}`)) {
    renderVacations();
    return;
  }
  state.vacationMonthLimits = { ...(state.vacationMonthLimits || {}) };
  state.vacationMonthLimits[vacationMonthLimitKey(year, brigade, month)] = limit;
  saveState();
  renderVacations();
}

function setPrivilegedVacationPriorityEnabled(enabled) {
  if (!requireStaffAdmin(`${enabled ? "включить" : "отключить"} приоритет льготников`)) {
    if (activeView === "settings") renderAppSettings();
    else renderVacations();
    return;
  }
  state.vacationPolicySettings = { ...(state.vacationPolicySettings || {}) };
  state.vacationPolicySettings.privilegedPriorityEnabled = Boolean(enabled);
  saveState();
  if (activeView === "settings") renderAppSettings();
  else renderVacations();
}

function selectVacationMonth(month) {
  const year = Number(vacationBalanceYear || vacationPlanYear());
  vacationDatePickerCursor = clampVacationDatePickerCursor({ year, month });
  if ($("vacationStartDateInput")) $("vacationStartDateInput").value = "";
  if ($("vacationEndDateInput")) $("vacationEndDateInput").value = "";
  vacationDatePickerDraftStart = "";
  vacationDatePickerDraftEnd = "";
  renderVacations();
  openVacationDatePicker();
}

function addVacationPart(tab) {
  const employee = vacationEmployees().find((item) => item.tab === String(tab || ""));
  if (!employee) return;
  const range = vacationInputRange();
  if (!range.valid) return;
  const { startDate, endDate, days } = range;
  const year = vacationPlanYear();
  const remaining = vacationRemainingDays(employee, year);
  if (days > remaining) {
    alert(`${employee.name}: осталось распределить ${remaining} дн. из ${vacationAllowance(employee)}. Уменьши количество дней.`);
    return;
  }
  const employeeConflict = vacationEmployeeRangeConflict(employee, startDate, endDate);
  if (employeeConflict) {
    alert(`${employee.name} уже находится в отпуске ${vacationRangeLabel(employeeConflict)}. Периоды одного сотрудника не должны пересекаться.`);
    return;
  }
  if (privilegedVacationPriorityEnabled() && vacationPriority(employee) === "regular") {
    const privilegedRemaining = privilegedEmployeesWithRemaining(itemBrigade(employee), year);
    if (privilegedRemaining.length) {
      const examples = privilegedRemaining.slice(0, 4)
        .map((item) => `${item.employee.name} — ${item.remaining} дн.`)
        .join("\n");
      const extra = privilegedRemaining.length > 4 ? `\nИ ещё: ${privilegedRemaining.length - 4} чел.` : "";
      alert(`Нельзя добавить отпуск обычному сотруднику. Сначала распределите все дни льготникам бригады ${itemBrigade(employee)}.\n\n${examples}${extra}`);
      return;
    }
  }
  if (!canAddVacationWithinLimit(employee, startDate, endDate)) {
    return;
  }
  const workplaceConflict = vacationWorkplaceConflict(employee, startDate, endDate);
  if (workplaceConflict) {
    alert(`Нельзя одновременно отправить в отпуск сотрудников одного рабочего места.\n${workplaceConflict.name} уже запланирован(а) на ${vacationRangeLabel(workplaceConflict.item)} (${workplaceConflict.place}). Следующий сотрудник может начать отпуск на следующий день после окончания этого периода.`);
    return;
  }

  const start = vacationDateObject(startDate);
  state.vacations = state.vacations || [];
  state.vacations.push({
    id: crypto.randomUUID(),
    brigade: itemBrigade(employee),
    year,
    month: start.getUTCMonth(),
    days,
    startDate,
    endDate,
    name: employee.name,
    tab: employee.tab,
    place: employee.place,
    grade: employee.grade,
    updatedAt: new Date().toISOString(),
  });
  saveState();
  closeVacationDatePicker();
  renderVacations();
}

function vacationEmployeeFromItem(item) {
  return activeEmployeesForBrigade(itemBrigade(item))
    .find((employee) => String(employee.tab || "") === String(item?.tab || "")) || item;
}

function vacationWorkplaceKey(value) {
  return String(value || "").trim().toLocaleLowerCase("ru-RU");
}

function vacationEmployeeRangeConflict(employee, startDate, endDate, options = {}) {
  const employeeKey = vacationEmployeeKey(employee);
  const ignored = new Set((options.ignoreIds || []).map(String));
  return (options.items || state.vacations || []).find((item) => {
    if (ignored.has(String(item.id || "")) || vacationEmployeeKey(item) !== employeeKey) return false;
    const range = vacationItemRange(item);
    return vacationRangesOverlap(startDate, endDate, range.startDate, range.endDate);
  }) || null;
}

function vacationWorkplaceConflict(employee, startDate, endDate, options = {}) {
  const placeKey = vacationWorkplaceKey(employee.place);
  if (!placeKey) return null;
  const employeeKey = vacationEmployeeKey(employee);
  const ignored = new Set((options.ignoreIds || []).map(String));
  const conflict = (options.items || state.vacations || []).find((item) => {
    if (ignored.has(String(item.id || ""))) return false;
    if (itemBrigade(item) !== itemBrigade(employee) || vacationEmployeeKey(item) === employeeKey) return false;
    const otherEmployee = vacationEmployeeFromItem(item);
    if (vacationWorkplaceKey(item.place || otherEmployee.place) !== placeKey) return false;
    const range = vacationItemRange(item);
    return vacationRangesOverlap(startDate, endDate, range.startDate, range.endDate);
  });
  if (!conflict) return null;
  const otherEmployee = vacationEmployeeFromItem(conflict);
  return {
    name: conflict.name || otherEmployee.name || "Другой сотрудник",
    place: conflict.place || otherEmployee.place || employee.place,
    item: conflict,
  };
}

function deleteVacationPart(id) {
  if (!requireStaffAdmin("удалить отпуск")) return;
  const cleanId = String(id || "").trim();
  if (!cleanId) return;
  state = normalizeAppStateData(state);
  rememberDeletedId("deletedVacationIds", cleanId);
  state.vacations = (state.vacations || []).filter((item) => String(item?.id || "").trim() !== cleanId);
  saveState();
  renderVacations();
}

function deleteVacationParts(idsText) {
  if (!requireStaffAdmin("удалить отпуск")) return;
  const ids = String(idsText || "").split("|").filter(Boolean);
  if (!ids.length) return;
  ids.forEach((id) => rememberDeletedId("deletedVacationIds", id));
  state.vacations = (state.vacations || []).filter((item) => !ids.includes(item.id));
  saveState();
  renderVacations();
}

function renderCalendar() {
  if (!$("shiftCalendar")) return;
  $("calendarTitle").textContent = `${MONTHS[calendarCursor.month]} ${calendarCursor.year}`;
  const first = new Date(calendarCursor.year, calendarCursor.month, 1);
  const daysInMonth = new Date(calendarCursor.year, calendarCursor.month + 1, 0).getDate();
  const mondayBasedStart = (first.getDay() + 6) % 7;
  const cells = [];
  const weekDays = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];

  for (const day of weekDays) {
    cells.push(`<div class="calendar-head">${day}</div>`);
  }
  for (let i = 0; i < mondayBasedStart; i += 1) {
    cells.push(`<div class="calendar-cell muted"></div>`);
  }

  for (let day = 1; day <= daysInMonth; day += 1) {
    const dateValue = `${calendarCursor.year}-${String(calendarCursor.month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    const shift = getShiftForDate(dateValue);
    const entries = currentEntries().filter((entry) => entry.date === dateValue);
    const absences = currentAbsences().filter((absence) => absence.date === dateValue);
    const proletchik = currentProletchikShifts().filter((shiftItem) => shiftItem.date === dateValue);
    const capitalRepair = currentCapitalRepairShifts().filter((shiftItem) => shiftItem.date === dateValue);
    const markers = [
      entries.length ? `<span>${entries.length} работ.</span>` : "",
      absences.length ? `<span>${absences.length} отс.</span>` : "",
      capitalRepair.length ? `<span>кап.</span>` : "",
      proletchik.length ? `<span>прол.</span>` : "",
    ].filter(Boolean).join("");
    cells.push(`
      <button class="calendar-cell ${shift.kind || ""}" type="button" data-date="${dateValue}">
        <strong>${day}</strong>
        <em>${escapeHtml(shift.label)}</em>
        <small>${markers}</small>
      </button>
    `);
  }

  $("shiftCalendar").innerHTML = cells.join("");
  $("shiftCalendar").querySelectorAll("[data-date]").forEach((button) => {
    button.addEventListener("click", () => renderCalendarDayDetails(button.dataset.date));
  });

  const selected = $("dateInput")?.value;
  if (selected && selected.startsWith(`${calendarCursor.year}-${String(calendarCursor.month + 1).padStart(2, "0")}`)) {
    renderCalendarDayDetails(selected);
  } else {
    $("calendarDayDetails").innerHTML = `<div class="absent-empty">Выбери дату в календаре.</div>`;
  }
}

function renderCalendarDayDetails(dateValue) {
  const shift = getShiftForDate(dateValue);
  const entries = currentEntries().filter((entry) => entry.date === dateValue);
  const absences = currentAbsences().filter((absence) => absence.date === dateValue);
  const proletchik = currentProletchikShifts().filter((shiftItem) => shiftItem.date === dateValue);
  const capitalRepair = currentCapitalRepairShifts().filter((shiftItem) => shiftItem.date === dateValue);

  const entryRows = entries.map((entry) => `
    <tr>
      <td>${escapeHtml(entry.name)}</td>
      <td>${escapeHtml(entry.actualPlace)}</td>
      <td>${entry.actualGrade}</td>
      <td>${escapeHtml(entryKindLabel(entry) || "")}</td>
      <td>${escapeHtml(classifyEntry(entry).mustTransfer ? "в перевод" : "штатно")}</td>
    </tr>
  `).join("");
  const absenceRows = absences.map((absence) => `
    <tr><td>${escapeHtml(absence.name)}</td><td>${escapeHtml(absence.reason)}</td><td>${escapeHtml(absence.comment || "")}</td></tr>
  `).join("");
  const proletchikRows = proletchik.map((item) => {
    const generated = currentEntries().find((entry) => entry.sourceProletchikId === item.id);
    return `<tr><td>${escapeHtml(item.name)}</td><td>${generated ? escapeHtml(`${generated.actualPlace}, ${generated.actualGrade}р.`) : "не распределён"}</td><td>${escapeHtml(item.comment || "")}</td></tr>`;
  }).join("");
  const capitalRepairRows = capitalRepair.map((item) => {
    const generated = currentEntries().find((entry) => entry.sourceCapitalRepairId === item.id);
    return `<tr><td>${escapeHtml(item.name)}</td><td>${generated ? escapeHtml(`${generated.actualPlace}, ${generated.actualGrade}р.`) : "не распределён"}</td><td>${escapeHtml(item.comment || "")}</td></tr>`;
  }).join("");

  $("calendarDayDetails").innerHTML = `
    <div class="day-details-header">
      <h3>${formatDate(dateValue)}</h3>
      <span class="badge ${shift.kind === "off" ? "warn" : "ok"}">${escapeHtml(shift.label)}</span>
    </div>
    <div class="day-detail-grid">
      <section>
        <h4>Кто работал</h4>
        <table>
          <thead><tr><th>ФИО</th><th>Место</th><th>Разряд</th><th>Вид</th><th>Статус</th></tr></thead>
          <tbody>${entryRows || `<tr><td colspan="5">Записей смены нет.</td></tr>`}</tbody>
        </table>
      </section>
      <section>
        <h4>Кто отсутствовал</h4>
        <table>
          <thead><tr><th>ФИО</th><th>Причина</th><th>Комментарий</th></tr></thead>
          <tbody>${absenceRows || `<tr><td colspan="3">Отсутствующих нет.</td></tr>`}</tbody>
        </table>
      </section>
      <section>
        <h4>Капитальный ремонт</h4>
        <table>
          <thead><tr><th>ФИО</th><th>Распределение</th><th>Комментарий</th></tr></thead>
          <tbody>${capitalRepairRows || `<tr><td colspan="3">Капитальный ремонт не указан.</td></tr>`}</tbody>
        </table>
      </section>
      <section>
        <h4>Пролётчик</h4>
        <table>
          <thead><tr><th>ФИО</th><th>Распределение</th><th>Комментарий</th></tr></thead>
          <tbody>${proletchikRows || `<tr><td colspan="3">Пролётчик не указан.</td></tr>`}</tbody>
        </table>
      </section>
    </div>
  `;
}

function renderProletchikShifts() {
  const table = document.getElementById("proletchikTable");
  if (!table) return;
  const tbody = table.querySelector("tbody");
  const shifts = currentProletchikShifts();
  tbody.innerHTML = shifts.map((shift) => {
    const generated = currentEntries().find((entry) => entry.sourceProletchikId === shift.id);
    const assigned = generated
      ? `<span class="badge ok">${escapeHtml(generated.actualPlace)}, ${generated.actualGrade}р.</span>`
      : `<span class="badge warn">не распределён</span>`;
    return `
      <tr>
        <td>${formatDate(shift.date)}</td>
        <td>${escapeHtml(shift.name)}</td>
        <td>${escapeHtml(shift.tab)}</td>
        <td>${assigned}</td>
        <td>${escapeHtml(shift.comment)}</td>
        <td><button class="danger" type="button" onclick="deleteProletchikShift('${shift.id}')">Удалить</button></td>
      </tr>
    `;
  }).join("");

  renderProletchikDistribution();
}

function renderProletchikDistribution(assignments = null) {
  const box = document.getElementById("proletchikDistributionBox");
  if (!box) return;
  const generated = assignments || currentEntries()
    .filter((entry) => entry.generatedProletchik)
    .map((entry) => ({ entry, explanation: entry.comment || "" }));

  if (!generated.length) {
    box.innerHTML = `<div class="absent-empty">Умное распределение пролётчика ещё не выполнялось.</div>`;
    return;
  }

  box.innerHTML = `
    <div class="distribution-title">Распределение пролётчика</div>
    <table>
      <thead>
        <tr><th>Дата</th><th>ФИО</th><th>Куда закрыт</th><th>Разряд</th><th>Почему выбран вариант</th></tr>
      </thead>
      <tbody>
        ${generated.map((item) => `
          <tr>
            <td>${formatDate(item.entry.date)}</td>
            <td>${escapeHtml(item.entry.name)}</td>
            <td>${escapeHtml(item.entry.actualPlace)}</td>
            <td>${item.entry.actualGrade}</td>
            <td>${escapeHtml(item.explanation)}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
}

function renderAbsences() {
  const date = $("workplaceDateInput")?.value || $("dateInput").value;
  if (!$("absenceDashboard")) return;
  if (!date) {
    $("absenceDashboard").innerHTML = `<div class="absent-empty">Дата смены не выбрана.</div>`;
    return;
  }

  const rows = missingEmployeesForDate(date);
  $("absenceDashboard").innerHTML = `
    <div class="absence-current-head">
      <div>
        <strong>${formatDate(date)}</strong>
      </div>
      <span>${rows.length} не указано на рабочих местах</span>
    </div>
    <div class="absence-list">
      ${rows.length ? rows.map((row) => `
        <article class="absence-item">
          <div class="absence-person">
            <strong>${escapeHtml(row.name)}</strong>
            <span>Таб. № ${escapeHtml(row.tab)} · ${escapeHtml(row.place)} · ${escapeHtml(row.grade)}р.</span>
          </div>
          <label class="absence-reason-field">
            Причина
            <select class="absence-reason-select" data-absence-date="${escapeHtml(date)}" data-absence-tab="${escapeHtml(row.tab)}" data-absence-name="${escapeHtml(row.name)}">
              <option value="" ${row.reason ? "" : "selected"}>Выбрать причину</option>
              ${ABSENCE_REASONS.map((reason) => `<option value="${escapeHtml(reason)}" ${row.reason === reason ? "selected" : ""}>${escapeHtml(reason)}</option>`).join("")}
            </select>
          </label>
        </article>
      `).join("") : `<div class="absent-empty">Все сотрудники поставлены на рабочие места.</div>`}
    </div>
  `;

  $("absenceDashboard").querySelectorAll("[data-absence-date]").forEach((select) => {
    select.addEventListener("change", () => {
      setAbsenceReason(select.dataset.absenceDate, select.dataset.absenceTab, select.dataset.absenceName, select.value);
    });
  });
}

function missingEmployeesForDate(date) {
  const cache = ensureWorkplaceCache(date);
  if (cache.missingRows) return cache.missingRows;
  const worked = workedKeysForDate(date);
  const saved = new Map(
    currentAbsences()
      .filter((absence) => absence.date === date)
      .map((absence) => [absenceKey(absence), absence])
  );

  cache.missingRows = currentEmployees()
    .filter((employee) => !worked.has(absenceKey(employee)))
    .sort(compareEmployeeWorkplaceGrade)
    .map((employee) => {
      const absence = saved.get(absenceKey(employee));
      return {
        ...employee,
        reason: absence?.reason === AUTO_ABSENCE_REASON ? "" : (absence?.reason || ""),
      };
    });
  return cache.missingRows;
}

function setAbsenceReason(date, tab, name, reason) {
  const key = tab ? `tab:${tab}` : `name:${normalizeName(name)}`;
  const removed = (state.absences || []).filter((absence) =>
    belongsToCurrentBrigade(absence) && absence.date === date && absenceKey(absence) === key
  );
  removed.forEach((absence) => rememberDeletedId("deletedAbsenceIds", absence.id));
  state.absences = (state.absences || []).filter((absence) => !removed.some((item) => item.id === absence.id));

  if (reason) {
    const employee = currentEmployees().find((item) => absenceKey(item) === key) || { name, tab };
    state.absences.push({
      id: crypto.randomUUID(),
      brigade: currentBrigade(),
      date,
      name: employee.name || name,
      tab: employee.tab || tab,
      reason,
      comment: "Выбрано во вкладке отсутствующие",
      auto: false,
    });
    state.absences.sort((a, b) => a.date.localeCompare(b.date) || a.name.localeCompare(b.name, "ru"));
  }

  saveState();
  renderAbsences();
  renderWorkplaceAddedList();
  renderAbsentToday();
  renderGlobalStaff();
  scheduleGithubSync();
}

function countBy(items, getKey) {
  return items.reduce((acc, item) => {
    const key = getKey(item);
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});
}

function renderAbsentToday() {
  const date = $("dateInput").value;
  const absences = currentAbsences().filter((absence) => absence.date === date);
  if (!date) {
    $("absentTodayBox").innerHTML = "";
    return;
  }
  if (!absences.length) {
    $("absentTodayBox").innerHTML = `<div class="absent-empty">На ${formatDate(date)} отсутствующие не отмечены.</div>`;
    return;
  }
  $("absentTodayBox").innerHTML = `
    <div class="absent-title">Отсутствуют на ${formatDate(date)}</div>
    <div class="absent-list">
      ${absences.map((absence) => `
        <span class="absent-chip">
          ${escapeHtml(absence.name)} · ${escapeHtml(absence.reason)}
        </span>
      `).join("")}
    </div>
  `;
}

function renderStaff() {
  const tbody = $("staffTable").querySelector("tbody");
  const rows = currentEmployees()
    .sort(compareEmployeeWorkplaceGrade)
    .map((employee) => {
      const source = `${isCustomEmployee(employee.tab) ? "добавлен" : "штат"}${employee.edited ? ", ред." : ""}`;
      const status = `<span class="badge ok">активен</span>`;
      const actions = `<button type="button" class="secondary" onclick="editEmployee('${employee.tab}')">Редактировать</button> <button type="button" class="danger" onclick="dismissEmployee('${employee.tab}')">Уволить</button>`;
      const remove = isCustomEmployee(employee.tab)
        ? `<button type="button" class="secondary" onclick="removeCustomEmployee('${employee.tab}')">Удалить совсем</button>`
        : "";
      return `
        <tr>
          <td>${escapeHtml(employee.tab)}</td>
          <td>${escapeHtml(employee.name)}</td>
          <td>${escapeHtml(employee.place)}</td>
          <td>${employee.grade}</td>
          <td>${status} <span class="muted-text">${source}</span></td>
          <td class="staff-actions">${actions} ${remove}</td>
        </tr>
      `;
    });
  tbody.innerHTML = rows.join("");
}

function renderSummary() {
  const entries = currentEntries();
  const transfers = entries.filter((entry) => classifyEntry(entry).mustTransfer);
  const repair = entries.filter((entry) => entryOrdinaryShiftKind(entry, "repair")).length;
  const warmup = entries.filter((entry) => entryOrdinaryShiftKind(entry, "warmup")).length;
  const proletchikShifts = currentProletchikShifts().length;
  const absences = currentAbsences().length;
  const roleTypes = statsRoleTypes(entries);
  const cards = [
    ["Записей", entries.length],
    ["В перевод", transfers.length],
    ["Ремонт", repair],
    ["Разогрев", warmup],
    ...roleTypes.map((roleType) => [
      statsRoleLabel(roleType),
      entries.filter((entry) => statsRoleType(entry) === roleType).length,
    ]),
    ...(roleTypes.includes("proletchik") && proletchikShifts ? [["Нераспределённых смен пролётчика", proletchikShifts]] : []),
    ["Отсутствия", absences],
  ];
  $("summaryCards").innerHTML = cards.map(([label, value]) => `<div class="summary-card">${label}<strong>${value}</strong></div>`).join("");
}

function statsDateRange(period, dateValue) {
  const selected = dateValue ? new Date(`${dateValue}T00:00:00`) : new Date(state.year, state.month, 1);
  if (period === "month") {
    const start = new Date(selected.getFullYear(), selected.getMonth(), 1);
    const end = new Date(selected.getFullYear(), selected.getMonth() + 1, 0);
    return { start: dateInputValue(start), end: dateInputValue(end), label: `${MONTHS[start.getMonth()]} ${start.getFullYear()}` };
  }
  if (period === "week") {
    const start = new Date(selected);
    start.setDate(selected.getDate() - ((selected.getDay() + 6) % 7));
    const end = new Date(start);
    end.setDate(start.getDate() + 6);
    return { start: dateInputValue(start), end: dateInputValue(end), label: `${formatDate(dateInputValue(start))} - ${formatDate(dateInputValue(end))}` };
  }
  const value = dateInputValue(selected);
  return { start: value, end: value, label: formatDate(value) || "смена" };
}

function dateInputValue(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function statsPlaceKey(place) {
  const text = String(place || "").trim();
  const code = placeCode(text);
  if (FURNACES.includes(code)) return `Печь ${code}`;
  if (code === "РМ") return "Разливочные машины";
  if (new RegExp("^цех\\s*\\d+$", "i").test(text) || (new RegExp("^\\d+$").test(text) && !FURNACES.includes(text))) return `Цех ${code}`;
  return text || "Другое место";
}
function entryKindLabel(entry) {
  const specialRole = normalizedSpecialRole(entry);
  if (specialRole) return specialWorkLabel(specialRole, normalizeCustomSpecialRoleId(specialRole) ? "Специальная работа" : specialRole);
  return KIND_LABELS[entry.shiftKind] || entry.shiftKind;
}

function statsEntryVisible(entry) {
  const settings = appSettings();
  const specialRole = normalizedSpecialRole(entry);
  if (specialRole === "proletchik") return settings.statsIncludeProletchik !== false;
  if (specialRole === "capitalRepair") return settings.statsIncludeCapitalRepair !== false;
  if (specialRole === "subworker") return settings.statsIncludeSubworkers !== false;
  if (normalizeCustomSpecialRoleId(specialRole)) return true;
  if (entry.shiftKind === "repair" && settings.statsIncludeRepair === false) return false;
  if (entry.shiftKind === "warmup" && settings.statsIncludeWarmup === false) return false;
  return true;
}

function selectedStatsHierarchy() {
  const departmentId = selectedWorkplaceDepartmentId || selectedStatsDepartmentId || "";
  const sectionId = selectedWorkplaceSectionId || selectedStatsSectionId || "";
  const department = configuredDepartments().find((item) => item.id === departmentId);
  const section = configuredSections(departmentId).find((item) => item.id === sectionId);
  return {
    departmentId,
    sectionId,
    departmentName: department?.name || "Текущий цех",
    sectionName: section ? configuredSectionLabel(section) : "Текущий участок",
    place: "",
    placeName: "Все рабочие места участка",
  };
}

function statsItemMatchesHierarchy(item) {
  const hierarchy = selectedStatsHierarchy();
  const itemPlace = item?.actualPlace || item?.place || "";
  return workplaceMatchesHierarchy(
    itemPlace,
    hierarchy.departmentId,
    hierarchy.sectionId
  ) && (!hierarchy.place || itemPlace === hierarchy.place || statsPlaceKey(itemPlace) === statsPlaceKey(hierarchy.place));
}

function entriesForStats() {
  const date = $("statsDateInput")?.value || $("dateInput")?.value || dateInputValue(new Date());
  const period = "month";
  const range = statsDateRange(period, date);
  const effectiveRange = { ...range, end: date < range.end ? date : range.end };
  const entries = currentEntries().filter((entry) =>
    entry.date >= effectiveRange.start
    && entry.date <= effectiveRange.end
    && brigadeWorksOnDate(entry.date, itemBrigade(entry))
    && statsEntryVisible(entry)
    && statsItemMatchesHierarchy(entry)
  );
  return { period, range: effectiveRange, entries };
}

function buildStatsRows(entries) {
  const order = [...FURNACES.map((code) => `Печь ${code}`), "Разливочные машины"];
  const groups = new Map(order.map((place) => [place, {
    place,
    peopleKeys: new Set(),
    workers: [],
    shifts: 0,
    hours: 0,
    nominalHours: 0,
    baseBalanceHours: 0,
    finalBalanceHours: 0,
    lowPayLossHours: 0,
    repairLossHours: 0,
    warmupLossHours: 0,
    capitalRepairHours: 0,
    proletchikHours: 0,
    repair: 0,
    warmup: 0,
    average: 0,
    proletchik: 0,
    capitalRepair: 0,
  }]));

  for (const entry of entries) {
    const place = statsPlaceKey(entry.actualPlace);
    if (!groups.has(place)) {
      groups.set(place, {
        place,
        peopleKeys: new Set(),
        workers: [],
        shifts: 0,
        hours: 0,
        nominalHours: 0,
        baseBalanceHours: 0,
        finalBalanceHours: 0,
        lowPayLossHours: 0,
        repairLossHours: 0,
        warmupLossHours: 0,
        capitalRepairHours: 0,
        proletchikHours: 0,
        repair: 0,
        warmup: 0,
        average: 0,
        proletchik: 0,
        capitalRepair: 0,
      });
    }
    const row = groups.get(place);
    const specialRole = normalizedSpecialRole(entry);
    const ordinaryRepair = !specialRole && entry.shiftKind === "repair";
    const ordinaryWarmup = !specialRole && entry.shiftKind === "warmup";
    const ordinaryAverage = !specialRole && entry.shiftKind === "average";
    const shiftCount = Number(entry.shiftCount || 1);
    const workedHours = Number(entry.hours || hoursForKind(entry.shiftKind, shiftCount));
    const nominalHours = Number((12 * shiftCount).toFixed(1));
    const balanceHours = entryBalanceHours(entry);
    const lowPayLossHours = entryLowPayLossHours(entry);
    row.peopleKeys.add(entry.tab ? `tab:${entry.tab}` : `name:${normalizeName(entry.name)}`);
    row.workers.push({
      date: entry.date,
      name: entry.name,
      tab: entry.tab,
      grade: entry.actualGrade,
      kind: entryKindLabel(entry),
      hours: workedHours,
      nominalHours,
      balanceHours,
      lowPayLossHours,
      isRepair: ordinaryRepair,
      isWarmup: ordinaryWarmup,
      isAverage: ordinaryAverage,
      isProletchik: specialRole === "proletchik",
      isCapitalRepair: specialRole === "capitalRepair",
    });
    row.shifts += shiftCount;
    row.hours += workedHours;
    row.nominalHours += nominalHours;
    row.finalBalanceHours += balanceHours;
    row.lowPayLossHours += lowPayLossHours;
    if (ordinaryRepair) row.repairLossHours += lowPayLossHours;
    if (ordinaryWarmup) row.warmupLossHours += lowPayLossHours;
    if (specialRole === "capitalRepair") {
      row.capitalRepair += shiftCount;
      row.capitalRepairHours += balanceHours;
    } else if (specialRole === "proletchik") {
      row.proletchik += shiftCount;
      row.proletchikHours += balanceHours;
    } else {
      row.baseBalanceHours += balanceHours;
    }
    if (ordinaryRepair) row.repair += shiftCount;
    if (ordinaryWarmup) row.warmup += shiftCount;
    if (ordinaryAverage) row.average += shiftCount;
  }

  return [...groups.values()]
    .map((row) => ({
      ...row,
      people: row.peopleKeys.size,
      hours: Number(row.hours.toFixed(1)),
      nominalHours: Number(row.nominalHours.toFixed(1)),
      baseBalanceHours: Number(row.baseBalanceHours.toFixed(1)),
      finalBalanceHours: Number(row.finalBalanceHours.toFixed(1)),
      withoutLowPayHours: Number((row.finalBalanceHours + row.lowPayLossHours).toFixed(1)),
      withoutCapitalRepairHours: Number((row.finalBalanceHours - row.capitalRepairHours).toFixed(1)),
      withoutProletchikHours: Number((row.finalBalanceHours - row.proletchikHours).toFixed(1)),
      lowPayLossHours: Number(row.lowPayLossHours.toFixed(1)),
      repairLossHours: Number(row.repairLossHours.toFixed(1)),
      warmupLossHours: Number(row.warmupLossHours.toFixed(1)),
      capitalRepairHours: Number(row.capitalRepairHours.toFixed(1)),
      proletchikHours: Number(row.proletchikHours.toFixed(1)),
      workers: row.workers.sort((a, b) => a.date.localeCompare(b.date) || a.name.localeCompare(b.name, "ru")),
    }))
    .filter((row) => row.people || row.shifts || row.hours)
    .sort((a, b) => {
      const aIndex = order.indexOf(a.place);
      const bIndex = order.indexOf(b.place);
      return (aIndex === -1 ? 99 : aIndex) - (bIndex === -1 ? 99 : bIndex) || a.place.localeCompare(b.place, "ru");
    });
}

function scheduledShiftCountForRange(range, brigade = currentBrigade()) {
  if (!range?.start || !range?.end) {
    return 0;
  }
  const target = String(brigade || currentBrigade());
  let count = 0;
  for (let serial = dateSerial(range.start); serial <= dateSerial(range.end); serial += 1) {
    const dateValue = dateValueFromSerial(serial);
    if (startShiftForDate(dateValue, "day") === target) count += 1;
    if (startShiftForDate(dateValue, "night") === target) count += 1;
  }
  return count;
}

function statsTotals(entries, rows = buildStatsRows(entries), range = null) {
  const totalPeople = new Set(entries.map((entry) => entry.tab ? `tab:${entry.tab}` : `name:${normalizeName(entry.name)}`)).size;
  const scheduledShifts = scheduledShiftCountForRange(range);
  const totalShifts = range?.start && range?.end
    ? scheduledShifts
    : new Set(entries.map((entry) => entry.date).filter(Boolean)).size;
  const totalHours = Number(entries.reduce((sum, entry) => sum + Number(entry.hours || hoursForKind(entry.shiftKind, entry.shiftCount || 1)), 0).toFixed(1));
  const totalNominalHours = Number(rows.reduce((sum, row) => sum + row.nominalHours, 0).toFixed(1));
  const totalFinalBalanceHours = Number(rows.reduce((sum, row) => sum + row.finalBalanceHours, 0).toFixed(1));
  const totalLowPayLossHours = Number(rows.reduce((sum, row) => sum + row.lowPayLossHours, 0).toFixed(1));
  const totalRepairLossHours = Number(rows.reduce((sum, row) => sum + row.repairLossHours, 0).toFixed(1));
  const totalWarmupLossHours = Number(rows.reduce((sum, row) => sum + row.warmupLossHours, 0).toFixed(1));
  const totalWithoutProletchikHours = Number(rows.reduce((sum, row) => sum + row.withoutProletchikHours, 0).toFixed(1));
  const totalWithoutCapitalRepairHours = Number(rows.reduce((sum, row) => sum + row.withoutCapitalRepairHours, 0).toFixed(1));
  const totalProletchikHours = Number(rows.reduce((sum, row) => sum + row.proletchikHours, 0).toFixed(1));
  const totalCapitalRepairHours = Number(rows.reduce((sum, row) => sum + row.capitalRepairHours, 0).toFixed(1));
  const repairEntries = entries.filter((entry) => entryOrdinaryShiftKind(entry, "repair"));
  const warmupEntries = entries.filter((entry) => entryOrdinaryShiftKind(entry, "warmup"));
  const averageEntries = entries.filter((entry) => entryOrdinaryShiftKind(entry, "average"));
  const proletchikEntries = entries.filter((entry) => normalizedSpecialRole(entry) === "proletchik");
  const capitalRepairEntries = entries.filter((entry) => normalizedSpecialRole(entry) === "capitalRepair");
  const workerKey = (entry) => entry.tab ? `tab:${entry.tab}` : `name:${normalizeName(entry.name)}`;
  const groupedShiftCount = (list) => {
    const groups = new Map();
    list.forEach((entry) => {
      const key = [
        entry.date || "",
        statsPlaceKey(entry.actualPlace),
        entry.shiftKind || "",
      ].join("|");
      groups.set(key, Math.max(groups.get(key) || 0, Number(entry.shiftCount || 1)));
    });
    return [...groups.values()].reduce((sum, count) => sum + count, 0);
  };
  const repairShifts = groupedShiftCount(repairEntries);
  const warmupShifts = groupedShiftCount(warmupEntries);
  const averageShifts = groupedShiftCount(averageEntries);
  const repairHours = Number(repairEntries.reduce((sum, entry) => sum + statsHoursForEntry(entry), 0).toFixed(1));
  const warmupHours = Number(warmupEntries.reduce((sum, entry) => sum + statsHoursForEntry(entry), 0).toFixed(1));
  const averageHours = Number(averageEntries.reduce((sum, entry) => sum + statsHoursForEntry(entry), 0).toFixed(1));
  const repairPeople = new Set(repairEntries.map(workerKey)).size;
  const warmupPeople = new Set(warmupEntries.map(workerKey)).size;
  const averagePeople = new Set(averageEntries.map(workerKey)).size;
  const proletchikShifts = proletchikEntries.reduce((sum, entry) => sum + Number(entry.shiftCount || 1), 0);
  const capitalRepairShifts = capitalRepairEntries.reduce((sum, entry) => sum + Number(entry.shiftCount || 1), 0);
  const proletchikPeople = new Set(proletchikEntries.map(workerKey)).size;
  const capitalRepairPeople = new Set(capitalRepairEntries.map(workerKey)).size;
  return {
    totalPeople,
    totalShifts,
    totalHours,
    totalNominalHours,
    totalFinalBalanceHours,
    totalLowPayLossHours,
    totalRepairLossHours,
    totalWarmupLossHours,
    totalWithoutProletchikHours,
    totalWithoutCapitalRepairHours,
    totalProletchikHours,
    totalCapitalRepairHours,
    repairShifts,
    warmupShifts,
    repairHours,
    warmupHours,
    repairPeople,
    warmupPeople,
    averageShifts,
    averageHours,
    averagePeople,
    proletchikShifts,
    capitalRepairShifts,
    proletchikPeople,
    capitalRepairPeople,
  };
}

function statsHoursForEntry(entry) {
  return Number(entry.hours || hoursForKind(entry.shiftKind, entry.shiftCount || 1) || 0);
}

function formatRuNumber(value) {
  const num = Number(value || 0);
  return Number.isInteger(num) ? String(num) : String(Number(num.toFixed(1))).replace(".", ",");
}

function pluralRu(value, one, few, many) {
  const num = Math.abs(Number(value || 0));
  if (!Number.isInteger(num)) return few;
  const mod10 = num % 10;
  const mod100 = num % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return few;
  return many;
}

function formatStatsWorkSummary(shifts, hours, people) {
  return `${formatRuNumber(shifts)} ${pluralRu(shifts, "смена", "смены", "смен")} / ${formatRuNumber(hours)} ${pluralRu(hours, "час", "часа", "часов")} / ${formatRuNumber(people)} ${pluralRu(people, "человек", "человека", "человек")}`;
}

function emptyPlaceHourBreakdown(place) {
  return {
    place,
    grades: new Map(),
    gradePeople: new Map(),
    proletchik: 0,
    subworker: 0,
    capitalRepair: 0,
    specialRoles: new Map(),
    repair: 0,
    warmup: 0,
    average: 0,
    total: 0,
  };
}

function buildPlaceHourBreakdown(entries) {
  const order = [...FURNACES.map((code) => `Печь ${code}`), "Разливочные машины"];
  const groups = new Map(order.map((place) => [place, emptyPlaceHourBreakdown(place)]));

  for (const entry of entries) {
    const place = statsPlaceKey(entry.actualPlace);
    if (!groups.has(place)) groups.set(place, emptyPlaceHourBreakdown(place));
    const row = groups.get(place);
    const hours = statsHoursForEntry(entry);
    row.total = Number((row.total + hours).toFixed(1));
    const grade = String(entry.actualGrade || "");
    if (grade) {
      row.grades.set(grade, Number(((row.grades.get(grade) || 0) + hours).toFixed(1)));
      const people = row.gradePeople.get(grade) || new Set();
      people.add(entry.tab ? `tab:${entry.tab}` : `name:${normalizeName(entry.name)}`);
      row.gradePeople.set(grade, people);
    }

    const specialRole = normalizedSpecialRole(entry);
    if (specialRole === "proletchik") {
      row.proletchik = Number((row.proletchik + hours).toFixed(1));
    } else if (specialRole === "subworker") {
      row.subworker = Number((row.subworker + hours).toFixed(1));
    } else if (specialRole === "capitalRepair") {
      row.capitalRepair = Number((row.capitalRepair + hours).toFixed(1));
    } else if (normalizeCustomSpecialRoleId(specialRole)) {
      row.specialRoles.set(specialRole, Number(((row.specialRoles.get(specialRole) || 0) + hours).toFixed(1)));
    } else if (entry.shiftKind === "repair") {
      row.repair = Number((row.repair + hours).toFixed(1));
    } else if (entry.shiftKind === "warmup") {
      row.warmup = Number((row.warmup + hours).toFixed(1));
    } else if (entry.shiftKind === "average") {
      row.average = Number((row.average + hours).toFixed(1));
    }
  }

  return [...groups.values()]
    .filter((row) => row.total || row.proletchik || row.subworker || row.capitalRepair || row.specialRoles.size || row.repair || row.warmup || row.average || row.grades.size)
    .sort((a, b) => {
      const aIndex = order.indexOf(a.place);
      const bIndex = order.indexOf(b.place);
      return (aIndex === -1 ? 99 : aIndex) - (bIndex === -1 ? 99 : bIndex) || a.place.localeCompare(b.place, "ru");
    });
}

function formatHours(value) {
  const number = Number(value || 0);
  return formatRuNumber(number);
}

function formatHoursText(value) {
  return `${formatHours(value)} ${pluralRu(value, "час", "часа", "часов")}`;
}

function statsGradePeopleCount(row, grade) {
  return row.gradePeople.get(String(grade))?.size || 0;
}

function statsGradeLineDanger(row, grade) {
  const textGrade = String(grade);
  const people = statsGradePeopleCount(row, textGrade);
  const code = String(placeCode(row.place) || "");
  if (FURNACES.includes(code)) {
    if (textGrade === "7") return people < 1;
    if (textGrade === "6") return people < 2;
  }
  if (row.place === "Разливочные машины" && textGrade === "4") return people < 4;
  return false;
}

function statsRequiredGrades(row) {
  const code = String(placeCode(row.place) || "");
  if (FURNACES.includes(code)) return ["7", "6", "5"];
  if (row.place === "Разливочные машины") return ["4", "3"];
  return [];
}

function renderPlaceHourRows(row) {
  const gradeKeys = [...new Set([...statsRequiredGrades(row), ...row.grades.keys()])];
  const gradeRows = gradeKeys
    .sort((a, b) => Number(b) - Number(a))
    .map((grade) => {
      const hours = row.grades.get(grade) || 0;
      const dangerClass = statsGradeLineDanger(row, grade) ? " danger" : "";
      return `
      <div class="stats-line${dangerClass}">
        <span>${escapeHtml(grade)} разряд</span>
        <strong>${formatHoursText(hours)}</strong>
      </div>
    `;
    }).join("");

  const settings = appSettings();
  const customRoleHours = row.specialRoles instanceof Map ? row.specialRoles : new Map();
  const roleHours = new Map([
    ["proletchik", Number(row.proletchik || 0)],
    ["subworker", Number(row.subworker || 0)],
    ["capitalRepair", Number(row.capitalRepair || 0)],
    ...[...customRoleHours.entries()].map(([roleId, hours]) => [roleId, Number(hours || 0)]),
  ]);
  const activeRoleIds = specialRoleDefinitionsForWorkplace(row.place, settings).map((role) => role.id);
  const historicalRoleIds = [...roleHours.entries()].filter(([, hours]) => hours !== 0).map(([roleId]) => roleId);
  const relevantRoleIds = new Set([...activeRoleIds, ...historicalRoleIds]);
  const roleDefinitions = specialRoleDefinitionsForIds([...relevantRoleIds], settings)
    .filter((role) => relevantRoleIds.has(role.id) && statsRoleIncluded(role.id, settings));
  const specialRows = [
    ...roleDefinitions.map((role) => [role.name, roleHours.get(role.id) || 0, role.statsType]),
    settings.statsIncludeRepair !== false ? ["Ремонт", row.repair, "", "stats-repair-line"] : null,
    settings.statsIncludeWarmup !== false ? ["Разогрев", row.warmup] : null,
    ["По среднему", row.average],
  ].filter(Boolean).filter(([, hours]) => settings.statsShowZeroRows !== false || Number(hours) !== 0).map(([label, hours, roleType = "", rowClass = ""]) => {
    const roleRowClass = roleType && Number(hours) > 0 ? statsRoleClass(roleType) : "";
    const hoursClass = roleType && Number(hours) > 0
      ? ` class="stats-special-hours${statsRoleClass(roleType)}"`
      : "";
    const roleStyle = roleType && Number(hours) > 0 ? specialRoleStyleAttribute(roleType) : "";
    const rowClassName = rowClass ? ` ${escapeHtml(rowClass)}` : "";
    return `
    <div class="stats-line${roleRowClass}${rowClassName}"${roleStyle}>
      <span>${escapeHtml(label)}</span>
      <strong${hoursClass}${roleStyle}>${formatHoursText(hours)}</strong>
    </div>
  `;
  }).join("");

  return `
    ${gradeRows || `<div class="stats-line muted"><span>Разряды</span><strong>${formatHoursText(0)}</strong></div>`}
    ${specialRows}
    <div class="stats-line total">
      <span>Итого</span>
      <strong>${formatHoursText(row.total)}</strong>
    </div>
  `;
}

function renderPlaceHourPanel(title, entries, subtitle = "") {
  const rows = buildPlaceHourBreakdown(entries);
  const totalHours = Number(rows.reduce((sum, row) => sum + row.total, 0).toFixed(1));
  const settings = appSettings();
  return `
    <section class="stats-place-panel">
      <div class="stats-place-title">
        <div>
          <strong>${escapeHtml(title)}</strong>
          ${subtitle ? `<span>${escapeHtml(subtitle)}</span>` : ""}
        </div>
        <b>${formatHoursText(totalHours)}</b>
      </div>
      <div class="stats-place-grid">
        ${rows.length ? rows.map((row) => {
          const workplaceDepartment = configuredDepartmentForWorkplace(row.place, settings);
          const workplaceColor = configuredWorkplaceColor(row.place, settings);
          const workplaceTextColor = structureColorText(workplaceColor);
          return `
          <article class="stats-place-card has-structure-color" data-department-id="${escapeHtml(workplaceDepartment?.id || "")}" style="--stats-workplace-color:${escapeHtml(workplaceColor)};--stats-workplace-text:${escapeHtml(workplaceTextColor)}">
            <h3>${escapeHtml(row.place)}</h3>
            ${renderPlaceHourRows(row)}
          </article>`;
        }).join("") : `<div class="absent-empty">Данные по рабочим местам ещё не внесены.</div>`}
      </div>
    </section>
  `;
}

function statsSelectedMonthDate() {
  const fallbackDate = $("statsDateInput")?.value || $("dateInput")?.value || dateInputValue(new Date());
  return `${fallbackDate.slice(0, 7)}-01`;
}

function statsEffectiveMonthRange() {
  const range = statsDateRange("month", statsSelectedMonthDate());
  const selectedDate = $("statsDateInput")?.value || $("dateInput")?.value || range.end;
  const end = selectedDate.startsWith(range.start.slice(0, 7)) && selectedDate < range.end ? selectedDate : range.end;
  return { ...range, end };
}

function statsShiftAnchorDate() {
  return $("statsDateInput")?.value || $("dateInput")?.value || selectedShiftDate() || dateInputValue(new Date());
}

function statsShiftChoices(anchorDate = statsShiftAnchorDate(), brigade = currentBrigade()) {
  if (!anchorDate) return [];
  const targetBrigade = String(brigade || currentBrigade());
  const monthStart = `${anchorDate.slice(0, 7)}-01`;
  const anchorKind = selectedShiftKindForDate(anchorDate);
  const anchorSerial = shiftSerial(anchorDate, anchorKind);
  const choices = [];

  for (let serial = dateSerial(monthStart); serial <= dateSerial(anchorDate); serial += 1) {
    const date = dateValueFromSerial(serial);
    for (const kind of ["day", "night"]) {
      if (shiftSerial(date, kind) > anchorSerial || startShiftForDate(date, kind) !== targetBrigade) continue;
      choices.push({ date, kind });
    }
  }

  choices.sort((a, b) => shiftSerial(a.date, a.kind) - shiftSerial(b.date, b.kind));
  return choices.map((choice) => ({
    ...choice,
    current: shiftSerial(choice.date, choice.kind) === anchorSerial,
    label: `${formatDate(choice.date)} · ${choice.kind === "night" ? "Ночь" : "День"} · ${shiftSerial(choice.date, choice.kind) === anchorSerial ? "текущая" : "отработана"}`,
  }));
}

function statsEntriesInRange(range) {
  return currentEntries().filter((entry) =>
    entry.date >= range.start
    && entry.date <= range.end
    && brigadeWorksOnDate(entry.date, itemBrigade(entry))
    && statsEntryVisible(entry)
    && statsItemMatchesHierarchy(entry)
  );
}

function statsEmployeeKey(item) {
  return item?.tab ? `tab:${item.tab}` : `name:${normalizeName(item?.name)}`;
}

function statsEmployeeChoices(monthEntries) {
  const grouped = new Map();
  (monthEntries || []).forEach((item) => {
    const key = statsEmployeeKey(item);
    if (!key || key === "name:") return;
    const current = grouped.get(key) || {};
    grouped.set(key, {
      ...current,
      ...item,
      name: item.name || current.name || "",
      tab: item.tab || current.tab || "",
      place: item.place || item.actualPlace || current.place || "",
      grade: item.grade || item.actualGrade || current.grade || "",
    });
  });
  activeEmployeesForBrigade(currentBrigade()).forEach((employee) => {
    const key = statsEmployeeKey(employee);
    if (!key || key === "name:") return;
    const history = grouped.get(key) || {};
    grouped.set(key, {
      ...history,
      ...employee,
      name: employee.name || history.name || "",
      tab: employee.tab || history.tab || "",
      place: employee.place || history.place || history.actualPlace || "",
      grade: employee.grade ?? history.grade ?? history.actualGrade ?? "",
    });
  });
  return [...grouped.values()]
    .filter(statsItemMatchesHierarchy)
    .sort((a, b) => String(a.name || "").localeCompare(String(b.name || ""), "ru"));
}

function renderStatsEmployeeSelect(monthEntries) {
  const select = $("statsEmployeeInput");
  if (!select) return "";
  const previous = select.value;
  const employees = statsEmployeeChoices(monthEntries);
  select.innerHTML = employees.map((employee) => `
    <option value="${escapeHtml(statsEmployeeKey(employee))}">${escapeHtml(employee.name)}${employee.tab ? ` · ${escapeHtml(employee.tab)}` : ""}</option>
  `).join("");
  if (employees.some((employee) => statsEmployeeKey(employee) === previous)) select.value = previous;
  return select.value;
}

function setStatsMode(mode) {
  statsMode = ["month", "shift", "employee", "sick", "proletchik", "subworker", "capital-repair"].includes(mode) ? mode : "month";
  renderStats();
}

function renderStatsModeControls() {
  if ($("statsModeSelect")) $("statsModeSelect").value = statsMode;
  $("statsEmployeeField")?.classList.toggle("hidden", statsMode !== "employee");
  const titles = {
    month: ["Общая статистика за месяц", "Сводные показатели выбранной бригады за месяц."],
    shift: ["Статистика по сменам", "Состав и человеко-часы за выбранную смену."],
    employee: ["Индивидуальная статистика за месяц", "Смены и часы выбранного сотрудника за месяц."],
    sick: ["Больничный за месяц", "Сотрудники и смены на больничном за выбранный месяц."],
    proletchik: ["Пролётчик за месяц", "Сотрудники, смены и часы по работе пролётчика."],
    subworker: ["Подработчик за месяц", "Сотрудники, смены и часы по подработке."],
    "capital-repair": ["Капремонт за месяц", "Сотрудники, смены и часы по капремонту."],
  };
  const [title, subtitle] = titles[statsMode];
  if ($("statsViewTitle")) $("statsViewTitle").textContent = title;
  if ($("statsViewSubtitle")) $("statsViewSubtitle").textContent = subtitle;
}

function statsSummaryCardsMarkup(items) {
  return items.map(([label, value]) => `<div class="summary-card">${escapeHtml(label)}<strong>${escapeHtml(value)}</strong></div>`).join("");
}

function statsWorkerKey(entry) {
  return entry?.tab ? `tab:${entry.tab}` : `name:${normalizeName(entry?.name)}`;
}

function statsRoleType(entry) {
  const role = normalizedSpecialRole(entry);
  if (role === "capitalRepair") return "capital-repair";
  if (role === "proletchik" || role === "subworker" || normalizeCustomSpecialRoleId(role)) return role;
  return "";
}

function statsRoleLabel(type) {
  const role = type === "capital-repair" ? "capitalRepair" : type;
  return specialWorkLabel(role, normalizeCustomSpecialRoleId(role) ? "Специальная работа" : "");
}

function statsRoleClass(type) {
  if (normalizeCustomSpecialRoleId(type)) return " stats-role-custom";
  return ["proletchik", "capital-repair", "subworker"].includes(type) ? ` stats-role-${type}` : "";
}

function statsRoleId(type) {
  return type === "capital-repair" ? "capitalRepair" : canonicalSpecialRoleId(type);
}

function statsRoleIncluded(roleValue, settings = appSettings()) {
  const roleId = canonicalSpecialRoleId(roleValue);
  if (roleId === "proletchik") return settings.statsIncludeProletchik !== false;
  if (roleId === "capitalRepair") return settings.statsIncludeCapitalRepair !== false;
  if (roleId === "subworker") return settings.statsIncludeSubworkers !== false;
  return Boolean(normalizeCustomSpecialRoleId(roleId));
}

function statsRoleDefinitionsForEntries(entries, settings = appSettings()) {
  const departmentIds = new Set();
  if (selectedStatsDepartmentId) departmentIds.add(selectedStatsDepartmentId);
  if (!selectedStatsDepartmentId) {
    (entries || []).forEach((entry) => {
      const departmentId = String(entry?.departmentId || configuredDepartmentIdForWorkplace(entry?.actualPlace, settings) || "");
      if (departmentId) departmentIds.add(departmentId);
    });
  }
  if (!departmentIds.size) (settings.departments || []).forEach((department) => departmentIds.add(department.id));
  const relevantRoleIds = new Set();
  departmentIds.forEach((departmentId) => {
    specialRoleDefinitionsForDepartment(departmentId, settings).forEach((role) => relevantRoleIds.add(role.id));
  });
  (entries || []).forEach((entry) => {
    const roleId = statsRoleId(statsRoleType(entry));
    if (roleId) relevantRoleIds.add(roleId);
  });
  return specialRoleDefinitionsForIds([...relevantRoleIds], settings)
    .filter((role) => relevantRoleIds.has(role.id) && statsRoleIncluded(role.id, settings));
}

function statsCustomRoleTypes(entries, settings = appSettings()) {
  return statsRoleDefinitionsForEntries(entries, settings)
    .filter((role) => normalizeCustomSpecialRoleId(role.id))
    .map((role) => role.statsType);
}

function statsRoleTypes(entries, settings = appSettings()) {
  return statsRoleDefinitionsForEntries(entries, settings).map((role) => role.statsType);
}

function statsCoverageRequirements(place) {
  if (appSettings().showMinimumStaffingWarnings === false) return [];
  const gradeRequirements = Object.entries(workplaceGradeRuleSet(place))
    .filter(([, rule]) => Number(rule.minimum || 0) > 0)
    .map(([grade, rule]) => ({ type: "grade", key: grade, grade, minimum: Number(rule.minimum), label: `${grade} разряд` }))
    .sort((a, b) => Number(b.grade) - Number(a.grade));
  const specialRequirements = Object.entries(workplaceSpecialRuleSet(place))
    .filter(([, rule]) => Number(rule.minimum || 0) > 0)
    .map(([role, rule]) => ({
      type: "role",
      key: role,
      grade: role,
      minimum: Number(rule.minimum),
      label: specialWorkLabel(role, role),
    }));
  return [...gradeRequirements, ...specialRequirements];
}

function buildStatsCoverageReport(entries) {
  const groups = new Map();
  (entries || []).forEach((entry) => {
    const place = statsPlaceKey(entry.actualPlace);
    const requirements = statsCoverageRequirements(place);
    if (!requirements.length || !entry.date) return;
    const key = `${entry.date}|${place}`;
    if (!groups.has(key)) {
      groups.set(key, {
        date: entry.date,
        place,
        requirements,
        grades: new Map(),
        roles: new Map(),
      });
    }
    const group = groups.get(key);
    const grade = String(entry.actualGrade || "");
    if (grade) {
      const people = group.grades.get(grade) || new Set();
      people.add(statsWorkerKey(entry));
      group.grades.set(grade, people);
    }
    const role = normalizedSpecialRole(entry);
    if (role) {
      const people = group.roles.get(role) || new Set();
      people.add(statsWorkerKey(entry));
      group.roles.set(role, people);
    }
  });

  const checks = [];
  groups.forEach((group) => {
    group.requirements.forEach((requirement) => {
      const actual = requirement.type === "role"
        ? group.roles.get(requirement.key)?.size || 0
        : group.grades.get(requirement.key)?.size || 0;
      checks.push({
        date: group.date,
        place: group.place,
        grade: requirement.grade,
        label: requirement.label,
        actual,
        minimum: requirement.minimum,
        missing: Math.max(0, requirement.minimum - actual),
        ok: actual >= requirement.minimum,
      });
    });
  });
  checks.sort((a, b) => b.date.localeCompare(a.date) || a.place.localeCompare(b.place, "ru"));
  return {
    checks,
    issues: checks.filter((check) => !check.ok),
    okCount: checks.filter((check) => check.ok).length,
  };
}

function buildStatsRoleBalance(entries, roleType) {
  const groups = new Map();
  (entries || []).forEach((entry) => {
    if (statsRoleType(entry) !== roleType) return;
    const key = statsWorkerKey(entry);
    const row = groups.get(key) || {
      key,
      name: entry.name || "Без ФИО",
      tab: entry.tab || "",
      shifts: 0,
      hours: 0,
      dates: new Set(),
    };
    row.shifts += Number(entry.shiftCount || 1);
    row.hours += statsHoursForEntry(entry);
    if (entry.date) row.dates.add(entry.date);
    groups.set(key, row);
  });
  const rows = [...groups.values()].map((row) => ({
    ...row,
    shifts: Number(row.shifts.toFixed(1)),
    hours: Number(row.hours.toFixed(1)),
    dates: [...row.dates].sort(),
  })).sort((a, b) => a.shifts - b.shifts || a.hours - b.hours || a.name.localeCompare(b.name, "ru"));
  const counts = rows.map((row) => row.shifts);
  return {
    rows,
    minimum: counts.length ? Math.min(...counts) : 0,
    maximum: counts.length ? Math.max(...counts) : 0,
    spread: counts.length ? Math.max(...counts) - Math.min(...counts) : 0,
  };
}

function renderStatsCoveragePanel(entries, title = "Комплектация рабочих мест") {
  const report = buildStatsCoverageReport(entries);
  const statusClass = report.issues.length ? "danger" : "ok";
  const statusText = report.checks.length
    ? (report.issues.length ? `${report.issues.length} ${pluralRu(report.issues.length, "нарушение", "нарушения", "нарушений")}` : "Нормы соблюдены")
    : "Нет смен для проверки";
  return `
    <section class="stats-operational-section stats-coverage-section">
      <div class="stats-operational-head">
        <div>
          <h3>${escapeHtml(title)}</h3>
          <p>Минимальная комплектация проверяется по правилам выбранных рабочих мест.</p>
        </div>
        <span class="stats-health-badge ${statusClass}">${escapeHtml(statusText)}</span>
      </div>
      <div class="stats-coverage-list">
        ${report.issues.length ? report.issues.map((check) => `
          <div class="stats-coverage-row danger">
            <div>
              <strong>${escapeHtml(check.place)}</strong>
              <span>${escapeHtml(formatDate(check.date))}</span>
            </div>
            <div>
              <b>${escapeHtml(check.label)}: ${check.actual} из ${check.minimum}</b>
              <span>Не хватает ${check.missing} ${pluralRu(check.missing, "работника", "работников", "работников")}</span>
            </div>
          </div>
        `).join("") : `
          <div class="stats-coverage-empty ${statusClass}">
            ${report.checks.length ? "Все проверенные рабочие места укомплектованы по норме." : "После заполнения смен здесь появится контроль разрядов."}
          </div>
        `}
      </div>
    </section>
  `;
}

function renderStatsBalanceList(balance, roleType) {
  const maximum = Math.max(1, balance.maximum);
  if (!balance.rows.length) {
    return `<div class="stats-balance-empty">Назначений пока нет.</div>`;
  }
  return balance.rows.map((row, index) => {
    const width = Math.max(8, Math.round((row.shifts / maximum) * 100));
    return `
      <div class="stats-balance-row${statsRoleClass(roleType)}"${specialRoleStyleAttribute(roleType)}>
        <div class="stats-balance-person">
          <strong>${escapeHtml(row.name)}</strong>
          <span>${row.tab ? `Таб. № ${escapeHtml(row.tab)} · ` : ""}${formatRuNumber(row.shifts)} ${pluralRu(row.shifts, "смена", "смены", "смен")} · ${escapeHtml(formatHoursText(row.hours))}</span>
        </div>
        <div class="stats-balance-meter" aria-label="${escapeHtml(`${row.shifts} смен`)}">
          <span style="width:${width}%"></span>
        </div>
        ${index === 0 && balance.spread > 0 ? `<em>меньше всех</em>` : ""}
      </div>
    `;
  }).join("");
}

function renderStatsRoleBalancePanel(entries) {
  const settings = appSettings();
  const sections = statsRoleTypes(entries, settings).map((type) => [type, statsRoleLabel(type)]);
  return `
    <section class="stats-operational-section stats-balance-section">
      <div class="stats-operational-head">
        <div>
          <h3>Равномерность специальных работ</h3>
          <p>Сотрудники отсортированы от меньшего количества смен к большему.</p>
        </div>
      </div>
      <div class="stats-balance-columns">
        ${sections.map(([type, label]) => {
          const balance = buildStatsRoleBalance(entries, type);
          return `
            <section class="stats-balance-column">
              <div class="stats-balance-title${statsRoleClass(type)}"${specialRoleStyleAttribute(type)}>
                <strong>${escapeHtml(label)}</strong>
                <span>Разница: ${formatRuNumber(balance.spread)} ${pluralRu(balance.spread, "смена", "смены", "смен")}</span>
              </div>
              <div class="stats-balance-list">${renderStatsBalanceList(balance, type)}</div>
            </section>
          `;
        }).join("")}
      </div>
    </section>
  `;
}

function statsRoleLegendCount(entries, type, countBy = "people") {
  const matching = (entries || []).filter((entry) => statsRoleType(entry) === type);
  if (countBy !== "shifts") {
    return new Set(matching
      .map(statsWorkerKey)
      .filter((key) => key && key !== "name:")
    ).size;
  }
  const assignments = new Map();
  matching.forEach((entry, index) => {
    const worker = statsWorkerKey(entry);
    const date = String(entry.date || "");
    const fallback = String(entry.id || entry.sourceProletchikId || entry.sourceCapitalRepairId || index);
    const key = date ? `${worker}|${date}` : `entry:${fallback}`;
    assignments.set(key, Math.max(assignments.get(key) || 0, Number(entry.shiftCount || 1)));
  });
  return Number([...assignments.values()].reduce((sum, count) => sum + count, 0).toFixed(1));
}

function renderStatsRoleLegend(entries, countBy = "people") {
  const settings = appSettings();
  const types = statsRoleTypes(entries, settings);
  const countLabel = (count) => countBy === "shifts"
    ? `${formatRuNumber(count)} ${pluralRu(count, "смена", "смены", "смен")}`
    : `${formatRuNumber(count)} чел.`;
  return `
    <div class="stats-role-legend" aria-label="${countBy === "shifts" ? "Количество специальных смен" : "Количество сотрудников по специальным работам"}">
      ${types.map((type) => {
        const count = statsRoleLegendCount(entries, type, countBy);
        return `
        <span class="${statsRoleClass(type).trim()}"${specialRoleStyleAttribute(type)}><i></i>${escapeHtml(statsRoleLabel(type))}: ${escapeHtml(countLabel(count))}</span>
      `;
      }).join("")}
    </div>
  `;
}

function statsCompactSummaryItems(scopeLabel, totals, entries) {
  const coverage = buildStatsCoverageReport(entries);
  return [
    ["Период", scopeLabel],
    ["Смен", totals.totalShifts],
    ["Работников", totals.totalPeople],
    ["Часов", formatHoursText(totals.totalHours)],
    ["Нарушений норм", coverage.issues.length],
  ];
}

function statsTeamSummaryItems(scopeLabel, totals) {
  const settings = appSettings();
  const hierarchy = selectedStatsHierarchy();
  return [
    ["Бригада", currentBrigade()],
    ["Цех", hierarchy.departmentName],
    ["Участок", hierarchy.sectionName],
    ["Рабочее место", hierarchy.placeName],
    ["Период", scopeLabel],
    ["Людей", totals.totalPeople],
    ["Смен", totals.totalShifts],
    ["Фактически часов", formatHoursText(totals.totalHours)],
    ["Если без ремонта/разогрева", formatHoursText(totals.totalNominalHours)],
    ["Потеря ремонта", formatHoursText(totals.totalRepairLossHours)],
    ["Потеря разогрева", formatHoursText(totals.totalWarmupLossHours)],
    ["Итог зачётных часов", formatHoursText(totals.totalFinalBalanceHours)],
    settings.statsIncludeProletchik !== false ? ["Без пролётчика", formatHoursText(totals.totalWithoutProletchikHours)] : null,
    settings.statsIncludeCapitalRepair !== false ? ["Без капремонта", formatHoursText(totals.totalWithoutCapitalRepairHours)] : null,
    settings.statsIncludeCapitalRepair !== false ? ["Капремонт", formatStatsWorkSummary(totals.capitalRepairShifts, totals.totalCapitalRepairHours, totals.capitalRepairPeople)] : null,
    settings.statsIncludeProletchik !== false ? ["Пролётчик", formatStatsWorkSummary(totals.proletchikShifts, totals.totalProletchikHours, totals.proletchikPeople)] : null,
    ["По среднему", formatStatsWorkSummary(totals.averageShifts, totals.averageHours, totals.averagePeople)],
    settings.statsIncludeRepair !== false ? ["Ремонт", formatStatsWorkSummary(totals.repairShifts, totals.repairHours, totals.repairPeople)] : null,
    settings.statsIncludeWarmup !== false ? ["Разогрев", formatStatsWorkSummary(totals.warmupShifts, totals.warmupHours, totals.warmupPeople)] : null,
  ].filter(Boolean);
}

function renderStatsHiddenTable(rows, emptyText) {
  const tbody = $("statsTable")?.querySelector("tbody");
  if (!tbody) return;
  tbody.innerHTML = rows.length ? rows.map((row) => `
    <tr>
      <td>${escapeHtml(row.place)}</td>
      <td>${row.people}</td>
      <td>${row.shifts}</td>
      <td>${row.finalBalanceHours}</td>
      <td>${row.repair}</td>
      <td>${row.warmup}</td>
      <td>${row.proletchik + row.capitalRepair}</td>
    </tr>
  `).join("") : `<tr><td colspan="7" class="empty-cell">${escapeHtml(emptyText)}</td></tr>`;
}

function renderMonthlyStats() {
  const range = statsEffectiveMonthRange();
  const entries = statsEntriesInRange(range);
  const rows = buildStatsRows(entries);
  const totals = statsTotals(entries, rows, range);
  $("statsSummaryCards").innerHTML = statsSummaryCardsMarkup(statsCompactSummaryItems(range.label, totals, entries));
  $("statsMonthlyBreakdown").innerHTML = renderStatsCoveragePanel(entries);
  $("statsChart").innerHTML = `
    ${renderStatsRoleLegend(entries)}
    ${renderStatsRoleBalancePanel(entries)}
  `;
  $("statsWorkplaceCards").innerHTML = renderPlaceHourPanel(
    `${range.label}, бригада ${currentBrigade()}`,
    entries,
    `Часы по рабочим местам с ${formatDate(range.start)} по ${formatDate(range.end)}`
  );
  renderStatsHiddenTable(rows, "За выбранный месяц смены ещё не внесены.");
}

function renderShiftStats() {
  const choices = statsShiftChoices();
  const monthRange = statsEffectiveMonthRange();
  const monthEntries = statsEntriesInRange(monthRange);
  const monthRows = buildStatsRows(monthEntries);
  const monthTotals = statsTotals(monthEntries, monthRows, monthRange);
  const coverage = buildStatsCoverageReport(monthEntries);

  $("statsSummaryCards").innerHTML = statsSummaryCardsMarkup([
    ["Период", monthRange.label],
    ["Смен", choices.length],
    ["Работников", monthTotals.totalPeople],
    ["Часов", formatHoursText(monthTotals.totalHours)],
    ["Нарушений норм", coverage.issues.length],
  ]);
  $("statsMonthlyBreakdown").innerHTML = "";
  $("statsChart").innerHTML = renderStatsRoleLegend(monthEntries);
  $("statsWorkplaceCards").innerHTML = choices.length
    ? `<div class="stats-shift-timeline">${choices.map((choice) => {
        const range = statsDateRange("shift", choice.date);
        const entries = statsEntriesInRange(range);
        const rows = buildStatsRows(entries);
        const totals = statsTotals(entries, rows, range);
        const shiftLabel = choice.kind === "night" ? "Ночная смена" : "Дневная смена";
        return `
          <article class="stats-shift-timeline-item${choice.current ? " current" : ""}">
            <div class="stats-shift-timeline-head">
              <div>
                <strong>${escapeHtml(formatDate(choice.date))}, бригада ${escapeHtml(currentBrigade())}</strong>
                <span>${escapeHtml(shiftLabel)}${choice.current ? " · текущая" : ""}</span>
              </div>
              <div class="stats-shift-timeline-metrics">
                <b>${totals.totalPeople} ${pluralRu(totals.totalPeople, "работник", "работника", "работников")}</b>
                <b>${escapeHtml(formatHoursText(totals.totalHours))}</b>
              </div>
            </div>
            ${renderStatsCoveragePanel(entries, `Комплектация смены ${formatDate(choice.date)}`)}
            ${renderStatsRoleLegend(entries)}
            ${renderPlaceHourPanel(
              `${formatDate(choice.date)}, бригада ${currentBrigade()}`,
              entries,
              shiftLabel
            )}
          </article>
        `;
      }).join("")}</div>`
    : `<div class="absent-empty">В выбранном месяце у бригады нет смен по графику.</div>`;
  renderStatsHiddenTable(monthRows, "За смены выбранного месяца записи ещё не внесены.");
}

function individualStatsSummary(employee, entries, range) {
  const shifts = new Set(entries.map((entry) => entry.date).filter(Boolean)).size;
  const hours = Number(entries.reduce((sum, entry) => sum + statsHoursForEntry(entry), 0).toFixed(1));
  return [
    ["ФИО", employee?.name || "Не выбран"],
    ["Период", range.label],
    ["Отработано смен", shifts],
    ["Отработано часов", formatHoursText(hours)],
  ].filter(Boolean);
}

function individualAbsences(employee, range, workedEntries = []) {
  if (!employee) return [];
  const key = statsEmployeeKey(employee);
  const workedDates = new Set(
    (workedEntries || [])
      .filter((entry) => statsEmployeeKey(entry) === key)
      .map((entry) => entry.date)
      .filter(Boolean)
  );
  const byDate = new Map();
  currentAbsences().filter((absence) =>
    absence.date >= range.start
    && absence.date <= range.end
    && statsEmployeeKey(absence) === key
    && Boolean(String(absence.reason || "").trim())
    && !workedDates.has(absence.date)
  ).forEach((absence) => {
    const existing = byDate.get(absence.date);
    if (!existing) {
      byDate.set(absence.date, absence);
      return;
    }
    const existingAutomatic = isAutomaticAbsence(existing);
    const automatic = isAutomaticAbsence(absence);
    if (
      (existingAutomatic && !automatic)
      || (existingAutomatic === automatic && syncItemTime(absence) >= syncItemTime(existing))
    ) {
      byDate.set(absence.date, absence);
    }
  });
  return [...byDate.values()].sort((a, b) => a.date.localeCompare(b.date));
}

function buildIndividualWorkplaces(entries) {
  const groups = new Map();
  (entries || []).forEach((entry) => {
    const place = statsPlaceKey(entry.actualPlace);
    const grade = String(entry.actualGrade || "не указан");
    const key = `${place}|${grade}`;
    const row = groups.get(key) || { place, grade, dates: new Set(), hours: 0, roles: new Set() };
    if (entry.date) row.dates.add(entry.date);
    row.hours += statsHoursForEntry(entry);
    const role = statsRoleType(entry);
    if (role) row.roles.add(role);
    groups.set(key, row);
  });
  return [...groups.values()].map((row) => ({
    ...row,
    shifts: row.dates.size,
    hours: Number(row.hours.toFixed(1)),
    roles: [...row.roles],
  })).sort((a, b) => b.shifts - a.shifts || a.place.localeCompare(b.place, "ru") || Number(b.grade) - Number(a.grade));
}

function buildIndividualAbsenceReasons(absences) {
  const groups = new Map();
  (absences || []).forEach((absence) => {
    const reason = String(absence.reason || "Причина не указана");
    const dates = groups.get(reason) || new Set();
    if (absence.date) dates.add(absence.date);
    groups.set(reason, dates);
  });
  return [...groups.entries()]
    .map(([reason, dates]) => ({ reason, shifts: dates.size, dates: [...dates].sort() }))
    .sort((a, b) => b.shifts - a.shifts || a.reason.localeCompare(b.reason, "ru"));
}

function sickLeaveAbsences(range) {
  const employeesByKey = new Map();
  [
    ...activeEmployeesForBrigade(currentBrigade()),
    ...currentEntries(),
    ...currentAbsences(),
  ].forEach((item) => {
    const key = statsEmployeeKey(item);
    if (!key || key === "name:") return;
    const current = employeesByKey.get(key) || {};
    employeesByKey.set(key, {
      ...current,
      ...item,
      name: item.name || current.name || "",
      tab: item.tab || current.tab || "",
      place: item.place || current.place || item.actualPlace || current.actualPlace || "",
      grade: item.grade ?? current.grade ?? item.actualGrade ?? current.actualGrade ?? "",
    });
  });

  const workedDates = new Set(
    currentEntries()
      .filter((entry) => entry.date >= range.start && entry.date <= range.end)
      .map((entry) => `${statsEmployeeKey(entry)}|${entry.date}`)
  );
  const byWorkerAndDate = new Map();

  currentAbsences()
    .filter((absence) =>
      absence.date >= range.start
      && absence.date <= range.end
      && normalizeName(absence.reason) === normalizeName("Больничный")
      && !workedDates.has(`${statsEmployeeKey(absence)}|${absence.date}`)
    )
    .forEach((absence) => {
      const employee = employeesByKey.get(statsEmployeeKey(absence)) || {};
      const enriched = {
        ...employee,
        ...absence,
        name: absence.name || employee.name || "",
        tab: absence.tab || employee.tab || "",
        place: absence.place || employee.place || employee.actualPlace || "",
        actualPlace: absence.actualPlace || absence.place || employee.place || employee.actualPlace || "",
        grade: absence.grade ?? employee.grade ?? employee.actualGrade ?? "",
      };
      if (!statsItemMatchesHierarchy(enriched)) return;
      const key = `${statsEmployeeKey(enriched)}|${enriched.date}`;
      const previous = byWorkerAndDate.get(key);
      if (!previous || syncItemTime(enriched) >= syncItemTime(previous)) byWorkerAndDate.set(key, enriched);
    });

  return [...byWorkerAndDate.values()].sort((a, b) =>
    String(a.name || "").localeCompare(String(b.name || ""), "ru")
    || String(a.date || "").localeCompare(String(b.date || ""))
  );
}

function buildSickLeaveRows(absences) {
  const groups = new Map();
  (absences || []).forEach((absence) => {
    const key = statsEmployeeKey(absence);
    if (!key || key === "name:") return;
    const row = groups.get(key) || {
      key,
      name: absence.name || "",
      tab: absence.tab || "",
      place: absence.place || absence.actualPlace || "Не указано",
      grade: absence.grade ?? absence.actualGrade ?? "",
      dates: new Set(),
    };
    if (absence.date) row.dates.add(absence.date);
    groups.set(key, row);
  });
  return [...groups.values()]
    .map((row) => ({ ...row, dates: [...row.dates].sort(), shifts: row.dates.size }))
    .sort((a, b) => b.shifts - a.shifts || a.name.localeCompare(b.name, "ru"));
}

function renderSickLeaveStats() {
  const range = statsEffectiveMonthRange();
  const absences = sickLeaveAbsences(range);
  const rows = buildSickLeaveRows(absences);
  const totalShifts = rows.reduce((sum, row) => sum + row.shifts, 0);

  $("statsSummaryCards").innerHTML = statsSummaryCardsMarkup([
    ["Период", range.label],
    ["Сотрудников", rows.length],
    ["Смен на больничном", totalShifts],
  ]);
  $("statsMonthlyBreakdown").innerHTML = `
    <section class="stats-operational-section stats-individual-summary">
      <div class="stats-operational-head">
        <div>
          <h3>Больничные за ${escapeHtml(range.label)}</h3>
          <p>Учитываются только подтверждённые больничные без фактически отработанной смены в ту же дату.</p>
        </div>
      </div>
      <div class="stats-simple-list">
        ${rows.length ? rows.map((row) => `
          <div class="stats-simple-row stats-absence-row">
            <div>
              <strong>${escapeHtml(row.name)}</strong>
              <span>Таб. № ${escapeHtml(row.tab || "не указан")} · ${escapeHtml(row.place)}${row.grade !== "" ? ` · ${escapeHtml(row.grade)} разряд` : ""}</span>
              <span>${row.dates.map(formatDate).join(", ")}</span>
            </div>
            <b>${row.shifts} ${pluralRu(row.shifts, "смена", "смены", "смен")}</b>
          </div>
        `).join("") : `<div class="stats-coverage-empty ok">За выбранный месяц больничных нет.</div>`}
      </div>
    </section>
  `;
  $("statsChart").innerHTML = "";
  $("statsWorkplaceCards").innerHTML = "";
  renderStatsHiddenTable([], "За выбранный месяц больничных нет.");
}

function renderIndividualWorkSummary(entries) {
  const rows = buildIndividualWorkplaces(entries);
  return `
    <section class="stats-operational-section stats-individual-summary">
      <div class="stats-operational-head">
        <div>
          <h3>Где работал</h3>
          <p>Количество смен и часов по фактическому месту и разряду.</p>
        </div>
      </div>
      <div class="stats-simple-list">
        ${rows.length ? rows.map((row) => `
          <div class="stats-simple-row${row.roles[0] ? statsRoleClass(row.roles[0]) : ""}"${specialRoleStyleAttribute(row.roles[0])}>
            <div>
              <strong>${escapeHtml(row.place)}</strong>
              <span>${escapeHtml(row.grade)} разряд</span>
            </div>
            <div>
              <b>${row.shifts} ${pluralRu(row.shifts, "смена", "смены", "смен")}</b>
              <span>${escapeHtml(formatHoursText(row.hours))}</span>
            </div>
          </div>
        `).join("") : `<div class="stats-balance-empty">За выбранный период смен нет.</div>`}
      </div>
    </section>
  `;
}

function renderIndividualAbsenceSummary(absences) {
  const rows = buildIndividualAbsenceReasons(absences);
  const total = new Set((absences || []).map((absence) => absence.date).filter(Boolean)).size;
  return `
    <section class="stats-operational-section stats-individual-summary">
      <div class="stats-operational-head">
        <div>
          <h3>Отсутствовал: ${total} ${pluralRu(total, "смену", "смены", "смен")}</h3>
          <p>Причины отсутствия за выбранный период.</p>
        </div>
      </div>
      <div class="stats-simple-list">
        ${rows.length ? rows.map((row) => `
          <div class="stats-simple-row stats-absence-row">
            <div>
              <strong>${escapeHtml(row.reason)}</strong>
              <span>${row.dates.map(formatDate).join(", ")}</span>
            </div>
            <b>${row.shifts} ${pluralRu(row.shifts, "смена", "смены", "смен")}</b>
          </div>
        `).join("") : `<div class="stats-coverage-empty ok">Отсутствий за выбранный период нет.</div>`}
      </div>
    </section>
  `;
}

function renderIndividualShiftList(entries) {
  const sorted = [...entries].sort((a, b) => b.date.localeCompare(a.date) || String(a.actualPlace || "").localeCompare(String(b.actualPlace || ""), "ru"));
  return `
    <details class="stats-individual-panel">
      <summary class="stats-month-title">Подробно по датам</summary>
      <div class="stats-individual-list">
        ${sorted.length ? sorted.map((entry) => `
          <article class="stats-individual-shift${statsRoleClass(statsRoleType(entry))}"${specialRoleStyleAttribute(statsRoleType(entry))}>
            <div>
              <strong>${escapeHtml(formatDate(entry.date))}</strong>
              <span>${escapeHtml(entry.actualPlace || "Не указано")}${entry.actualGrade ? ` · ${escapeHtml(entry.actualGrade)} разряд` : ""}</span>
            </div>
            <div>
              <span>${escapeHtml(entryKindLabel(entry))}</span>
              <b>${escapeHtml(formatHoursText(statsHoursForEntry(entry)))}</b>
            </div>
          </article>
        `).join("") : `<div class="absent-empty">У выбранного сотрудника за этот месяц смен нет.</div>`}
      </div>
    </details>
  `;
}

function renderIndividualStats() {
  const range = statsEffectiveMonthRange();
  const monthEntries = statsEntriesInRange(range);
  const employeeKey = renderStatsEmployeeSelect(monthEntries);
  const employee = statsEmployeeChoices(monthEntries).find((item) => statsEmployeeKey(item) === employeeKey) || null;
  const entries = monthEntries.filter((entry) => statsEmployeeKey(entry) === employeeKey);
  const absences = individualAbsences(employee, range, entries);
  const rows = buildStatsRows(entries);
  const absenceShifts = new Set(absences.map((absence) => absence.date).filter(Boolean)).size;
  $("statsSummaryCards").innerHTML = statsSummaryCardsMarkup([
    ...individualStatsSummary(employee, entries, range),
    ["Отсутствовал смен", absenceShifts],
  ]);
  $("statsMonthlyBreakdown").innerHTML = `
    ${renderStatsRoleLegend(entries, "shifts")}
    ${renderIndividualWorkSummary(entries)}
    ${renderIndividualAbsenceSummary(absences)}
    ${renderIndividualShiftList(entries)}
  `;
  renderStatsHiddenTable(rows, "У выбранного сотрудника за этот месяц смен нет.");
}

function renderSpecialWorkStats(roleType) {
  const range = statsEffectiveMonthRange();
  const label = statsRoleLabel(roleType);
  const entries = statsEntriesInRange(range).filter((entry) => statsRoleType(entry) === roleType);
  const rows = buildStatsRows(entries);
  const balance = buildStatsRoleBalance(entries, roleType);
  const shifts = statsRoleLegendCount(entries, roleType, "shifts");
  const hours = Number(entries.reduce((sum, entry) => sum + statsHoursForEntry(entry), 0).toFixed(1));
  const sortedEntries = [...entries].sort((a, b) => b.date.localeCompare(a.date) || String(a.name || "").localeCompare(String(b.name || ""), "ru"));

  $("statsSummaryCards").innerHTML = statsSummaryCardsMarkup([
    ["Период", range.label],
    ["Работа", label],
    ["Сотрудников", balance.rows.length],
    ["Смен", formatRuNumber(shifts)],
    ["Часов", formatHoursText(hours)],
  ]);
  $("statsMonthlyBreakdown").innerHTML = `
    <section class="stats-operational-section stats-balance-section">
      <div class="stats-operational-head">
        <div>
          <h3>${escapeHtml(label)}: сотрудники</h3>
          <p>От меньшего количества смен к большему.</p>
        </div>
      </div>
      <div class="stats-balance-list">${renderStatsBalanceList(balance, roleType)}</div>
    </section>
    <details class="stats-individual-panel" open>
      <summary class="stats-month-title">Смены по датам</summary>
      <div class="stats-individual-list">
        ${sortedEntries.length ? sortedEntries.map((entry) => `
          <article class="stats-individual-shift${statsRoleClass(roleType)}"${specialRoleStyleAttribute(roleType)}>
            <div>
              <strong>${escapeHtml(formatDate(entry.date))}</strong>
              <span>${escapeHtml(entry.name || "Без ФИО")}${entry.actualPlace ? ` · ${escapeHtml(entry.actualPlace)}` : ""}</span>
            </div>
            <div><b>${escapeHtml(formatHoursText(statsHoursForEntry(entry)))}</b></div>
          </article>
        `).join("") : `<div class="absent-empty">За выбранный месяц таких смен нет.</div>`}
      </div>
    </details>
  `;
  $("statsChart").innerHTML = renderStatsRoleLegend(entries, "shifts");
  $("statsWorkplaceCards").innerHTML = renderPlaceHourPanel(
    `${label}, ${range.label}`,
    entries,
    `Часы по рабочим местам за ${range.label}`
  );
  renderStatsHiddenTable(rows, `За выбранный месяц назначений «${label}» нет.`);
}

function renderStats() {
  if (!$("statsSummaryCards") || !$("statsTable") || !$("statsChart") || !$("statsWorkplaceCards")) return;
  selectedStatsDepartmentId = selectedWorkplaceDepartmentId || "";
  selectedStatsSectionId = selectedWorkplaceSectionId || "";
  renderStatsModeControls();
  $("statsChart").innerHTML = "";
  $("statsWorkplaceCards").innerHTML = "";
  if (statsMode === "shift") {
    renderShiftStats();
  } else if (statsMode === "employee") {
    renderIndividualStats();
  } else if (statsMode === "sick") {
    renderSickLeaveStats();
  } else if (["proletchik", "subworker", "capital-repair"].includes(statsMode)) {
    renderSpecialWorkStats(statsMode);
  } else {
    renderMonthlyStats();
  }
  lockHorizontalScrollSoon();
}

function renderEntries() {
  const tbody = $("entriesTable").querySelector("tbody");
  tbody.innerHTML = currentEntries().map((entry) => {
    const info = classifyEntry(entry);
    const reason = info.reasons.length ? info.reasons.join("; ") : "не требуется";
    const badge = info.mustTransfer ? `<span class="badge warn">в перевод</span>` : `<span class="badge ok">штатно</span>`;
    return `
      <tr>
        <td>${formatDate(entry.date)}</td>
        <td>${escapeHtml(entry.name)}<br>${badge}</td>
        <td>${escapeHtml(entry.tab)}</td>
        <td>${escapeHtml(info.basePlace)} ${info.baseGrade ? `${info.baseGrade}р.` : ""}</td>
        <td>${escapeHtml(entry.actualPlace)}</td>
        <td>${entry.actualGrade}</td>
        <td>${escapeHtml(entryKindLabel(entry))}</td>
        <td>${escapeHtml(entry.scheduleShift || "")}</td>
        <td>${entry.hours}</td>
        <td>${escapeHtml(reason)}</td>
        <td><button class="danger" type="button" onclick="deleteEntry('${entry.id}')">Удалить</button></td>
      </tr>
    `;
  }).join("");
}

function transferRows() {
  const settings = appSettings();
  return currentMonthEntries().filter((entry) => {
    const info = classifyEntry(entry);
    if (!info.mustTransfer) return settings.transferIncludeStandardWork === true;
    return info.reasons.some((reason) => {
      const normalizedReason = String(reason || "").toLowerCase();
      if (normalizedReason.includes("подработчик")) return settings.transferIncludeSubworkers !== false;
      if (normalizedReason.includes("разряд")) return settings.transferIncludeDifferentGrade !== false;
      if (
        normalizedReason.includes("другом месте")
        || normalizedReason.includes("своей печи")
      ) return settings.transferIncludeDifferentWorkplace !== false;
      return true;
    });
  });
}

function renderTransferPreview() {
  const rows = transferRows();
  $("transferPreview").innerHTML = makeOrderDocument(rows);
}

function renderRepairPreview() {
  const rows = currentMonthEntries().filter((entry) => entryOrdinaryShiftKind(entry, "repair") || entryOrdinaryShiftKind(entry, "warmup"));
  $("repairPreview").innerHTML = makeRepairDocument(rows);
}

function renderMeetingPreview() {
  if (!$("meetingPreview")) return;
  $("meetingPreview").innerHTML = makeMeetingDocument(meetingRows());
}

function renderVacationPrintPreview() {
  if (!$("vacationPreview")) return;
  $("vacationPreview").innerHTML = makeVacationDocuments();
}

function syncVacationPrintMonth() {
  const value = vacationPlanMonth();
  if ($("printVacationMonthInput")) $("printVacationMonthInput").value = value;
}

function renderStartVacationInlinePreview() {
  const preview = $("startVacationInlinePreview");
  if (!preview) return;
  syncVacationPrintMonth();
  preview.innerHTML = makeVacationDocuments();
}


function renderSmartPreview() {
  if (!$("smartTransferPreview") || !$("smartRepairPreview")) return;
  $("smartTransferPreview").innerHTML = makeOrderDocument(transferRows());
  const repairRows = currentMonthEntries().filter((entry) => entryOrdinaryShiftKind(entry, "repair") || entryOrdinaryShiftKind(entry, "warmup"));
  $("smartRepairPreview").innerHTML = makeRepairDocument(repairRows);
}

function formatPrintEmployeeName(name) {
  const fullName = String(name || "").trim().split(/\s+/).filter(Boolean).join(" ");
  if (!fullName) return "";
  return `<span class="print-name-full">${escapeHtml(fullName)}</span>`;
}

function formSortValue(row, mode) {
  if (mode === "workplace") {
    return String(row.actualPlace || row.place || row.workplace || "").trim();
  }
  if (mode === "alphabetical") {
    return String(row.name || row.employeeName || "").trim();
  }
  return String(
    row.sortDate
    || row.startDate
    || row.date
    || row.currentItems?.[0]?.startDate
    || ""
  ).trim();
}

function compareFormValues(left, right, numeric = false) {
  if (!left && !right) return 0;
  if (!left) return 1;
  if (!right) return -1;
  return String(left).localeCompare(String(right), "ru", {
    numeric,
    sensitivity: "base",
  });
}

function compareConfiguredFormRows(a, b, sortSettings) {
  const mode = sortSettings.mode;
  const direction = sortSettings.direction === "desc" ? -1 : 1;
  const primaryMode = mode === "alphabetical-date"
    ? "alphabetical"
    : mode === "workplace-date"
      ? "workplace"
      : mode;
  const leftPrimary = formSortValue(a, primaryMode);
  const rightPrimary = formSortValue(b, primaryMode);
  if (!leftPrimary && rightPrimary) return 1;
  if (leftPrimary && !rightPrimary) return -1;
  const primary = compareFormValues(
    leftPrimary,
    rightPrimary,
    primaryMode !== "alphabetical"
  );
  if (primary) return primary * direction;

  if (mode === "alphabetical-date" || mode === "workplace-date") {
    const leftDate = formSortValue(a, "date");
    const rightDate = formSortValue(b, "date");
    if (!leftDate && rightDate) return 1;
    if (leftDate && !rightDate) return -1;
    const secondaryDate = compareFormValues(leftDate, rightDate, true);
    if (secondaryDate) return secondaryDate * direction;
  }

  return compareFormValues(a.name, b.name)
    || compareFormValues(a.actualPlace || a.place, b.actualPlace || b.place, true)
    || compareFormValues(a.startDate || a.date || a.sortDate, b.startDate || b.date || b.sortDate, true)
    || compareFormValues(a.tab, b.tab, true);
}

function sortFormRows(rows, formKind) {
  const sortSettings = configuredFormSort(formKind);
  return [...rows].sort((a, b) => compareConfiguredFormRows(a, b, sortSettings));
}

function makeOrderDocument(rows) {
  const pages = chunkRows(sortFormRows(groupTransferRows(rows), "transfer"), 35);
  return pages.map((pageRows, pageIndex) => {
    const printableRows = padRows(pageRows, 35);
    const rowOffset = pageIndex * 35;
    return `
    <article class="document-page transfer-document">
      <div class="doc-center">АКЦИОНЕРНОЕ ОБЩЕСТВО</div>
      <div class="doc-center">"ЧЕЛЯБИНСКИЙ ЭЛЕКТРОМЕТАЛЛУРГИЧЕСКИЙ КОМБИНАТ"</div>
      <div class="doc-center">(АО "ЧЭМК")</div>
      <br>
      <div class="doc-center doc-title">РАСПОРЯЖЕНИЕ</div>
      <div class="doc-center doc-subtitle">по подразделению</div>
      <div class="doc-row">
        <span>за ${MONTHS[state.month]} ${state.year} г.</span>
        <span>№ ${escapeHtml(state.orderNumber || "__________")}</span>
      </div>
      <p class="doc-note">В связи с производственной необходимостью, разрешить переводы в течение месяца следующим работникам:</p>
      <div class="doc-row"><span></span><strong>бригада № ${escapeHtml(state.brigade || "_____")}</strong></div>
      <table class="print-table">
        <colgroup>
          <col style="width: 5%">
          <col style="width: 8%">
          <col style="width: 36%">
          <col style="width: 15%">
          <col style="width: 7%">
          <col style="width: 8%">
          <col style="width: 21%">
        </colgroup>
        <thead>
          <tr>
            <th class="form-number-heading">№ п/п</th><th>Таб. №</th><th>ФИО</th><th>Период</th><th>Печь</th><th class="form-grade-heading">Разряд</th><th class="form-ack-heading">Ознакомлен(а), подпись</th>
          </tr>
        </thead>
        <tbody>
          ${printableRows.map((entry, index) => `
            <tr>
              <td class="num">${rowOffset + index + 1}</td>
              <td class="center">${entry ? escapeHtml(entry.tab) : ""}</td>
              <td class="name-cell">${entry ? `<div class="table-cell-lines">${formatPrintEmployeeName(entry.name)}</div>` : ""}</td>
              <td class="center">${entry ? formatEntryPeriod(entry) : ""}</td>
              <td class="center">${entry ? escapeHtml(printablePlace(entry.actualPlace)) : ""}</td>
              <td class="center">${entry ? entry.actualGrade : ""}</td>
              <td></td>
            </tr>
          `).join("")}
        </tbody>
      </table>
      <div class="signature-lines">
        <div>Начальник подразделения ________________________________</div>
        <div>Начальник смены ________________________________________</div>
      </div>
    </article>
  `;
  }).join("");
}

function makeRepairDocument(rows) {
  const rowsPerPage = 45;
  const pages = chunkRows(sortFormRows(groupRepairRows(rows), "repair"), rowsPerPage);
  return pages.map((pageRows, pageIndex) => {
    const printableRows = padRows(pageRows, rowsPerPage);
    const rowOffset = pageIndex * rowsPerPage;
    return `
    <article class="document-page repair-document">
      <div class="repair-header">
        <div class="repair-header-left">
          <div class="repair-title">СПИСОК</div>
          <div class="repair-subtitle">переводов плавильщиков на ремонт (разогрев) печи</div>
          <div>за ${escapeHtml(MONTHS[state.month] || "")} ${state.year}г.</div>
        </div>
        <div class="repair-header-right">ПРИЛОЖЕНИЕ К РАСПОРЯЖЕНИЮ №${escapeHtml(state.orderNumber || "_____")}</div>
      </div>
      <div class="repair-brigade">бригада № ${escapeHtml(state.brigade || "_____")}</div>
      <table class="print-table">
        <colgroup>
          <col style="width: 3.5%">
          <col style="width: 7.5%">
          <col style="width: 36%">
          <col style="width: 11%">
          <col style="width: 6%">
          <col style="width: 8%">
          <col style="width: 9%">
          <col style="width: 9%">
          <col style="width: 10%">
        </colgroup>
        <thead>
          <tr>
            <th class="form-number-heading">№ п/п</th><th>Таб. №</th><th>ФИО</th><th>Период</th><th>Печь</th><th class="form-grade-heading">Разряд</th><th>Кол-во смен</th><th>Кол-во часов</th><th>подпись работника</th>
          </tr>
        </thead>
        <tbody>
          ${printableRows.map((entry, index) => `
            <tr>
              <td class="num">${rowOffset + index + 1}</td>
              <td class="center">${entry ? escapeHtml(entry.tab) : ""}</td>
              <td class="name-cell">${entry ? `<div class="table-cell-lines">${formatPrintEmployeeName(entry.name)}</div>` : ""}</td>
              <td class="center">${entry ? formatEntryPeriod(entry) : ""}</td>
              <td class="center">${entry ? escapeHtml(printablePlace(entry.actualPlace)) : ""}</td>
              <td class="center">${entry ? entry.actualGrade : ""}</td>
              <td class="center">${entry ? formatShiftCount(entry.shiftCount) : ""}</td>
              <td class="center">${entry ? formatShiftCount(entry.hours) : ""}</td>
              <td></td>
            </tr>
          `).join("")}
        </tbody>
      </table>
      <div class="signature-lines repair-signature-lines">
        <div>Начальник подразделения __________________________________</div>
        <div>Начальник смены ________________________________________</div>
      </div>
    </article>
  `;
  }).join("");
}

function meetingRows() {
  const monthEntries = currentEntries().filter((entry) => {
    const date = new Date(`${entry.date}T00:00:00`);
    return date.getMonth() === Number(state.month) && date.getFullYear() === Number(state.year);
  });
  const shiftsByEmployee = new Map();

  for (const entry of monthEntries) {
    const key = entry.tab ? `tab:${entry.tab}` : `name:${normalizeName(entry.name)}`;
    shiftsByEmployee.set(key, Number((Number(shiftsByEmployee.get(key) || 0) + Number(entry.shiftCount || 1)).toFixed(2)));
  }

  const rows = currentEmployees()
    .map((employee) => ({
      ...employee,
      shifts: shiftsByEmployee.get(absenceKey(employee)) || 0,
    }));
  const filteredRows = appSettings().meetingIncludeEmployeesWithoutShifts === false
    ? rows.filter((employee) => employee.shifts > 0)
    : rows;
  return sortFormRows(filteredRows, "meeting");
}

function vacationPrintMonth() {
  return Number($("printVacationMonthInput")?.value ?? vacationPlanMonth());
}

function vacationPrintBrigade() {
  return String(state.brigade || vacationBrigade() || "").trim();
}

function vacationPrintYear() {
  return vacationPlanYear();
}

function vacationPrintYearsLabel() {
  const years = vacationPrintYears();
  return years[0] === years[1] ? String(years[0]) : `${years[0]}-${years[1]}`;
}

function vacationDaysText(days) {
  return `${formatRuNumber(days)} ${pluralRu(days, "день", "дня", "дней")}`;
}

function vacationPeriodText(item) {
  const range = vacationItemRange(item);
  const start = formatVacationPrintDate(range.startDate);
  const end = formatVacationPrintDate(range.endDate);
  return range.startDate === range.endDate ? start : `${start}–${end}`;
}

function formatVacationPrintDate(value) {
  if (!value) return "";
  const [year, month, day] = String(value).split("-");
  return `${String(day || "").padStart(2, "0")}.${String(month || "").padStart(2, "0")}.${String(year || "").slice(-2)}`;
}

function previousVacationSummary(items) {
  if (!items.length) return { days: 0, period: "" };
  return {
    days: items.reduce((sum, item) => sum + vacationItemRange(item).days, 0),
    period: items.map(vacationPeriodText).join(", "),
  };
}

function vacationPrintRows(year = vacationPrintYear()) {
  year = Number(year);
  const printBrigade = vacationPrintBrigade();
  const employeeMap = new Map(activeUnifiedEmployees().map((employee) => [vacationEmployeeKey(employee), employee]));
  const previousByEmployee = new Map();
  for (const item of state.vacations || []) {
    if (!vacationItemIntersectsYear(item, year - 1)) continue;
    if (printBrigade && itemBrigade(item) !== printBrigade) continue;
    const key = vacationEmployeeKey(item);
    const list = previousByEmployee.get(key) || [];
    list.push(item);
    previousByEmployee.set(key, list);
  }
  const grouped = new Map();
  for (const item of state.vacations || []) {
    if (!vacationItemIntersectsYear(item, year)) continue;
    if (printBrigade && itemBrigade(item) !== printBrigade) continue;
    const employee = employeeMap.get(vacationEmployeeKey(item)) || item;
    const key = vacationEmployeeKey(item);
    const current = grouped.get(key) || {
      tab: item.tab || employee.tab || "",
      name: item.name || employee.name || "",
      brigade: item.brigade || itemBrigade(employee),
      place: item.place || employee.place || "",
      days: 0,
      currentItems: [],
      status: vacationPriority(employee) === "privileged" ? "Льготник" : "Отсутствует",
    };
    current.days = Number(current.days || 0) + vacationItemRange(item).days;
    current.currentItems.push(item);
    grouped.set(key, current);
  }
  const rows = [];
  for (const [key, item] of grouped.entries()) {
    const previous = previousVacationSummary(previousByEmployee.get(key) || []);
    const sortedItems = [...item.currentItems]
      .sort((a, b) => vacationItemRange(a).startDate.localeCompare(vacationItemRange(b).startDate));
    sortedItems.forEach((currentItem, index) => {
      const range = vacationItemRange(currentItem);
      rows.push({
        ...item,
        days: range.days,
        currentItems: [currentItem],
        previousDays: index === 0 ? previous.days : 0,
        previousPeriod: index === 0 ? previous.period : "",
        currentPeriod: vacationPeriodText(currentItem),
        sortDate: range.startDate || "",
      });
    });
  }
  return sortFormRows(rows, "vacation");
}

function makeVacationDocument(rows) {
  const rowsPerPage = 45;
  const options = arguments[1] || {};
  const year = Number(options.year ?? vacationPrintYear());
  const brigadeLabel = `бригада № ${vacationPrintBrigade() || "_____"}`;
  const totalPeople = new Set(rows.filter(Boolean).map((item) => vacationEmployeeKey(item))).size;
  const totalDays = rows.reduce((sum, item) => sum + Number(item.days || 0), 0);
  const pages = chunkRows(rows, rowsPerPage);
  return (pages.length ? pages : [[]]).map((pageRows, pageIndex) => {
    const printableRows = padRows(pageRows, rowsPerPage);
    const rowOffset = pageIndex * rowsPerPage;
    return `
    <article class="document-page vacation-document">
      <div class="doc-center doc-title">ГРАФИК ОТПУСКОВ</div>
      <div class="doc-center">${escapeHtml(brigadeLabel)}</div>
      <div class="doc-center">за ${year} г.</div>
      <div class="doc-row">
        <span>Всего сотрудников: ${totalPeople}</span>
        <span>Всего дней отпуска: ${formatShiftCount(totalDays)}</span>
      </div>
      <table class="print-table">
        <colgroup>
          <col style="width: 6%">
          <col style="width: 8%">
          <col style="width: 28%">
          <col style="width: 6%">
          <col style="width: 12%">
          <col style="width: 6%">
          <col style="width: 12%">
          <col style="width: 9%">
          <col style="width: 13%">
        </colgroup>
        <thead>
          <tr>
            <th class="form-number-heading" rowspan="2">№ п/п</th>
            <th rowspan="2">Таб. №</th>
            <th rowspan="2">ФИО</th>
            <th colspan="2">Предыдущий отпуск</th>
            <th colspan="2">Текущий отпуск</th>
            <th rowspan="2">Статус</th>
            <th rowspan="2">Подпись</th>
          </tr>
          <tr>
            <th>Дней</th>
            <th>Период</th>
            <th>Дней</th>
            <th>Период</th>
          </tr>
        </thead>
        <tbody>
          ${printableRows.map((item, index) => `
            <tr>
              <td class="num">${rowOffset + index + 1}</td>
              <td class="center">${item ? escapeHtml(item.tab || "") : ""}</td>
              <td class="name-cell">${item ? `<div class="table-cell-lines">${formatPrintEmployeeName(item.name)}</div>` : ""}</td>
              <td class="center">${item ? (item.previousDays ? formatShiftCount(item.previousDays) : "") : ""}</td>
              <td class="center">${item ? escapeHtml(item.previousPeriod || "") : ""}</td>
              <td class="center">${item ? formatShiftCount(item.days || 0) : ""}</td>
              <td class="center">${item ? escapeHtml(item.currentPeriod || "") : ""}</td>
              <td class="center">${item ? escapeHtml(item.status || "Отсутствует") : ""}</td>
              <td></td>
            </tr>
          `).join("")}
        </tbody>
      </table>
      <div class="signature-lines">
        <div>Начальник подразделения ________________________________</div>
        <div>Начальник смены ________________________________________</div>
      </div>
    </article>`;
  }).join("");
}

function vacationPrintYears() {
  const year = vacationPrintYear();
  return [year, year + 1];
}

function makeVacationDocuments() {
  return vacationPrintYears()
    .map((year) => makeVacationDocument(vacationPrintRows(year), { year }))
    .join("");
}

function makeMeetingDocument(rows) {
  const rowsPerPage = 45;
  const pages = chunkRows(rows, rowsPerPage);
  return (pages.length ? pages : [[]]).map((pageRows, pageIndex) => {
    const printableRows = padRows(pageRows, rowsPerPage);
    const rowOffset = pageIndex * rowsPerPage;
    return `
    <article class="document-page meeting-document">
      <div class="doc-center doc-title">ВСТРЕЧНО-СМЕННЫЕ СОБРАНИЯ</div>
      <div class="doc-center">бригада № ${escapeHtml(state.brigade || "_____")}</div>
      <div class="doc-center">за ${MONTHS[state.month]} ${state.year} г.</div>
      <br>
      <table class="print-table">
        <colgroup>
          <col style="width: 4%">
          <col style="width: 9%">
          <col style="width: 42%">
          <col style="width: 10%">
          <col style="width: 8%">
          <col style="width: 13%">
          <col style="width: 14%">
        </colgroup>
        <thead>
          <tr>
            <th class="form-number-heading">№ п/п</th>
            <th>Таб. №</th>
            <th>ФИО</th>
            <th>Рабочее место</th>
            <th class="form-grade-heading">Разряд</th>
            <th>Кол-во смен за месяц</th>
            <th>Подпись</th>
          </tr>
        </thead>
        <tbody>
          ${printableRows.map((employee, index) => `
            <tr>
              <td class="num">${rowOffset + index + 1}</td>
              <td class="center">${employee ? escapeHtml(employee.tab) : ""}</td>
              <td class="name-cell">${employee ? `<div class="table-cell-lines">${formatPrintEmployeeName(employee.name)}</div>` : ""}</td>
              <td class="center">${employee ? escapeHtml(employee.place) : ""}</td>
              <td class="center">${employee ? escapeHtml(employee.grade) : ""}</td>
              <td class="center">${employee ? formatShiftCount(employee.shifts) : ""}</td>
              <td></td>
            </tr>
          `).join("")}
        </tbody>
      </table>
      <div class="signature-lines">
        <div>Начальник смены ________________________________________</div>
      </div>
    </article>
  `;
  }).join("");
}

function groupTransferRows(rows) {
  const sorted = [...rows].sort(compareTransferGroupRows);
  if (appSettings().transferMergeConsecutiveShifts === false) {
    return sorted.map((entry) => ({
      ...entry,
      groupKey: transferGroupKey(entry),
      startDate: entry.date,
      endDate: entry.date,
    })).sort(compareTransferPrintRows);
  }
  const groups = [];

  for (const entry of sorted) {
    const key = transferGroupKey(entry);
    const last = groups[groups.length - 1];
    if (last && last.groupKey === key && shouldMergePrintInterval(last, entry)) {
      last.endDate = entry.date;
      last.shiftCount = Number(last.shiftCount || 0) + Number(entry.shiftCount || 1);
      last.hours = Number((Number(last.hours || 0) + Number(entry.hours || 0)).toFixed(1));
      last.actualGrade = mergeGradeLabel(last.actualGrade, entry.actualGrade);
      continue;
    }

    groups.push({
      ...entry,
      groupKey: key,
      startDate: entry.date,
      endDate: entry.date,
    });
  }

  return groups.sort(compareTransferPrintRows);
}

function compareTransferGroupRows(a, b) {
  return compareEmployeeIdentity(a, b)
    || String(a.date || "").localeCompare(String(b.date || ""))
    || transferPlaceGroupValue(a.actualPlace).localeCompare(transferPlaceGroupValue(b.actualPlace), "ru")
    || String(a.role || "").localeCompare(String(b.role || ""), "ru")
    || String(a.shiftKind || "").localeCompare(String(b.shiftKind || ""), "ru")
    || String(a.actualGrade || "").localeCompare(String(b.actualGrade || ""), "ru", { numeric: true });
}

function compareTransferPrintRows(a, b) {
  return compareEmployeeIdentity(a, b)
    || String(a.startDate || a.date || "").localeCompare(String(b.startDate || b.date || ""))
    || String(a.endDate || a.date || "").localeCompare(String(b.endDate || b.date || ""))
    || transferPlaceGroupValue(a.actualPlace).localeCompare(transferPlaceGroupValue(b.actualPlace), "ru")
    || String(a.actualGrade || "").localeCompare(String(b.actualGrade || ""), "ru", { numeric: true })
    || String(a.shiftKind || "").localeCompare(String(b.shiftKind || ""), "ru");
}

function groupRepairRows(rows) {
  const sorted = [...rows].sort(compareRepairGroupRows);
  if (appSettings().repairMergeConsecutiveShifts === false) {
    return sorted.map((entry) => ({
      ...entry,
      groupKey: repairGroupKey(entry),
      startDate: entry.date,
      endDate: entry.date,
    })).sort(compareRepairPrintRows);
  }
  const groups = [];

  for (const entry of sorted) {
    const key = repairGroupKey(entry);
    const last = groups[groups.length - 1];
    if (last && last.groupKey === key && shouldMergePrintInterval(last, entry)) {
      last.endDate = entry.date;
      last.shiftCount = Number((Number(last.shiftCount || 0) + Number(entry.shiftCount || 1)).toFixed(2));
      last.hours = Number((Number(last.hours || 0) + Number(entry.hours || 0)).toFixed(1));
      continue;
    }

    groups.push({
      ...entry,
      groupKey: key,
      startDate: entry.date,
      endDate: entry.date,
    });
  }

  return groups.sort(compareRepairPrintRows);
}

function compareRepairGroupRows(a, b) {
  return compareEmployeeIdentity(a, b)
    || String(a.date || "").localeCompare(String(b.date || ""))
    || String(a.actualPlace || "").localeCompare(String(b.actualPlace || ""), "ru", { numeric: true })
    || String(a.shiftKind || "").localeCompare(String(b.shiftKind || ""), "ru")
    || String(a.actualGrade || "").localeCompare(String(b.actualGrade || ""), "ru", { numeric: true });
}

function compareRepairPrintRows(a, b) {
  return String(a.startDate || a.date || "").localeCompare(String(b.startDate || b.date || ""))
    || String(a.endDate || a.date || "").localeCompare(String(b.endDate || b.date || ""))
    || compareEmployeeIdentity(a, b)
    || String(a.actualPlace || "").localeCompare(String(b.actualPlace || ""), "ru", { numeric: true })
    || String(a.shiftKind || "").localeCompare(String(b.shiftKind || ""), "ru")
    || String(a.actualGrade || "").localeCompare(String(b.actualGrade || ""), "ru", { numeric: true });
}

function compareEmployeeIdentity(a, b) {
  return normalizeName(a.name || "").localeCompare(normalizeName(b.name || ""), "ru")
    || String(a.name || "").localeCompare(String(b.name || ""), "ru")
    || String(a.tab || "").localeCompare(String(b.tab || ""), "ru", { numeric: true });
}

function isCurrentBrigadeStaffEntry(entry) {
  return Boolean(employeeByTab(entry.tab) || employeeByName(entry.name));
}

function shouldMergePrintInterval(previous, current) {
  const previousDate = previous.endDate || previous.date;
  if (previousDate === current.date) return true;
  return isNextWorkDateForBrigade(previousDate, current.date, currentBrigade());
}
function repairGroupKey(entry) {
  return [
    entry.tab || normalizeName(entry.name),
    normalizeName(entry.name),
    entry.actualPlace,
    entry.actualGrade,
    entry.shiftKind,
  ].join("::");
}

function transferGroupKey(entry) {
  return [
    entry.tab || normalizeName(entry.name),
    normalizeName(entry.name),
    transferPlaceGroupValue(entry.actualPlace),
    entry.actualGrade,
  ].join("::");
}

function isNextDate(previous, current) {
  return dateSerial(current) - dateSerial(previous) === 1;
}

function isNextWorkDateForBrigade(previous, current, brigade = currentBrigade()) {
  if (!previous || !current) return false;
  const previousSerial = dateSerial(previous);
  const currentSerial = dateSerial(current);
  if (currentSerial <= previousSerial) return false;

  for (let serial = previousSerial + 1; serial <= previousSerial + 10; serial += 1) {
    const dateValue = dateValueFromSerial(serial);
    if (!brigadeWorksOnDate(dateValue, brigade)) continue;
    return dateValue === current;
  }

  return false;
}

function brigadeWorksOnDate(dateValue, brigade = currentBrigade()) {
  const target = String(brigade || currentBrigade());
  return startShiftForDate(dateValue, "day") === target || startShiftForDate(dateValue, "night") === target;
}

function dateValueFromSerial(serial) {
  const date = new Date(serial * 86400000);
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}-${String(date.getUTCDate()).padStart(2, "0")}`;
}

function dateSerial(value) {
  const [year, month, day] = String(value || "").split("-").map(Number);
  return Math.floor(Date.UTC(year, month - 1, day) / 86400000);
}

function buildRepairCandidateMap() {
  const byFurnace = new Map();
  for (const entry of currentEntries()) {
    const code = placeCode(entry.actualPlace);
    if (!FURNACES.includes(code)) continue;
    if (!byFurnace.has(code)) byFurnace.set(code, new Map());
    const day = byFurnace.get(code).get(entry.date) || [];
    day.push(entry);
    byFurnace.get(code).set(entry.date, day);
  }

  return byFurnace;
}

function manualRepairEntriesForFurnace(furnace) {
  return currentEntries().filter((entry) =>
    placeCode(entry.actualPlace) === String(furnace)
    && (entryOrdinaryShiftKind(entry, "repair") || entryOrdinaryShiftKind(entry, "warmup"))
    && !entry.smartRepairDistribution
  );
}

function scoreRepairCandidate(date, entries) {
  const hasSubworker = entries.some((entry) => classifyEntry(entry).reasons.some((reason) => reason.includes("подработчик")));
  const hasProletchik = entries.some((entry) => entry.role === "proletchik");
  const hasCapitalRepair = entries.some((entry) => entry.role === "capitalRepair");
  const isNight = getShiftForDate(date).kind === "night";
  const people = entries.length;
  const score = (people * 1000) + (isNight ? 300 : 0) + (hasSubworker ? 10000 : 0) + (hasProletchik ? 10000 : 0) + (hasCapitalRepair ? 10000 : 0);
  const explanation = [
    `${people} чел. на печи`,
    isNight ? "ночная смена: есть ночная надбавка, поэтому дата менее желательна для ремонта/разогрева" : "дневная смена",
    hasSubworker ? "есть подработчик" : "подработчиков нет",
    hasProletchik ? "есть пролётчик" : "пролётчика нет",
    hasCapitalRepair ? "есть капитальный ремонт" : "капремонта нет",
    "выбрана дата с меньшей нагрузкой: ремонт 11,5 ч по голому тарифу, разогрев 12 ч с условиями труда, обычная смена выгоднее",
    "учтено: чем больше плавильщиков на печи, тем меньше доля тонн на человека",
  ].join("; ");

  return { date, entries, people, hasSubworker, hasProletchik, score, explanation };
}

function resetSmartRepairDistribution(furnaces = null) {
  const furnaceSet = furnaces ? new Set(furnaces.map(String)) : null;
  for (const entry of state.entries || []) {
    if (!belongsToCurrentBrigade(entry) || !entry.smartRepairDistribution) continue;
    if (furnaceSet && !furnaceSet.has(placeCode(entry.actualPlace))) continue;
    entry.shiftKind = entry.previousShiftKind || "regular";
    entry.shiftCount = Number(entry.previousShiftCount || 1);
    entry.hours = Number(entry.previousHours ?? hoursForKind(entry.shiftKind, entry.shiftCount));
    entry.comment = entry.previousComment || "";
    delete entry.smartRepairDistribution;
    delete entry.smartRepairKind;
    delete entry.smartRepairExplanation;
    delete entry.previousShiftKind;
    delete entry.previousShiftCount;
    delete entry.previousHours;
    delete entry.previousComment;
  }
}

function distributeRepairForFurnaces(furnaces, plan, byFurnace, warnings) {
  let changedRows = 0;

  for (const furnace of furnaces) {
    const manualRows = manualRepairEntriesForFurnace(furnace);
    if (manualRows.length) {
      warnings.push(`Печь ${furnace}: ремонт/разогрев уже внесён вручную (${manualRows.length} строк), авто-подбор пропущен.`);
      continue;
    }

    const item = plan[furnace] || { repair: 0, warmup: 0 };
    const repairCount = Math.ceil(Number(item.repair || 0));
    const warmupCount = Math.ceil(Number(item.warmup || 0));
    if (!repairCount && !warmupCount) continue;

    const candidates = [...(byFurnace.get(furnace)?.entries() || [])]
      .map(([date, entries]) => scoreRepairCandidate(date, entries))
      .sort((a, b) => a.score - b.score || a.date.localeCompare(b.date));

    const repairPick = candidates.slice(0, repairCount);
    const warmupPick = candidates.slice(repairCount, repairCount + warmupCount);

    if (repairPick.length < repairCount) {
      warnings.push(`Печь ${furnace}: не хватает введённых дат для ремонта (${repairPick.length} из ${repairCount}).`);
    }
    if (warmupPick.length < warmupCount) {
      warnings.push(`Печь ${furnace}: не хватает введённых дат для разогрева (${warmupPick.length} из ${warmupCount}).`);
    }

    for (const candidate of repairPick) {
      markEntriesAsSmartRepair(candidate.entries, "repair", `Печь ${furnace}, ${formatDate(candidate.date)}: ${candidate.explanation}`);
      changedRows += candidate.entries.length;
    }
    for (const candidate of warmupPick) {
      markEntriesAsSmartRepair(candidate.entries, "warmup", `Печь ${furnace}, ${formatDate(candidate.date)}: ${candidate.explanation}`);
      changedRows += candidate.entries.length;
    }
  }

  return changedRows;
}

function applySmartRepairForFurnace(furnace) {
  const manualRows = manualRepairEntriesForFurnace(furnace);
  if (manualRows.length) {
    alert(`Печь ${furnace}: ремонт/разогрев уже внесён вручную. Умное распределение по этой печи отключено.`);
    renderRepairPlanGrid();
    return;
  }

  const plan = currentRepairPlans();
  const item = plan[furnace] || { repair: 0, warmup: 0 };
  const repairCount = Math.ceil(Number(item.repair || 0));
  const warmupCount = Math.ceil(Number(item.warmup || 0));

  if (!repairCount && !warmupCount) {
    alert(`Сначала укажи ремонт или разогрев для печи ${furnace}.`);
    return;
  }

  resetSmartRepairDistribution([furnace]);
  const byFurnace = buildRepairCandidateMap();
  const warnings = [];
  const changedRows = distributeRepairForFurnaces([furnace], plan, byFurnace, warnings);
  state.entries.sort((a, b) => a.date.localeCompare(b.date) || a.name.localeCompare(b.name, "ru"));
  saveState();
  render();
  openPrintPreview("repairPreview");

  if (!changedRows) {
    alert(`По печи ${furnace} не нашёл введённых смен для распределения.`);
    return;
  }

  const message = [`Готово. Печь ${furnace}: в бланк ремонта/разогрева внесено ${changedRows} строк.`];
  if (warnings.length) message.push(warnings.join("\n"));
  alert(message.join("\n"));
}

function applyCapitalRepairDistribution() {
  if (!specialRoleEnabledForDepartment("capitalRepair", DEFAULT_DEPARTMENT_ID, appSettings())) {
    alert(`Роль «${specialWorkLabel("capitalRepair", "Капремонт")}» удалена из подразделения «Цех 7». Верните её в настройках, чтобы создавать новые назначения.`);
    return;
  }
  if (!currentCapitalRepairShifts().length) {
    alert("Сначала добавь капитальный ремонт во вкладке Рабочие места.");
    return;
  }

  const assignments = smartDistributeCapitalRepair({
    saveAfter: false,
    renderAfter: false,
  });

  state.entries.sort((a, b) => a.date.localeCompare(b.date) || a.name.localeCompare(b.name, "ru"));
  saveState();
  render();
  openPrintPreview("transferPreview");

  if (!assignments.length) {
    alert("Не нашёл смен капитального ремонта для распределения.");
    return;
  }

  alert(`Готово. Капитальный ремонт распределён и внесён в бланки: ${assignments.length} смен.`);
}

function applyProletchikDistribution() {
  if (!specialRoleEnabledForDepartment("proletchik", DEFAULT_DEPARTMENT_ID, appSettings())) {
    alert(`Роль «${specialWorkLabel("proletchik", "Пролётчик")}» удалена из подразделения «Цех 7». Верните её в настройках, чтобы создавать новые назначения.`);
    return;
  }
  if (!currentProletchikShifts().length) {
    alert("Сначала добавь пролётчика во вкладке Рабочие места.");
    return;
  }

  const assignments = smartDistributeProletchik({
    silent: true,
    saveAfter: false,
    renderAfter: false,
    showPreview: false,
  });

  state.entries.sort((a, b) => a.date.localeCompare(b.date) || a.name.localeCompare(b.name, "ru"));
  saveState();
  render();
  openPrintPreview("transferPreview");

  if (!assignments.length) {
    alert("Не нашёл смен пролётчика для распределения.");
    return;
  }

  alert(`Готово. Пролётчик распределён и внесён в бланки: ${assignments.length} смен.`);
}

function markEntriesAsSmartRepair(items, kind, explanation) {
  for (const entry of items) {
    entry.previousShiftKind = entry.shiftKind;
    entry.previousShiftCount = entry.shiftCount;
    entry.previousHours = entry.hours;
    entry.previousComment = entry.comment || "";
    entry.shiftKind = kind;
    entry.shiftCount = 1;
    entry.hours = hoursForKind(kind, 1);
    entry.smartRepairDistribution = true;
    entry.smartRepairKind = kind;
    entry.smartRepairExplanation = explanation;
    entry.comment = `Умное распределение ${kind === "repair" ? "ремонта" : "разогрева"}. ${explanation}${entry.previousComment ? `. ${entry.previousComment}` : ""}`;
  }
}

function applySmartRepairDistribution() {
  const plan = currentRepairPlans();
  const totalNeeded = FURNACES.reduce((sum, furnace) => {
    const item = plan[furnace] || {};
    return sum + Math.ceil(Number(item.repair || 0)) + Math.ceil(Number(item.warmup || 0));
  }, 0);
  if (!totalNeeded) {
    alert("Сначала укажи ремонт/разогрев в плане по печам.");
    return;
  }

  resetSmartRepairDistribution();
  const byFurnace = buildRepairCandidateMap();
  const warnings = [];
  const changedRows = distributeRepairForFurnaces(FURNACES, plan, byFurnace, warnings);

  state.entries.sort((a, b) => a.date.localeCompare(b.date) || a.name.localeCompare(b.name, "ru"));
  saveState();
  render();
  openPrintPreview("repairPreview");

  if (!changedRows) {
    alert("Не нашёл введённых смен для умного распределения.");
    return;
  }

  const message = ["Готово."];
  if (changedRows) {
    message.push(`В бланк ремонта/разогрева внесено ${changedRows} строк.`);
  }
  if (warnings.length) message.push(warnings.join("\n"));
  alert(message.join("\n"));
}

function renderReasonReport() {
  const capitalRepairRows = currentEntries()
    .filter((entry) => entry.role === "capitalRepair")
    .map((entry, index) => `
      <tr>
        <td data-label="№">${index + 1}</td>
        <td data-label="Дата">${formatDate(entry.date)}</td>
        <td data-label="Плавильщик">${escapeHtml(entry.name)}</td>
        <td data-label="Куда закрыт">${escapeHtml(entry.actualPlace)}</td>
        <td data-label="Разряд">${entry.actualGrade}</td>
        <td class="reason-load-cell" data-label="Загрузка смены">${escapeHtml(workplaceLoadSummary(entry.date))}</td>
        <td data-label="Обоснование">${escapeHtml(entry.comment || "Закрыто вручную на рабочее место.")}</td>
      </tr>
    `).join("");

  const proletchikRows = currentEntries()
    .filter((entry) => entry.role === "proletchik")
    .map((entry, index) => `
      <tr>
        <td data-label="№">${index + 1}</td>
        <td data-label="Дата">${formatDate(entry.date)}</td>
        <td data-label="Пролётчик">${escapeHtml(entry.name)}</td>
        <td data-label="Куда закрыт">${escapeHtml(entry.actualPlace)}</td>
        <td data-label="Разряд">${entry.actualGrade}</td>
        <td class="reason-load-cell" data-label="Загрузка смены">${escapeHtml(workplaceLoadSummary(entry.date))}</td>
        <td data-label="Обоснование">${escapeHtml(entry.comment || "Закрыто вручную на рабочее место.")}</td>
      </tr>
    `).join("");

  const repairRows = buildRepairReasonRows();

  const html = `
    <div class="reason-report">
      <section class="reason-section">
        <h3>Обоснование распределения капитального ремонта</h3>
        <p>Капитальный ремонт закрывается вручную на выбранное рабочее место и по указанному разряду.</p>
        ${capitalRepairRows ? `<table>
          <thead><tr><th>№</th><th>Дата</th><th>Плавильщик</th><th>Куда закрыт</th><th>Разряд</th><th>Загрузка смены</th><th>Обоснование</th></tr></thead>
          <tbody>${capitalRepairRows}</tbody>
        </table>` : `<div class="reason-empty-card">Капитальный ремонт ещё не внесён вручную.</div>`}
      </section>

      <section class="reason-section">
        <h3>Обоснование распределения пролётчика</h3>
        <p>Пролётчик закрывается вручную на выбранное рабочее место и по указанному разряду. В загрузке показано, где сколько человек работало в эту смену без пролётчика и капитального ремонта.</p>
        ${proletchikRows ? `<table>
          <thead><tr><th>№</th><th>Дата</th><th>Пролётчик</th><th>Куда закрыт</th><th>Разряд</th><th>Загрузка смены</th><th>Обоснование</th></tr></thead>
          <tbody>${proletchikRows}</tbody>
        </table>` : `<div class="reason-empty-card">Пролётчик ещё не внесён вручную.</div>`}
      </section>

      <section class="reason-section">
        <h3>Обоснование ремонта / разогрева</h3>
        <p>Программа выбирает даты с меньшей потерей зарплаты: без подработчиков, без пролётчика и с меньшим количеством людей на печи. У разливщиков смен ремонта/разогрева нет.</p>
        ${repairRows ? `<table>
          <thead><tr><th>№</th><th>Печь</th><th>Что закрыть</th><th>Дата</th><th>Людей</th><th>Подработчик</th><th>Пролётчик</th><th>Обоснование</th></tr></thead>
          <tbody>${repairRows}</tbody>
        </table>` : `<div class="reason-empty-card">План ремонта/разогрева ещё не внесён или нет смен для подбора.</div>`}
      </section>
    </div>
  `;

  if ($("smartReasonPreview")) $("smartReasonPreview").innerHTML = html;
}

function workplaceLoadSummary(date) {
  const order = [...FURNACES.map((furnace) => `Печь ${furnace}`), "РМ"];
  const loads = new Map(order.map((place) => [place, { people: 0, hours: 0 }]));
  const custom = new Map();

  for (const entry of currentEntries()) {
    if (entry.date !== date) continue;
    if (entry.role === "proletchik" || entry.role === "capitalRepair") continue;
    const code = placeCode(entry.actualPlace);
    const place = FURNACES.includes(code) ? `Печь ${code}` : (isCastingPlaceValue(code) ? "РМ" : printablePlace(entry.actualPlace));
    const hours = Number(entry.hours || 0);
    if (loads.has(place)) {
      const current = loads.get(place);
      current.people += 1;
      current.hours = Number((current.hours + hours).toFixed(1));
    } else {
      const current = custom.get(place) || { people: 0, hours: 0 };
      current.people += 1;
      current.hours = Number((current.hours + hours).toFixed(1));
      custom.set(place, current);
    }
  }

  const totalPeople = [...loads.values(), ...custom.values()].reduce((sum, item) => sum + item.people, 0);
  const totalHours = Number([...loads.values(), ...custom.values()].reduce((sum, item) => sum + item.hours, 0).toFixed(1));
  const parts = [
    ...order.map((place) => {
      const item = loads.get(place) || { people: 0, hours: 0 };
      return `${place}: ${item.people} чел. / ${formatShiftCount(item.hours)} ч`;
    }),
    ...[...custom.entries()]
      .sort((a, b) => a[0].localeCompare(b[0], "ru"))
      .map(([place, item]) => `${place}: ${item.people} чел. / ${formatShiftCount(item.hours)} ч`),
    `Итого: ${totalPeople} чел. / ${formatShiftCount(totalHours)} ч`,
  ];
  return parts.join("\n");
}

function buildRepairReasonRows() {
  const byFurnace = new Map();
  for (const entry of currentEntries()) {
    const code = placeCode(entry.actualPlace);
    if (!FURNACES.includes(code)) continue;
    if (!byFurnace.has(code)) byFurnace.set(code, new Map());
    const day = byFurnace.get(code).get(entry.date) || [];
    day.push(entry);
    byFurnace.get(code).set(entry.date, day);
  }

  let rowNumber = 0;
  const rows = [];
  for (const furnace of FURNACES) {
    const plan = currentRepairPlans()[furnace] || { repair: 0, warmup: 0 };
    const needed = Number(plan.repair || 0) + Number(plan.warmup || 0);
    if (!needed) continue;

    const candidates = [...(byFurnace.get(furnace)?.entries() || [])]
      .map(([date, entries]) => {
        const hasSubworker = entries.some((entry) => classifyEntry(entry).reasons.some((reason) => reason.includes("подработчик")));
        const hasProletchik = entries.some((entry) => entry.role === "proletchik");
        const people = entries.length;
        const hasCapitalRepair = entries.some((entry) => entry.role === "capitalRepair");
        const isNight = getShiftForDate(date).kind === "night";
        const score = (people * 1000) + (isNight ? 300 : 0) + (hasSubworker ? 10000 : 0) + (hasProletchik ? 10000 : 0) + (hasCapitalRepair ? 10000 : 0);
        const explanation = [
          `${people} чел. на печи`,
          hasSubworker ? "есть подработчик" : "подработчиков нет",
          hasProletchik ? "есть пролётчик" : "пролётчика нет",
          `оценка ${score}`,
        ].join("; ");
        return { date, people, hasSubworker, hasProletchik, hasCapitalRepair, isNight, score, explanation };
      })
      .sort((a, b) => a.score - b.score || a.date.localeCompare(b.date));

    const repairPick = candidates.slice(0, Math.ceil(plan.repair || 0)).map((item) => ({ ...item, kind: "Ремонт" }));
    const warmupPick = candidates
      .slice(Math.ceil(plan.repair || 0), Math.ceil((plan.repair || 0) + (plan.warmup || 0)))
      .map((item) => ({ ...item, kind: "Разогрев" }));

    for (const item of [...repairPick, ...warmupPick]) {
      rowNumber += 1;
      rows.push(`
        <tr>
          <td data-label="№">${rowNumber}</td>
          <td data-label="Печь">Печь ${furnace}</td>
          <td data-label="Что закрыть">${item.kind}</td>
          <td data-label="Дата">${formatDate(item.date)}</td>
          <td data-label="Людей">${item.people}</td>
          <td data-label="Подработчик">${item.hasSubworker ? "есть" : "нет"}</td>
          <td data-label="Пролётчик">${item.hasProletchik ? "есть" : "нет"}</td>
          <td data-label="Обоснование">${escapeHtml(item.explanation)}</td>
        </tr>
      `);
    }
  }

  return rows.join("");
}

function padRows(rows, count) {
  return [...rows, ...Array(Math.max(0, count - rows.length)).fill(null)].slice(0, count);
}

function chunkRows(rows, count) {
  const source = rows.length ? rows : [];
  const chunks = [];
  for (let index = 0; index < source.length; index += count) {
    chunks.push(source.slice(index, index + count));
  }
  return chunks.length ? chunks : [[]];
}

function printPreview(targetId) {
  renderPrintDocuments();
  const target = $(targetId);
  if (!target) return;
  printIsolatedPreview(target.innerHTML);
}

function printIsolatedPreview(previewHtml) {
  const frame = document.createElement("iframe");
  frame.setAttribute("title", "Печать бланка");
  frame.style.position = "fixed";
  frame.style.right = "0";
  frame.style.bottom = "0";
  frame.style.width = "0";
  frame.style.height = "0";
  frame.style.border = "0";
  frame.style.opacity = "0";
  document.body.appendChild(frame);

  const printCss = `
    @page { size: A4 portrait; margin: 0; }
    * { box-sizing: border-box; }
    html, body {
      width: 210mm !important;
      min-height: 297mm !important;
      margin: 0 !important;
      padding: 0 !important;
      background: #fff !important;
      overflow: visible !important;
    }
    body {
      display: block !important;
      color: #111 !important;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    .preview,
    .print-target {
      display: block !important;
      width: 210mm !important;
      margin: 0 !important;
      padding: 0 !important;
      background: #fff !important;
      overflow: visible !important;
    }
    .document-page {
      display: block !important;
      position: relative !important;
      width: 210mm !important;
      height: 297mm !important;
      min-height: 297mm !important;
      max-height: 297mm !important;
      margin: 0 auto !important;
      padding: 12mm 10mm !important;
      border: 0 !important;
      box-shadow: none !important;
      border-radius: 0 !important;
      overflow: hidden !important;
      break-after: page !important;
      page-break-after: always !important;
      background: #fff !important;
    }
    .document-page:last-child {
      break-after: auto !important;
      page-break-after: auto !important;
    }
  `;

  const doc = frame.contentDocument || frame.contentWindow.document;
  doc.open();
  doc.write(`<!doctype html><html><head><meta charset="utf-8"><style>${collectCurrentCss()}</style><style>${printCss}</style></head><body><div class="preview print-target">${previewHtml}</div></body></html>`);
  doc.close();

  const runPrint = () => {
    const win = frame.contentWindow;
    if (!win) return;
    win.focus();
    win.print();
    setTimeout(() => frame.remove(), 1000);
  };
  setTimeout(runPrint, 150);
}

function collectCurrentCss() {
  return [...document.styleSheets].map((sheet) => {
    try {
      return [...sheet.cssRules].map((rule) => rule.cssText).join("\n");
    } catch {
      return "";
    }
  }).join("\n");
}

function countEmailDocumentPages(html) {
  return Math.max(1, (String(html || "").match(/<article\s+class="document-page/g) || []).length);
}

function emailPdfCss(pageCount = 1) {
  const pagePositions = Array.from({ length: Math.max(1, pageCount) }, (_, index) =>
    `body > .document-page:nth-of-type(${index + 1}) { top: ${index * 1123}px; }`
  ).join("\n");
  return `
    * { box-sizing: border-box; }
    html, body {
      margin: 0;
      padding: 0;
      background: #fff;
      color: #111;
      font-family: "Times New Roman", Times, serif;
    }
    body {
      position: relative;
      width: 794px;
      height: ${Math.max(1, pageCount) * 1123}px;
      min-height: ${Math.max(1, pageCount) * 1123}px;
      overflow: hidden;
    }
    .document-page {
      position: absolute;
      left: 0;
      top: 0;
      width: 794px;
      height: 1123px;
      min-height: 1123px;
      max-height: 1123px;
      margin: 0 auto;
      padding: 52px 68px;
      background: #fff;
      color: #111;
      border: 0;
      box-shadow: none;
      font-family: "Times New Roman", Times, serif;
      font-size: 13.8px;
      overflow: hidden;
      page-break-after: always;
      break-after: page;
    }
    ${pagePositions}
    .document-page:last-child { page-break-after: auto; }
    .doc-center { text-align: center; }
    .doc-title {
      font-size: 17px;
      font-weight: 700;
      text-transform: uppercase;
    }
    .doc-subtitle {
      font-size: 15px;
      font-weight: 700;
      text-decoration: underline;
    }
    .doc-row {
      display: flex;
      justify-content: space-between;
      gap: 20px;
      margin: 8px 0;
    }
    .doc-note { margin: 10px 0 4px; }
    .print-table {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0;
      border-top: 1px solid #111;
      border-left: 1px solid #111;
      table-layout: fixed;
      font-size: 12px;
    }
    .print-table tr {
      height: 18px;
    }
    .print-table th,
    .print-table td {
      border: 0;
      border-right: 1px solid #111;
      border-bottom: 1px solid #111;
      padding: 2px 3px;
      height: 18px;
      line-height: 1.05;
      text-align: center;
      vertical-align: middle;
      overflow-wrap: anywhere;
    }
    .print-table .name-cell {
      padding: 1px 3px;
      overflow: hidden;
      vertical-align: middle;
      text-align: left;
    }
    .table-cell-lines {
      display: flex;
      align-items: center;
      justify-content: flex-start;
      min-width: 0;
      height: 100%;
      line-height: 1;
      text-align: left;
      overflow: visible;
      text-overflow: clip;
    }
    .print-name-full {
      display: block;
      white-space: nowrap;
      font-size: inherit;
      line-height: 1;
    }
    .print-name-full-compact {
      font-size: inherit;
    }
    .print-name-full-tight {
      font-size: inherit;
    }
    .vacation-document .print-table,
    .vacation-document .print-table th,
    .vacation-document .print-table td {
      font-size: 9px;
      letter-spacing: 0;
    }
    .vacation-document .print-table th,
    .vacation-document .print-table td {
      height: 17px;
    }
    .vacation-document .print-table .name-cell {
      overflow: visible;
    }
    .vacation-document .print-name-full {
      white-space: nowrap;
      font-size: inherit;
    }
    .vacation-document .print-table td:nth-child(5),
    .vacation-document .print-table td:nth-child(7),
    .vacation-document .print-table th:nth-child(8),
    .vacation-document .print-table td:nth-child(8) {
      white-space: nowrap;
      overflow-wrap: normal;
      font-size: inherit;
    }
    .transfer-document .print-table {
      font-size: 12px;
    }
    .transfer-document .print-table tr,
    .transfer-document .print-table th,
    .transfer-document .print-table td {
      height: 20px;
      max-height: 20px;
    }
    .transfer-document .table-cell-lines {
      height: 18px;
      max-height: 18px;
      line-height: 12px;
    }
    .transfer-document .signature-lines {
      margin-top: 8px;
      gap: 8px;
    }
   .print-table th {
     background: #f3f4f6;
     font-weight: 700;
     text-align: center;
   }
    .document-page .print-table th.form-number-heading {
      white-space: nowrap;
      overflow-wrap: normal;
      word-break: normal;
    }
    .print-table td.num,
    .print-table td.center { text-align: center; }
    .signature-lines {
      margin-top: 14px;
      display: grid;
      gap: 12px;
    }
    .repair-document {
      padding: 52px 68px;
      font-size: 12.8px;
    }
    .repair-header {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 32px;
      align-items: start;
      margin: 0 0 8px;
    }
    .repair-header-left,
    .repair-header-right { text-align: center; }
    .repair-title,
    .repair-subtitle,
    .repair-header-right,
    .repair-brigade { font-weight: 700; }
    .repair-title { text-transform: uppercase; }
    .repair-brigade {
      margin: 0 0 5px;
      text-align: center;
    }
    .repair-document .print-table {
      font-size: 12px;
    }
    .repair-document .print-table th,
    .repair-document .print-table td {
      height: 17px;
      padding: 1px 2px;
      line-height: 1;
    }
    .repair-document .print-table th {
      white-space: normal;
      overflow: visible;
      overflow-wrap: normal;
      word-break: normal;
      line-height: 1.05;
      font-size: inherit;
    }
    .meeting-document {
      padding: 52px 45px;
      font-size: 13.8px;
    }
  `;
}

function formEmailMeta(kind = "all") {
  const map = {
    transfer: { label: "переводы", file: "Переводы", title: "Переводы" },
    repair: { label: "ремонт/разогрев", file: "Ремонт_разогрев", title: "Ремонт/разогрев" },
    meeting: { label: "встречно-сменные собрания", file: "Встречносменные", title: "Встречно-сменные" },
    vacation: { label: "график отпусков", file: "График_отпусков", title: "График отпусков" },
    all: { label: "бланки", file: "Бланки", title: "Бланки" },
  };
  return map[kind] || map.all;
}

function formsEmailFileName(kind = "all") {
  const periodMonth = kind === "vacation" ? vacationPrintMonth() : Number(state.month);
  const periodYear = kind === "vacation" ? vacationPrintYearsLabel() : Number(state.year);
  const month = MONTHS[periodMonth] || "месяц";
  const meta = formEmailMeta(kind);
  return `${meta.file}_бригада_${state.brigade || ""}_${month}_${periodYear}.pdf`.replace(/[\\/:*?"<>|]+/g, "_");
}

function formEmailPages(kind = "all") {
  renderTransferPreview();
  renderRepairPreview();
  renderMeetingPreview();
  renderVacationPrintPreview();

  if (kind === "transfer") return $("transferPreview").innerHTML;
  if (kind === "repair") return $("repairPreview").innerHTML;
  if (kind === "meeting") return $("meetingPreview").innerHTML;
  if (kind === "vacation") return $("vacationPreview").innerHTML;
  return `${$("transferPreview").innerHTML}\n${$("repairPreview").innerHTML}\n${$("meetingPreview").innerHTML}\n${$("vacationPreview").innerHTML}`;
}

async function prepareFormsEmail(kind = "all") {
  try {
    const meta = formEmailMeta(kind);
    const periodMonth = kind === "vacation" ? vacationPrintMonth() : Number(state.month);
    const periodYear = kind === "vacation" ? vacationPrintYearsLabel() : Number(state.year);
    const title = `${meta.title} бригада ${state.brigade || ""}, ${MONTHS[periodMonth]} ${periodYear}`;
    const fileName = formsEmailFileName(kind);
    const pagesHtml = formEmailPages(kind);
    const pageCount = countEmailDocumentPages(pagesHtml);
    const html = `<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=794, initial-scale=1, maximum-scale=1, user-scalable=no">
  <title>${escapeHtml(title)}</title>
  <style>${emailPdfCss(pageCount)}</style>
</head>
<body>
  ${pagesHtml}
</body>
</html>`;

    const message = `Здравствуйте.\n\nОтправляю ${meta.label} за ${MONTHS[periodMonth]} ${periodYear}, бригада № ${state.brigade || ""}.\n\nФайл PDF прикреплён к письму.`;

    if (window.AndroidEmail?.sharePdf) {
      window.AndroidEmail.showToast?.("Готовлю PDF...");
      const started = window.AndroidEmail.sharePdf(OFFICE_EMAIL, title, message, fileName, html);
      if (started) return;
    }

    const htmlFileName = fileName.replace(/\.pdf$/i, ".html");
    if (window.AndroidEmail?.shareHtml) {
      const started = window.AndroidEmail.shareHtml(OFFICE_EMAIL, title, message, htmlFileName, html);
      if (started) return;
    }

    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const file = new File([blob], htmlFileName, { type: "text/html" });
    if (navigator.canShare?.({ files: [file] }) && navigator.share) {
      try {
        await navigator.share({
          title,
          text: `${message}\n\nПолучатель: ${OFFICE_EMAIL}`,
          files: [file],
        });
        return;
      } catch (error) {
        if (error?.name === "AbortError") return;
      }
    }

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = htmlFileName;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);

    const subject = encodeURIComponent(title);
    const body = encodeURIComponent(`Здравствуйте.\n\nОтправляю ${meta.label} за ${MONTHS[periodMonth]} ${periodYear}, бригада № ${state.brigade || ""}.\n\nВ APK бланк прикрепляется как PDF. В браузере файл скачан как HTML: ${htmlFileName}. Его можно открыть и сохранить в PDF через печать.`);
    window.location.href = `mailto:${OFFICE_EMAIL}?subject=${subject}&body=${body}`;
    alert(`PDF-вложение доступно в Android-приложении.\nВ этом браузере скачан HTML-файл: ${htmlFileName}\nОткрылось письмо на ${OFFICE_EMAIL}.`);
  } catch (error) {
    showAppMessage("Почта", `Не удалось подготовить письмо: ${error.message || error}`);
  }
}

function formatDate(value) {
  if (!value) return "";
  const [year, month, day] = value.split("-");
  return `${day}.${month}.${year}`;
}

function formatEntryPeriod(entry) {
  const start = entry.startDate || entry.date;
  const end = entry.endDate || entry.date;
  if (!start) return "";
  if (!end || start === end) return formatShortDate(start);
  return `${formatShortDate(start)}-${formatShortDate(end)}`;
}

function formatShortDate(value) {
  if (!value) return "";
  const [year, month, day] = value.split("-");
  return `${Number(day)}.${month}.${String(year).slice(-2)}`;
}

function formatShiftCount(value) {
  const number = Number(value || 0);
  if (!number) return "";
  return Number.isInteger(number) ? String(number) : String(number).replace(".", ",");
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function escapeJs(value) {
  return String(value ?? "")
    .replace(/\\/g, "\\\\")
    .replace(/'/g, "\\'")
    .replace(/\r?\n/g, " ");
}

window.deleteEntry = deleteEntry;
window.deleteAbsence = deleteAbsence;
window.deleteProletchikShift = deleteProletchikShift;
window.deleteWorkplaceRow = deleteWorkplaceRow;
window.dismissEmployee = dismissEmployee;
window.restoreEmployee = restoreEmployee;
window.editEmployee = editEmployee;
window.removeCustomEmployee = removeCustomEmployee;
window.dismissGlobalEmployee = dismissGlobalEmployee;
window.restoreGlobalEmployee = restoreGlobalEmployee;
window.editGlobalEmployeeGrade = editGlobalEmployeeGrade;
window.transferGlobalEmployee = transferGlobalEmployee;
window.setRepairPlanCount = setRepairPlanCount;
window.applySmartRepairForFurnace = applySmartRepairForFurnace;
window.addVacationPart = addVacationPart;
window.prepareAdditionalVacationPart = prepareAdditionalVacationPart;
window.deleteVacationPart = deleteVacationPart;
window.deleteVacationParts = deleteVacationParts;
window.setVacationPriority = setVacationPriority;
window.setVacationAllowance = setVacationAllowance;
window.selectVacationMonth = selectVacationMonth;
window.selectWorkplace = selectWorkplace;
window.saveEmployeePhone = saveEmployeePhone;
window.deleteEmployeePhone = deleteEmployeePhone;
window.callEmployeePhone = callEmployeePhone;
init();


